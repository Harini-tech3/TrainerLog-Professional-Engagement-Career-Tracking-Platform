import React, { useState, useEffect } from 'react';
import { doc, getDoc, setDoc, collection, addDoc, query, where, onSnapshot, updateDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase';
import { useAuth } from '../components/Auth/AuthContext';
import { Engagement } from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import imageCompression from 'browser-image-compression';
import { 
  Plus, 
  Search, 
  Filter, 
  FileText, 
  MapPin, 
  Users as UsersIcon, 
  X, 
  Upload, 
  ExternalLink, 
  Loader2, 
  ArrowRight, 
  Award,
  Trash2,
  Calendar as CalendarIcon,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import Footer from '../components/Layout/Footer';

export default function Engagements() {
  const { user, isAuthReady } = useAuth();
  const [engagements, setEngagements] = useState<Engagement[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedEngagement, setSelectedEngagement] = useState<Engagement | null>(null);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [uploadStatuses, setUploadStatuses] = useState<Record<string, 'uploading' | 'error' | null>>({});
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedMonth, setSelectedMonth] = useState<string>('all');
  const [selectedYear, setSelectedYear] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const months = [
    { value: '0', label: 'Jan' },
    { value: '1', label: 'Feb' },
    { value: '2', label: 'Mar' },
    { value: '3', label: 'Apr' },
    { value: '4', label: 'May' },
    { value: '5', label: 'Jun' },
    { value: '6', label: 'Jul' },
    { value: '7', label: 'Aug' },
    { value: '8', label: 'Sep' },
    { value: '9', label: 'Oct' },
    { value: '10', label: 'Nov' },
    { value: '11', label: 'Dec' },
  ];

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => (currentYear - 2 + i).toString());

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    role: 'Lecturer',
    date: '',
    venue: '',
    audienceSize: 0,
    description: '',
  });

  useEffect(() => {
    if (!isAuthReady) return;
    if (!user) {
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, 'engagements'),
      where('professionalId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Engagement));
      setEngagements(data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'engagements');
    });

    return () => unsubscribe();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const promise = addDoc(collection(db, 'engagements'), {
      ...formData,
      professionalId: user.uid,
      status: 'logged',
      createdAt: serverTimestamp(),
    }).catch(error => handleFirestoreError(error, OperationType.CREATE, 'engagements'));

    toast.promise(promise, {
      loading: 'Logging engagement...',
      success: 'Engagement logged successfully!',
      error: 'Failed to log engagement.',
    });

    try {
      await promise;
      setIsModalOpen(false);
      setFormData({
        title: '',
        role: 'Lecturer',
        date: '',
        venue: '',
        audienceSize: 0,
        description: '',
      });
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    const promise = deleteDoc(doc(db, 'engagements', id));

    toast.promise(promise, {
      loading: 'Deleting log...',
      success: 'Engagement log deleted.',
      error: 'Failed to delete log.',
    });

    try {
      await promise;
      if (selectedEngagement?.id === id) {
        setIsDetailModalOpen(false);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, engagementId: string) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size must be less than 5MB');
      return;
    }

    setUploadStatuses(prev => ({ ...prev, [engagementId]: 'uploading' }));
    setUploadProgress(prev => ({ ...prev, [engagementId]: 0 }));

    try {
      let fileToUpload = file;

      // Only compress images that are somewhat large
      if (file.type.startsWith('image/') && file.size > 300 * 1024) {
        const options = {
          maxSizeMB: 1,
          maxWidthOrHeight: 1200,
          useWebWorker: false // Disable web worker as it can hang
        };
        try {
          fileToUpload = await imageCompression(file, options);
        } catch (e) {
          console.warn('Compression failed, uploading original', e);
        }
      }

      const storageRef = ref(storage, `certificates/${user.uid}/${engagementId}/${file.name}`);
      
      // Use uploadBytes for reliability
      await uploadBytes(storageRef, fileToUpload);
      const downloadURL = await getDownloadURL(storageRef);
      
      await updateDoc(doc(db, 'engagements', engagementId), {
        certificateUrl: downloadURL,
      });

      if (selectedEngagement && selectedEngagement.id === engagementId) {
        setSelectedEngagement({ ...selectedEngagement, certificateUrl: downloadURL });
      }
      
      setUploadStatuses(prev => ({ ...prev, [engagementId]: null }));
      setUploadProgress(prev => {
        const next = { ...prev };
        delete next[engagementId];
        return next;
      });
      toast.success('Certificate uploaded successfully!');
    } catch (err) {
      console.error('Error uploading file:', err);
      toast.error('Failed to upload certificate.');
      setUploadStatuses(prev => ({ ...prev, [engagementId]: 'error' }));
    }
  };

  const filteredEngagements = engagements.filter(e => {
    const date = new Date(e.date);
    const matchesStatus = statusFilter === 'all' ? true : e.status === statusFilter;
    const matchesMonth = selectedMonth === 'all' || date.getMonth().toString() === selectedMonth;
    const matchesYear = selectedYear === 'all' || date.getFullYear().toString() === selectedYear;
    const matchesSearch = (e.title || '').toLowerCase().includes((searchQuery || '').toLowerCase()) || 
                         (e.venue || '').toLowerCase().includes((searchQuery || '').toLowerCase()) ||
                         (e.role || '').toLowerCase().includes((searchQuery || '').toLowerCase());
    return matchesStatus && matchesMonth && matchesYear && matchesSearch;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-10 pb-12">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8 bg-white p-10 rounded-[3rem] border border-brand-100 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-50/30 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold text-brand-900 tracking-tight">Elite Engagement Logs</h1>
          <p className="text-brand-500 font-accent font-medium mt-2 text-lg">Curate and validate your professional legacy with precision.</p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 relative z-10">
          <div className="relative flex-1 sm:w-72">
            <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-brand-200" />
            <input 
              type="text"
              placeholder="Search engagements..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-brand-50/50 border border-brand-100 rounded-2xl text-[10px] font-accent font-bold uppercase tracking-widest focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
            />
          </div>
          <div className="relative">
            <Filter className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-brand-200" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="pl-12 pr-10 py-4 bg-brand-50/50 border border-brand-100 rounded-2xl text-[10px] font-accent font-bold text-brand-600 uppercase tracking-widest focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none appearance-none cursor-pointer"
            >
              <option value="all">All Status</option>
              <option value="logged">Logged</option>
              <option value="verified">Verified</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="btn-gold px-8 py-4 text-[10px]"
          >
            <Plus className="w-4 h-4 mr-3" />
            Log New Engagement
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {filteredEngagements.length > 0 ? (
          filteredEngagements.map((engagement) => (
            <motion.div
              key={engagement.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="premium-card p-8 group"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-4 mb-3">
                    <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight truncate">{engagement.title}</h3>
                    <span className={`px-4 py-1.5 text-[9px] font-accent font-bold uppercase tracking-[0.2em] rounded-full shadow-sm ${
                      engagement.status === 'verified' ? 'bg-brand-900 text-accent-400' : 
                      engagement.status === 'rejected' ? 'bg-red-50 text-red-700' :
                      'bg-brand-50 text-brand-600'
                    }`}>
                      {engagement.status}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-y-3 gap-x-8 text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">
                    <span className="text-accent-600 font-extrabold">{engagement.role}</span>
                    <span className="flex items-center"><CalendarIcon className="w-4 h-4 mr-2 text-brand-200" /> {new Date(engagement.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                    <span className="flex items-center"><MapPin className="w-4 h-4 mr-2 text-brand-200" /> {engagement.venue}</span>
                    <span className="flex items-center"><UsersIcon className="w-4 h-4 mr-2 text-brand-200" /> {Number(engagement.audienceSize) || 0} Professionals</span>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <button 
                    onClick={() => handleDelete(engagement.id)}
                    className="p-3 text-brand-200 hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                  {engagement.certificateUrl ? (
                    <a 
                      href={engagement.certificateUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-6 py-3 bg-brand-900 text-accent-400 hover:bg-brand-800 font-accent font-bold text-[10px] uppercase tracking-widest rounded-2xl transition-all shadow-lg shadow-brand-100"
                    >
                      <Award className="w-4 h-4 mr-3" />
                      View Credential
                    </a>
                  ) : (
                    <>
                      {uploadStatuses[engagement.id] === 'uploading' ? (
                        <div className="flex flex-col items-center min-w-[120px]">
                          <div className="w-full h-1.5 bg-brand-50 rounded-full overflow-hidden mb-1 relative">
                            <motion.div 
                              className="absolute inset-0 bg-accent-500" 
                              animate={{ x: ['-100%', '100%'] }}
                              transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                              style={{ width: '50%' }}
                            />
                          </div>
                          <span className="text-[8px] font-accent font-bold text-accent-600 uppercase tracking-widest animate-pulse">
                            Securing Dossier...
                          </span>
                        </div>
                      ) : (
                        <div className="p-3 text-brand-200 cursor-help" title="Open dossier to upload verification proof">
                          <Upload className="w-5 h-5" />
                        </div>
                      )}
                    </>
                  )}
                  <button 
                    onClick={() => {
                      setSelectedEngagement(engagement);
                      setIsDetailModalOpen(true);
                    }}
                    className="btn-secondary px-6 py-3 text-[10px]"
                  >
                    Dossier
                    <ArrowRight className="w-4 h-4 ml-3" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-24 bg-white rounded-[3rem] border-2 border-dashed border-brand-100">
            <div className="w-24 h-24 bg-brand-50 rounded-[2rem] flex items-center justify-center mx-auto mb-6">
              <FileText className="w-12 h-12 text-brand-100" />
            </div>
            <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">No records discovered</h3>
            <p className="text-brand-500 font-accent font-medium max-w-xs mx-auto mt-2 italic opacity-80">
              {searchQuery ? `No elite matches for "${searchQuery}"` : "Your professional history is awaiting its first entry."}
            </p>
            {(statusFilter !== 'all' || searchQuery) && (
              <button 
                onClick={() => { 
                  setStatusFilter('all'); 
                  setSearchQuery(''); 
                }}
                className="mt-8 text-accent-600 hover:text-accent-700 text-[10px] font-accent font-bold uppercase tracking-widest underline underline-offset-8 decoration-accent-200"
              >
                Reset Parameters
              </button>
            )}
          </div>
        )}
      </div>

      <AnimatePresence>
        {isDetailModalOpen && selectedEngagement && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsDetailModalOpen(false)}
              className="absolute inset-0 bg-brand-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[3rem] p-10 max-w-2xl w-full shadow-2xl overflow-hidden border border-brand-100"
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-accent-500" />
              <button 
                onClick={() => setIsDetailModalOpen(false)}
                className="absolute top-8 right-8 p-3 hover:bg-brand-50 rounded-2xl transition-all"
              >
                <X className="w-6 h-6 text-brand-300" />
              </button>

              <div className="space-y-10">
                <div>
                  <div className="flex items-center space-x-4 mb-3">
                    <h2 className="text-4xl font-display font-bold text-brand-900 tracking-tight">{selectedEngagement.title}</h2>
                    <span className={`px-4 py-1.5 text-[9px] font-accent font-bold uppercase tracking-[0.2em] rounded-full shadow-sm ${
                      selectedEngagement.status === 'verified' ? 'bg-brand-900 text-accent-400' : 
                      selectedEngagement.status === 'rejected' ? 'bg-red-50 text-red-700' :
                      'bg-brand-50 text-brand-600'
                    }`}>
                      {selectedEngagement.status}
                    </span>
                  </div>
                  <p className="text-accent-600 font-accent font-bold text-xl uppercase tracking-widest">{selectedEngagement.role}</p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                  <div className="bg-brand-50/50 p-5 rounded-[1.5rem] border border-brand-100">
                    <p className="text-[9px] text-brand-300 uppercase font-accent font-bold mb-2 tracking-widest">Date</p>
                    <p className="text-sm font-accent font-bold text-brand-900">{new Date(selectedEngagement.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                  </div>
                  <div className="bg-brand-50/50 p-5 rounded-[1.5rem] border border-brand-100">
                    <p className="text-[9px] text-brand-300 uppercase font-accent font-bold mb-2 tracking-widest">Venue</p>
                    <p className="text-sm font-accent font-bold text-brand-900 truncate">{selectedEngagement.venue}</p>
                  </div>
                  <div className="bg-brand-50/50 p-5 rounded-[1.5rem] border border-brand-100">
                    <p className="text-[9px] text-brand-300 uppercase font-accent font-bold mb-2 tracking-widest">Audience</p>
                    <p className="text-sm font-accent font-bold text-brand-900">{Number(selectedEngagement.audienceSize) || 0}</p>
                  </div>
                  <div className="bg-brand-50/50 p-5 rounded-[1.5rem] border border-brand-100">
                    <p className="text-[9px] text-brand-300 uppercase font-accent font-bold mb-2 tracking-widest">Logged</p>
                    <p className="text-sm font-accent font-bold text-brand-900">{new Date(selectedEngagement.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</p>
                  </div>
                </div>

                <div>
                  <p className="text-[10px] text-brand-300 uppercase font-accent font-bold mb-4 tracking-[0.2em]">Activity Dossier</p>
                  <div className="bg-brand-50/30 p-8 rounded-[2rem] border border-brand-100">
                    <p className="text-brand-600 leading-relaxed text-sm font-accent font-medium italic opacity-80">"{selectedEngagement.description}"</p>
                  </div>
                </div>

                <div className="pt-10 border-t border-brand-100">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-[10px] font-accent font-bold text-brand-900 uppercase tracking-widest flex items-center">
                      <Award className="w-5 h-5 mr-3 text-accent-600" />
                      Verification Credentials
                    </h4>
                    {selectedEngagement.status === 'verified' && (
                      <span className="flex items-center text-[9px] font-accent font-bold text-accent-600 uppercase tracking-widest">
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Authenticated by Elite Panel
                      </span>
                    )}
                  </div>
                  
                  {selectedEngagement.certificateUrl ? (
                    <div className="flex items-center justify-between p-6 bg-brand-900 rounded-[2rem] border border-brand-900 shadow-xl">
                      <div className="flex items-center">
                        <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center mr-5 shadow-inner">
                          <FileText className="w-7 h-7 text-accent-400" />
                        </div>
                        <div>
                          <p className="text-sm font-display font-bold text-white tracking-tight">Certificate of Excellence</p>
                          <p className="text-[9px] text-accent-400 font-accent font-bold uppercase tracking-[0.2em] mt-1">Encrypted & Verified</p>
                        </div>
                      </div>
                      <a 
                        href={selectedEngagement.certificateUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center px-6 py-3 bg-accent-500 text-white text-[10px] font-accent font-bold uppercase tracking-widest rounded-xl hover:bg-accent-600 transition-all shadow-lg shadow-accent-500/20"
                      >
                        Access Proof
                        <ExternalLink className="w-4 h-4 ml-3" />
                      </a>
                    </div>
                  ) : (
                    <div className="text-center p-12 border-2 border-dashed border-brand-100 rounded-[2.5rem] hover:border-accent-400 transition-all group relative bg-brand-50/30">
                      <input 
                        type="file" 
                        className="absolute inset-0 opacity-0 cursor-pointer z-10" 
                        onChange={(e) => handleFileUpload(e, selectedEngagement.id)}
                        disabled={uploadStatuses[selectedEngagement.id] === 'uploading'}
                      />
                      {uploadStatuses[selectedEngagement.id] === 'uploading' ? (
                        <div className="flex flex-col items-center">
                          <div className="w-20 h-20 border-4 border-brand-50 border-t-accent-500 rounded-full animate-spin mb-4 flex items-center justify-center" />
                          <p className="text-[10px] font-accent font-bold text-brand-500 uppercase tracking-widest animate-pulse">Synchronizing with Secure Cloud...</p>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center">
                          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mb-5 shadow-sm group-hover:scale-110 transition-all duration-500 border border-brand-50">
                            <Upload className="w-8 h-8 text-brand-100 group-hover:text-accent-600 transition-colors" />
                          </div>
                          <p className="text-sm font-display font-bold text-brand-900 tracking-tight">Transmit Verification Proof</p>
                          <p className="text-[10px] text-brand-300 mt-2 font-accent font-bold uppercase tracking-widest">PDF, PNG or JPG (Max 5MB)</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-brand-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[3rem] p-10 max-w-lg w-full shadow-2xl border border-brand-100"
            >
              <button 
                onClick={() => setIsModalOpen(false)}
                className="absolute top-8 right-8 p-3 hover:bg-brand-50 rounded-2xl transition-all"
              >
                <X className="w-6 h-6 text-brand-300" />
              </button>
              
              <h2 className="text-3xl font-display font-bold text-brand-900 tracking-tight mb-2">Log Engagement</h2>
              <p className="text-brand-500 font-accent font-medium mb-10 text-sm opacity-80 italic">Document your professional impact with elite precision.</p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="block text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Engagement Title</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Global Leadership Summit 2026"
                    className="block w-full px-5 py-4 rounded-2xl border-brand-100 bg-brand-50/50 focus:bg-white focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all text-sm font-accent font-medium"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="block text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Professional Role</label>
                    <select
                      className="block w-full px-5 py-4 rounded-2xl border-brand-100 bg-brand-50/50 focus:bg-white focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all text-sm font-accent font-bold text-brand-600 appearance-none cursor-pointer"
                      value={formData.role}
                      onChange={(e) => setFormData({ ...formData, role: e.target.value as any })}
                    >
                      <option>Lecturer</option>
                      <option>Speaker</option>
                      <option>Judge</option>
                      <option>Resource Person</option>
                      <option>Panelist</option>
                      <option>Guest Speaker</option>
                      <option>Consultant</option>
                      <option>Exhibitor</option>
                      <option>Moderator</option>
                      <option>Mentor</option>
                      <option>Trainer</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="block text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Commencement Date</label>
                    <input
                      type="date"
                      required
                      className="block w-full px-5 py-4 rounded-2xl border-brand-100 bg-brand-50/50 focus:bg-white focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all text-sm font-accent font-medium"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="block text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Elite Venue</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ritz-Carlton, Paris"
                      className="block w-full px-5 py-4 rounded-2xl border-brand-100 bg-brand-50/50 focus:bg-white focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all text-sm font-accent font-medium"
                      value={formData.venue}
                      onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="block text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Audience Magnitude</label>
                    <input
                      type="number"
                      required
                      className="block w-full px-5 py-4 rounded-2xl border-brand-100 bg-brand-50/50 focus:bg-white focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all text-sm font-accent font-medium"
                      value={formData.audienceSize || 0}
                      onChange={(e) => setFormData({ ...formData, audienceSize: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="block text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Professional Narrative</label>
                  <textarea
                    rows={3}
                    placeholder="Articulate your elite contribution..."
                    className="block w-full px-5 py-4 rounded-[2rem] border-brand-100 bg-brand-50/50 focus:bg-white focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all text-sm font-accent font-medium resize-none"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>
                <div className="flex justify-end space-x-4 pt-8">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-8 py-4 text-[10px] font-accent font-bold text-brand-400 bg-white border border-brand-100 rounded-2xl hover:bg-brand-50 transition-all uppercase tracking-widest"
                  >
                    Discard
                  </button>
                  <button
                    type="submit"
                    className="btn-gold px-10 py-4 text-[10px]"
                  >
                    Confirm Log
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
