import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { doc, getDoc, collection, query, where, getDocs, orderBy, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { User, Profile, Engagement } from '../types';
import { useAuth } from '../components/Auth/AuthContext';
import { 
  Star, 
  MapPin, 
  Briefcase, 
  Award, 
  Globe, 
  CheckCircle2,
  Calendar,
  Users,
  Sparkles,
  ArrowRight,
  Send,
  Linkedin,
  Mail as MailIcon,
  ChevronDown
} from 'lucide-react';
import { motion, useScroll, useSpring, AnimatePresence } from 'framer-motion';
import ExpertiseRadar from '../components/Analytics/ExpertiseRadar';
import ImpactSummarizer from '../components/Analytics/ImpactSummarizer';
import GlobalFootprintMap from '../components/Analytics/GlobalFootprintMap';

export default function PublicPortfolio() {
  const { id } = useParams<{ id: string }>();
  const { user, firebaseUser, isAuthReady } = useAuth();
  const [prof, setProf] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [engagements, setEngagements] = useState<Engagement[]>([]);
  const [loading, setLoading] = useState(true);
  const [isScrolled, setIsScrolled] = useState(false);

  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const fetchPortfolio = async () => {
      if (!id) return;
      try {
        const [userDoc, profileDoc] = await Promise.all([
          getDoc(doc(db, 'users', id)),
          getDoc(doc(db, 'profiles', id))
        ]);
        
        if (userDoc.exists()) {
          setProf({ uid: userDoc.id, ...userDoc.data() } as User);
        } else if (id === firebaseUser?.uid) {
          // Self-initialization for owner if missing
          console.log('Self-initializing missing portfolio identity...');
          const newUser = {
            uid: id,
            email: firebaseUser.email || '',
            displayName: firebaseUser.displayName || 'Elite Professional',
            role: 'Professional',
            isVerified: false,
            createdAt: serverTimestamp()
          };
          await setDoc(doc(db, 'users', id), newUser);
          setProf(newUser as any);
        }
        if (profileDoc.exists()) {
          setProfile(profileDoc.data() as Profile);
        }

        const engSnap = await getDocs(query(
          collection(db, 'engagements'),
          where('professionalId', '==', id),
          orderBy('date', 'desc')
        ));
        setEngagements(engSnap.docs.map(d => ({ id: d.id, ...d.data() } as Engagement)));
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchPortfolio();
  }, [id]);

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen bg-white">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
    </div>
  );

  if (!prof) return (
    <div className="text-center py-20 min-h-screen bg-white flex flex-col items-center justify-center space-y-10 px-6">
      <div className="relative">
        <div className="w-32 h-32 bg-brand-50 rounded-[2.5rem] flex items-center justify-center shadow-inner">
          <Sparkles className="w-16 h-16 text-brand-200" />
        </div>
        <div className="absolute -top-4 -right-4 w-12 h-12 bg-white rounded-full border border-brand-50 flex items-center justify-center shadow-lg">
          <Globe className="w-6 h-6 text-accent-500 animate-spin-slow" />
        </div>
      </div>
      
      <div className="space-y-4 max-w-md">
        <h2 className="text-4xl font-display font-bold text-brand-900 tracking-tight">Identity Not Found</h2>
        <p className="text-brand-400 font-accent font-medium leading-relaxed uppercase tracking-widest text-xs">
          The requested professional index does not exist in our elite network. They may have revoked public access or shifted their status.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-6">
        <Link to="/" className="btn-gold px-12 py-4 shadow-2xl shadow-accent-500/20">
          Establish New Identity
        </Link>
        <Link to="/search" className="btn-secondary px-12 py-4">
          Search Elite Network
        </Link>
      </div>
      
      <p className="text-[10px] font-accent font-bold text-brand-200 uppercase tracking-[0.4em] pt-10"> TrainerLog Elite Governance Protocol </p>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#FDFDFB] text-brand-900 selection:bg-accent-100 pb-12">
      {/* Progress Bar */}
      <motion.div 
        className="fixed top-0 left-0 right-0 h-1 bg-accent-500 z-[70] origin-left"
        style={{ scaleX }}
      />

      {/* Portfolio Header Bar */}
      <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 py-4 px-6 flex justify-between items-center ${
        isScrolled ? 'bg-white/80 backdrop-blur-md border-b border-brand-50 shadow-sm' : 'bg-transparent'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-brand-900 rounded-lg flex items-center justify-center text-accent-400 font-display font-bold text-xs ring-2 ring-accent-500/20">TL</div>
          <span className="text-[10px] font-accent font-bold uppercase tracking-[0.2em] text-brand-900">Elite Governance Protocol</span>
        </div>
        <div className="flex items-center gap-6">
          <Link to="/signup" className="hidden sm:flex text-[10px] font-accent font-bold text-brand-400 hover:text-accent-600 transition-all uppercase tracking-[0.2em] items-center gap-2 group">
            Establish Identity
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
          <a 
            href={`mailto:${prof?.email}?subject=Inquiry for Professional Engagement`}
            className="btn-gold px-6 py-2.5 text-[10px] flex items-center gap-2 ring-offset-2"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Secure Engagement</span>
            <span className="sm:hidden">Hire</span>
          </a>
        </div>
      </nav>

      {/* Floating LinkedIn Button */}
      <div className="fixed bottom-8 right-8 z-[50] flex flex-col gap-4 items-end">
        <AnimatePresence>
          {isScrolled && (
            <motion.a
              initial={{ scale: 0, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0, opacity: 0, y: 20 }}
              href={`https://www.linkedin.com/search/results/all/?keywords=${encodeURIComponent(prof?.displayName || '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 bg-brand-900 text-white rounded-full shadow-2xl shadow-brand-900/40 hover:scale-110 active:scale-95 transition-all group border border-brand-800"
              title="Find on LinkedIn"
            >
              <Linkedin className="w-6 h-6 text-accent-400 group-hover:text-white transition-colors" />
            </motion.a>
          )}
        </AnimatePresence>
      </div>

      <div className="pt-24 max-w-6xl mx-auto px-6 space-y-16">
        {/* Profile Card */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          className="bg-white p-12 md:p-16 rounded-[4rem] border border-brand-100 shadow-2xl relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-accent-50/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
          <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-brand-50 rounded-full blur-3xl opacity-50" />
          
          <div className="flex flex-col lg:flex-row gap-16 items-center lg:items-start text-center lg:text-left relative z-10">
            <div className="relative group">
              <div className="w-56 h-56 bg-brand-900 rounded-[3.5rem] flex items-center justify-center text-accent-400 text-8xl font-display font-bold overflow-hidden border-8 border-white shadow-2xl flex-shrink-0 transition-transform duration-700 group-hover:rotate-3 group-hover:scale-105">
                {prof?.photoURL ? (
                  <img src={prof.photoURL} alt={prof.displayName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  prof?.displayName[0]
                )}
              </div>
              <div className="absolute -bottom-4 -right-4 bg-emerald-500 p-3 rounded-2xl border-4 border-white shadow-lg animate-pulse">
                <CheckCircle2 className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="flex-1 space-y-8">
              <div className="space-y-4">
                <div className="flex items-center gap-6 justify-center lg:justify-start flex-wrap">
                  <h1 className="text-6xl md:text-8xl font-display font-bold text-brand-900 tracking-tighter leading-none italic">
                    {prof?.displayName?.split(' ')[0]}
                    <span className="gold-text-gradient block sm:inline sm:ml-4">{prof?.displayName?.split(' ').slice(1).join(' ')}</span>
                  </h1>
                </div>
                <div className="flex flex-wrap items-center justify-center lg:justify-start gap-y-4 gap-x-10 text-[10px] font-accent font-bold text-brand-400 uppercase tracking-[0.3em]">
                  <span className="flex items-center text-accent-600 bg-accent-50 px-4 py-1.5 rounded-full border border-accent-100">
                    <Star className="w-3.5 h-3.5 mr-2 fill-accent-500 text-accent-500" />
                    {profile?.averageRating ? `${profile.averageRating.toFixed(1)} Elite Rating` : 'Verified Leader'}
                  </span>
                  <span className="flex items-center group cursor-pointer hover:text-brand-900 transition-colors">
                    <MapPin className="w-4 h-4 mr-2 text-accent-500 transition-transform group-hover:-translate-y-1" />
                    {profile?.location || 'Global Presence'}
                  </span>
                  <span className="flex items-center group cursor-pointer hover:text-brand-900 transition-colors">
                    <Briefcase className="w-4 h-4 mr-2 text-accent-500 transition-transform group-hover:-translate-y-1" />
                    {prof?.role} / Expertise Certified
                  </span>
                </div>
              </div>
              <p className="text-brand-500 leading-relaxed font-accent font-medium text-xl md:text-2xl max-w-3xl italic opacity-90 border-l-4 border-accent-500 pl-8">
                "{profile?.bio || 'An elite professional dedicated to excellence and high-impact collaboration in the global education and training ecosystem.'}"
              </p>
              <div className="flex flex-wrap gap-4 justify-center lg:justify-start pt-4">
                {profile?.expertise.map((exp, i) => (
                  <motion.span 
                    key={i}
                    whileHover={{ scale: 1.05 }}
                    className="px-8 py-3 bg-brand-900 text-accent-400 text-[10px] font-accent font-bold uppercase rounded-full tracking-[0.2em] shadow-xl border border-brand-800"
                  >
                    {exp}
                  </motion.span>
                ))}
              </div>
            </div>
          </div>
          <motion.div 
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-20"
          >
            <span className="text-[8px] font-accent font-bold uppercase tracking-[0.4em]">Explore Impact</span>
            <ChevronDown className="w-4 h-4" />
          </motion.div>
        </motion.div>

        {/* Analytics Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ExpertiseRadar engagements={engagements} />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-12"
          >
            <GlobalFootprintMap engagements={engagements} />
            <ImpactSummarizer engagements={engagements} profile={profile} />
          </motion.div>
        </div>

        {/* Experience & Achievements */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2 space-y-12">
            <section className="bg-white p-12 rounded-[3.5rem] border border-brand-100 shadow-xl space-y-12">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-display font-bold text-brand-900 tracking-tight flex items-center">
                  <Briefcase className="w-8 h-8 mr-5 text-accent-500" />
                  Professional Legacy
                </h2>
                <div className="h-px flex-1 bg-brand-50 mx-10 hidden sm:block" />
              </div>
              
              <div className="space-y-12">
                {profile?.experience.length === 0 ? (
                  <div className="text-center py-20 bg-brand-50/30 rounded-[3rem] border border-brand-50 border-dashed">
                    <p className="text-brand-300 italic font-accent font-bold uppercase tracking-[0.3em] text-[10px]">Awaiting documentation of triumphs.</p>
                  </div>
                ) : (
                  profile?.experience.map((exp) => (
                    <div key={exp.id} className="flex gap-10 group relative">
                      <div className="w-20 h-20 bg-brand-50 rounded-[2rem] flex items-center justify-center flex-shrink-0 border border-brand-100 group-hover:scale-110 transition-transform duration-500 shadow-md">
                        <Award className="w-10 h-10 text-brand-200" />
                      </div>
                      <div className="space-y-4">
                        <h4 className="text-2xl font-display font-bold text-brand-900 group-hover:text-accent-600 transition-colors">{exp.title}</h4>
                        <div className="flex flex-wrap items-center gap-6 text-[10px] font-accent font-bold text-brand-300 uppercase tracking-widest">
                          <span className="text-brand-700">{exp.company}</span>
                          <div className="w-1.5 h-1.5 bg-brand-200 rounded-full" />
                          <span>{exp.location}</span>
                          <div className="w-1.5 h-1.5 bg-brand-200 rounded-full" />
                          <span className="text-accent-600 font-extrabold">
                            {new Date(exp.startDate).getFullYear()} - {exp.current ? 'PRESENT' : exp.endDate ? new Date(exp.endDate).getFullYear() : ''}
                          </span>
                        </div>
                        <p className="text-lg text-brand-500 leading-relaxed font-accent font-medium opacity-80">{exp.description}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </section>

            {/* Verified Engagements Showcase */}
            <section className="bg-white p-12 rounded-[3.5rem] border border-brand-100 shadow-xl space-y-12">
              <h2 className="text-3xl font-display font-bold text-brand-900 tracking-tight flex items-center">
                <Calendar className="w-8 h-8 mr-5 text-accent-500" />
                Verified Engagement History
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {engagements.filter(e => e.status === 'verified').slice(0, 4).map((eng) => (
                  <div key={eng.id} className="p-8 bg-brand-50/50 rounded-[2.5rem] border border-brand-100 hover:bg-white hover:shadow-2xl transition-all duration-500 group">
                    <div className="flex items-center justify-between mb-6">
                      <span className="text-[9px] font-accent font-bold text-accent-600 uppercase tracking-[0.2em] bg-accent-50 px-3 py-1 rounded-full border border-accent-100 group-hover:bg-accent-600 group-hover:text-white transition-colors">
                        {eng.role}
                      </span>
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    </div>
                    <h4 className="text-xl font-display font-bold text-brand-900 mb-2 truncate group-hover:text-accent-600 transition-colors">{eng.title}</h4>
                    <p className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-widest mb-4">
                      {new Date(eng.date).toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}
                    </p>
                    <div className="flex items-center gap-4 text-[10px] font-accent font-bold text-brand-400">
                      <Users className="w-4 h-4 text-brand-200" />
                      Reach: {eng.audienceSize} attendees
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <div className="space-y-12">
            {/* Elite Stats Circle */}
            <div className="bg-brand-900 p-12 rounded-[3.5rem] text-center text-white space-y-6 shadow-2xl relative overflow-hidden group">
              <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,rgba(201,162,63,0.15)_0,transparent_100%)]" />
              <p className="text-[10px] font-accent font-bold uppercase tracking-[0.3em] text-accent-400">Engagement Score</p>
              <div className="inline-flex items-center justify-center w-32 h-32 rounded-full border-4 border-accent-500/30 relative">
                <div className="absolute inset-0 rounded-full border-4 border-accent-500 border-t-transparent animate-[spin_3s_linear_infinite]" />
                <span className="text-5xl font-display font-bold text-accent-400">
                  {Math.min(engagements.length * 5, 100)}
                </span>
              </div>
              <p className="text-xs font-accent font-medium text-brand-200 max-w-[200px] mx-auto italic">
                Performance computed based on verified audience impact and peer reviews.
              </p>
            </div>

            {/* Core Competencies */}
            <section className="bg-white p-10 rounded-[2.5rem] border border-brand-100 shadow-lg space-y-10">
              <h2 className="text-xl font-display font-bold text-brand-900 tracking-tight flex items-center">
                <Award className="w-6 h-6 mr-4 text-accent-500" />
                Specialized Core
              </h2>
              <div className="flex flex-wrap gap-3">
                {profile?.skills.map((skill, i) => (
                  <span key={i} className="px-5 py-2.5 bg-brand-50 text-brand-600 text-[10px] font-accent font-bold uppercase rounded-xl border border-brand-100 tracking-widest hover:border-accent-400 hover:text-accent-600 transition-all cursor-default">
                    {skill}
                  </span>
                ))}
              </div>
            </section>

            {/* Credentials */}
            <section className="bg-white p-10 rounded-[2.5rem] border border-brand-100 shadow-lg space-y-8">
              <h2 className="text-xl font-display font-bold text-brand-900 tracking-tight flex items-center">
                <Globe className="w-6 h-6 mr-4 text-accent-500" />
                Global Credentials
              </h2>
              <div className="space-y-4">
                {profile?.certifications.map((cert) => (
                  <div key={cert.id} className="flex items-center space-x-5 p-6 bg-brand-50/50 rounded-2xl border border-brand-100 group hover:bg-white hover:shadow-xl transition-all">
                    <div className="p-3 bg-brand-900 rounded-xl shadow-lg group-hover:rotate-12 transition-transform">
                      <Award className="w-6 h-6 text-accent-400" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-display font-bold text-brand-900 truncate">{cert.name}</p>
                      <p className="text-[9px] text-brand-400 font-accent font-bold uppercase tracking-widest mt-1 italic">{cert.issuer}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>

        {/* Footer */}
        <footer className="pt-12 text-center border-t border-brand-50">
          <div className="inline-flex items-center gap-3 p-4 bg-white rounded-2xl border border-brand-100 shadow-sm transition-transform hover:scale-105">
            <span className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-widest">Powered by</span>
            <div className="w-6 h-6 bg-brand-900 rounded flex items-center justify-center text-accent-400 font-display font-bold text-[8px]">TL</div>
            <span className="text-[10px] font-accent font-bold text-brand-900 uppercase tracking-widest">TrainerLog Elite</span>
          </div>
          <p className="mt-8 text-[9px] font-accent font-bold text-brand-200 uppercase tracking-[0.4em]">© 2024 Elite Professional Governance Protocol</p>
        </footer>
      </div>
    </div>
  );
}
