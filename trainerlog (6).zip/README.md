# TrainerLog - Project Setup

This project is a full-stack application built with React (Frontend) and Express (Backend).

## Prerequisites

- Node.js (v18 or higher recommended)
- npm (v9 or higher recommended)

## Installation

1. **Extract the project** to your desired folder.
2. **Open your terminal** (Command Prompt or PowerShell on Windows).
3. **Navigate to the project folder**:
   ```bash
   cd path/to/trainer-log
   ```
4. **Install dependencies**:
   ```bash
   npm install --legacy-peer-deps
   ```
   *Note: Using `--legacy-peer-deps` is recommended to avoid version conflicts with older map libraries.*

## Configuration

### 🔑 THE .env FILE (CRITICAL)
The project **MUST** have a `.env` file in the root directory for the AI features (Narrative Synthesis) to work. 
I have created this file for you. **DO NOT DELETE IT.**

If you accidentally delete it, create a new file named `.env` and paste this inside:
```env
GEMINI_API_KEY=AIzaSyA67B7iIatsjqH32TDNLZcxMBBuEV0Bqio
NODE_ENV=development
```

Without this file, you will see "Narrative Synthesis Failed" errors in the browser.

## Running the Application

### Development Mode

To start the development server:
```bash
npm run dev
```
Once you see "Frontend environment stabilized", open your browser to:
`http://localhost:3000`

### Production Build

If you want to simulate a full production environment:
```bash
npm run build
npm start
```

## Troubleshooting

- **Node Version**: Ensure you are using a compatible Node.js version.
- **Port Conflict**: The server runs on port 3000. Ensure no other application is using this port.
- **Dependency Issues**: Always try deleting `node_modules` and `package-lock.json` before running `npm install` again if you face persistent errors.
