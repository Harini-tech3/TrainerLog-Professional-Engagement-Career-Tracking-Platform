import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  UserCircle, 
  Briefcase, 
  Mail, 
  Settings, 
  LogOut,
  ShieldCheck,
  Calendar,
  Search,
  ChevronRight,
  Zap
} from 'lucide-react';
import { useAuth } from '../Auth/AuthContext';
import { useLayout } from './LayoutContext';
import { auth, db } from '../../firebase';
import { cn } from '../../lib/utils';
import { motion } from 'framer-motion';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { Invitation } from '../../types';

export default function Sidebar() {
  const { user } = useAuth();
  const { isSidebarOpen: isOpen, setIsSidebarOpen: setIsOpen } = useLayout();
  const [invitationCount, setInvitationCount] = React.useState(0);

  React.useEffect(() => {
    if (!user?.uid) return;
    const q = query(
      collection(db, 'invitations'),
      where('professionalId', '==', user.uid),
      where('status', '==', 'pending')
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setInvitationCount(snapshot.size);
    });
    return () => unsubscribe();
  }, [user?.uid]);

  const navItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/' },
    ...(user?.role === 'Professional' ? [
      { name: 'Invitations', icon: Mail, path: '/invitations', badge: invitationCount },
      { name: 'Engagements', icon: Briefcase, path: '/engagements' },
    ] : []),
    { name: 'Profile', icon: UserCircle, path: '/profile' },
    ...(user?.role === 'Organizer' ? [
      { name: 'My Events', icon: Calendar, path: '/events' },
      { name: 'Find Professionals', icon: Search, path: '/search' },
      { name: 'Collaborations', icon: Mail, path: '/collaborations' },
    ] : []),
    ...(user?.role === 'Admin' ? [
      { name: 'Admin Panel', icon: ShieldCheck, path: '/admin' },
    ] : []),
    { name: 'Settings', icon: Settings, path: '/settings' },
  ];

  return (
    <>
      {/* Mobile Menu Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="lg:hidden fixed bottom-6 right-6 z-50 w-14 h-14 bg-brand-600 text-white rounded-full shadow-2xl flex items-center justify-center hover:bg-brand-700 transition-all active:scale-95 shadow-brand-200"
      >
        <LayoutDashboard className="w-6 h-6" />
      </button>

      {/* Sidebar Container */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-40 w-72 bg-white flex flex-col transition-transform duration-300 lg:h-full lg:border-none border-r border-slate-200 shadow-sm lg:shadow-none",
        isOpen ? "translate-x-0" : "-translate-x-full",
        "lg:static lg:translate-x-0"
      )}>
        <div className="p-8">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-brand-900 rounded-xl flex items-center justify-center shadow-xl shadow-brand-900/20 border border-brand-800">
              <Zap className="w-6 h-6 text-accent-400" />
            </div>
            <div>
              <h1 className="text-xl font-display font-bold text-brand-900 tracking-tight">TrainerLog</h1>
              <p className="text-[10px] font-accent font-bold text-accent-600 uppercase tracking-[0.2em]">Elite Network</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-6 space-y-2 overflow-y-auto scrollbar-hide">
          <p className="px-4 text-[10px] font-accent font-bold text-brand-400 uppercase tracking-[0.2em] mb-4">Management</p>
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={() => setIsOpen(false)}
              className={({ isActive }) => cn(
                "nav-link-premium group",
                isActive 
                  ? "bg-brand-900 text-white shadow-2xl shadow-brand-900/20" 
                  : "text-brand-500 hover:bg-brand-50 hover:text-brand-900"
              )}
            >
              {({ isActive }) => (
                <>
                  <div className="flex items-center">
                    <item.icon className={cn("w-5 h-5 mr-4 transition-colors", isActive ? "text-accent-400" : "text-brand-300 group-hover:text-brand-900")} />
                    {item.name}
                    {item.badge > 0 && (
                      <span className={cn(
                        "ml-3 px-2 py-0.5 text-[10px] font-accent font-bold rounded-full",
                        isActive ? "bg-accent-500 text-white" : "bg-brand-100 text-brand-600"
                      )}>
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <ChevronRight className={cn("w-4 h-4 transition-transform duration-300", isActive ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0")} />
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="p-8 mt-auto">
          <div className="bg-brand-50 rounded-3xl p-5 mb-4 border border-brand-100 shadow-sm">
            <div className="flex items-center space-x-4 mb-4">
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-brand-900 font-display font-bold text-xl overflow-hidden border border-brand-200 shadow-sm">
                  {user?.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName} className="w-full h-full object-cover" />
                  ) : (
                    user?.displayName?.[0] || 'U'
                  )}
                </div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full shadow-sm" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-accent font-bold text-brand-900 truncate">{user?.displayName}</p>
                <p className="text-[10px] font-accent font-bold text-accent-600 uppercase tracking-wider">{user?.role}</p>
              </div>
            </div>
            <button
              onClick={() => auth.signOut()}
              className="flex items-center justify-center w-full px-4 py-3 text-xs font-accent font-bold text-brand-600 bg-white rounded-xl hover:bg-brand-900 hover:text-white transition-all duration-300 border border-brand-200 shadow-sm hover:shadow-md"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </button>
          </div>
          <p className="text-[9px] text-center text-brand-300 font-accent font-bold uppercase tracking-widest">© 2026 TrainerLog Elite</p>
        </div>
      </div>

      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-30 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}
