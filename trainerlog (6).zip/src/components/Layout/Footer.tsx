import React from 'react';

export default function Footer() {
  return (
    <footer className="mt-16 pt-8 border-t border-brand-100 text-center pb-8">
      <div className="flex flex-col items-center gap-4">
        <div className="inline-flex items-center gap-3 px-5 py-2 bg-white rounded-2xl border border-brand-100 shadow-sm transition-all hover:shadow-lg">
          <div className="w-7 h-7 bg-brand-900 rounded-lg flex items-center justify-center text-accent-400 font-display font-bold text-[9px]">TL</div>
          <span className="text-[9px] font-accent font-bold text-brand-400 uppercase tracking-[0.3em]">TrainerLog Elite Governance</span>
        </div>
        <p className="text-[8px] font-accent font-bold text-brand-200 uppercase tracking-[0.4em] opacity-40">© 2026 Proprietary Professional Ecosystem • All Rights Reserved</p>
      </div>
    </footer>
  );
}
