import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { doc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { User, Profile, Experience, Certification } from '../types';
import { 
  Star, 
  MapPin, 
  Briefcase, 
  Award, 
  Globe, 
  Mail, 
  ChevronLeft,
  CheckCircle2,
  GraduationCap,
  BookOpen
} from 'lucide-react';
import { motion } from 'framer-motion';
import ReviewSystem from '../components/Reviews/ReviewSystem';
import { useAuth } from '../components/Auth/AuthContext';
import { cn } from '../lib/utils';

export default function ProfessionalProfile() {
  const { id } = useParams<{ id: string }>();
  const { user: currentUser } = useAuth();
  const [prof, setProf] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFullProfile = async () => {
      if (!id) return;
      try {
        const userDoc = await getDoc(doc(db, 'users', id));
        const profileDoc = await getDoc(doc(db, 'profiles', id));
        
        if (userDoc.exists()) {
          setProf({ uid: userDoc.id, ...userDoc.data() } as User);
        }
        if (profileDoc.exists()) {
          setProfile(profileDoc.data() as Profile);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchFullProfile();
  }, [id]);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
  );

  if (!prof) return (
    <div className="text-center py-20">
      <h2 className="text-2xl font-bold text-gray-900">Professional not found</h2>
      <Link to="/search" className="text-indigo-600 font-bold hover:underline mt-4 block">Back to Search</Link>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-20">
      <Link 
        to="/search" 
        className="inline-flex items-center text-[10px] font-accent font-bold text-brand-300 hover:text-accent-600 transition-all uppercase tracking-[0.2em] group"
      >
        <ChevronLeft className="w-4 h-4 mr-2 transition-transform group-hover:-translate-x-1" />
        Back to Elite Search
      </Link>

      <div className="bg-white p-12 rounded-[3rem] border border-brand-100 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent-50/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        
        <div className="flex flex-col md:flex-row gap-12 items-start relative z-10">
          <div className="w-40 h-40 bg-brand-900 rounded-[2.5rem] flex items-center justify-center text-accent-400 text-6xl font-display font-bold overflow-hidden border-4 border-white shadow-2xl flex-shrink-0">
            {prof.photoURL ? (
              <img src={prof.photoURL} alt={prof.displayName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              prof.displayName[0]
            )}
          </div>
          <div className="flex-1 space-y-6">
            <div>
              <div className="flex items-center space-x-4">
                <h1 className="text-5xl font-display font-bold text-brand-900 tracking-tight">{prof.displayName}</h1>
                <CheckCircle2 className="w-8 h-8 text-emerald-500 shadow-sm" />
              </div>
              <div className="flex flex-wrap items-center gap-y-3 gap-x-8 mt-4 text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">
                <span className="flex items-center text-accent-600">
                  <Star className="w-4 h-4 mr-2 fill-accent-500 text-accent-500" />
                  {profile?.averageRating ? `${profile.averageRating.toFixed(1)} Elite Rating` : 'New Professional'}
                </span>
                <span className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2 text-accent-500" />
                  {profile?.location || 'Global / Remote'}
                </span>
                <span className="flex items-center text-brand-900">
                  <Briefcase className="w-4 h-4 mr-2 text-accent-500" />
                  ${profile?.hourlyRate || 0} <span className="text-brand-300 ml-1">/ hour</span>
                </span>
              </div>
            </div>
            <p className="text-brand-500 leading-relaxed font-accent font-medium text-lg max-w-3xl italic opacity-80">
              "{profile?.bio || 'An elite professional dedicated to excellence and high-impact collaboration.'}"
            </p>
            <div className="flex flex-wrap gap-3">
              {profile?.expertise.map((exp, i) => (
                <span key={i} className="px-5 py-2 bg-brand-900 text-accent-400 text-[9px] font-accent font-bold uppercase rounded-full tracking-[0.2em] shadow-sm">
                  {exp}
                </span>
              ))}
            </div>
          </div>
          <div className="w-full md:w-auto pt-4 md:pt-0">
            <Link 
              to={`/search?invite=${prof.uid}`}
              className="btn-gold w-full md:w-auto px-10 py-5 text-[10px]"
            >
              <Mail className="w-5 h-5 mr-3" />
              Secure Talent
            </Link>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          {/* Experience */}
          <section className="bg-white p-12 rounded-[3rem] border border-brand-100 shadow-xl space-y-10">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-display font-bold text-brand-900 tracking-tight flex items-center">
                <Briefcase className="w-7 h-7 mr-4 text-accent-500" />
                Professional Legacy
              </h2>
              <div className="h-px flex-1 bg-brand-50 mx-8" />
            </div>
            <div className="space-y-12">
              {profile?.experience.length === 0 ? (
                <div className="text-center py-10 bg-brand-50/30 rounded-[2rem] border border-brand-50">
                  <p className="text-brand-300 italic font-accent font-bold uppercase tracking-widest text-xs">Awaiting documentation of professional triumphs.</p>
                </div>
              ) : (
                profile?.experience.map((exp) => (
                  <div key={exp.id} className="flex gap-8 group">
                    <div className="w-16 h-16 bg-brand-50 rounded-2xl flex items-center justify-center flex-shrink-0 border border-brand-100 group-hover:scale-110 transition-transform duration-500 shadow-sm">
                      <Briefcase className="w-8 h-8 text-brand-200" />
                    </div>
                    <div className="space-y-3">
                      <h4 className="text-xl font-display font-bold text-brand-900 group-hover:text-accent-600 transition-colors">{exp.title}</h4>
                      <div className="flex items-center gap-4 text-[10px] font-accent font-bold text-brand-300 uppercase tracking-widest">
                        <span className="text-brand-600">{exp.company}</span>
                        <div className="w-1 h-1 bg-brand-200 rounded-full" />
                        <span>{exp.location}</span>
                      </div>
                      <p className="text-[10px] text-accent-600 font-accent font-bold uppercase tracking-[0.2em]">
                        {new Date(exp.startDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })} - {exp.current ? 'Present' : exp.endDate ? new Date(exp.endDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : 'N/A'}
                      </p>
                      <p className="text-base text-brand-500 leading-relaxed font-accent font-medium opacity-80">{exp.description}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>

          {/* Reviews */}
          <section className="bg-white p-12 rounded-[3rem] border border-brand-100 shadow-xl">
            <ReviewSystem 
              professionalId={prof.uid} 
              canReview={currentUser?.role === 'Organizer'} 
            />
          </section>
        </div>

        <div className="space-y-12">
          {/* Skills */}
          <section className="bg-white p-10 rounded-[2.5rem] border border-brand-100 shadow-lg space-y-8">
            <h2 className="text-xl font-display font-bold text-brand-900 tracking-tight flex items-center">
              <Award className="w-6 h-6 mr-4 text-accent-500" />
              Core Competencies
            </h2>
            <div className="flex flex-wrap gap-3">
              {profile?.skills.map((skill, i) => (
                <span key={i} className="px-4 py-2 bg-brand-50 text-brand-600 text-[10px] font-accent font-bold uppercase rounded-xl border border-brand-100 tracking-widest">
                  {skill}
                </span>
              ))}
            </div>
          </section>

          {/* Certifications */}
          <section className="bg-white p-10 rounded-[2.5rem] border border-brand-100 shadow-lg space-y-8">
            <h2 className="text-xl font-display font-bold text-brand-900 tracking-tight flex items-center">
              <GraduationCap className="w-6 h-6 mr-4 text-accent-500" />
              Elite Credentials
            </h2>
            <div className="space-y-4">
              {profile?.certifications.length === 0 ? (
                <p className="text-brand-300 italic font-accent font-bold uppercase tracking-widest text-[10px] text-center py-6 bg-brand-50/30 rounded-2xl border border-brand-50">No credentials documented.</p>
              ) : (
                profile?.certifications.map((cert) => (
                  <div key={cert.id} className="flex items-center space-x-4 p-5 bg-brand-50/50 rounded-2xl border border-brand-100 hover:bg-white hover:shadow-md transition-all group">
                    <div className="p-3 bg-white rounded-xl shadow-sm group-hover:text-accent-600 transition-colors">
                      <Award className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-display font-bold text-brand-900 truncate">{cert.name}</p>
                      <p className="text-[9px] text-brand-400 font-accent font-bold uppercase tracking-widest mt-1">{cert.issuer}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>

          {/* Web Presence */}
          <section className="bg-white p-10 rounded-[2.5rem] border border-brand-100 shadow-lg space-y-8">
            <h2 className="text-xl font-display font-bold text-brand-900 tracking-tight flex items-center">
              <Globe className="w-6 h-6 mr-4 text-accent-500" />
              Digital Footprint
            </h2>
            <div className="space-y-3">
              {profile?.portfolioLinks.map((link, i) => (
                <a 
                  key={i} 
                  href={link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center p-4 bg-brand-50/50 rounded-2xl border border-brand-100 text-[10px] font-accent font-bold text-brand-600 uppercase tracking-widest hover:bg-white hover:shadow-md hover:text-accent-600 transition-all truncate group"
                >
                  <Globe className="w-4 h-4 mr-3 text-brand-200 group-hover:text-accent-500 transition-colors" />
                  {link.replace(/^https?:\/\/(www\.)?/, '')}
                </a>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
