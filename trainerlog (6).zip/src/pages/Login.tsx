import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';
import { motion } from 'framer-motion';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate('/');
    } catch (err: any) {
      setError('Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FDFDFB] py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-accent-50/50 rounded-full blur-3xl" />
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-brand-50 rounded-full blur-3xl" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full space-y-12 bg-white p-12 rounded-[3.5rem] shadow-2xl relative z-10 border border-brand-100"
      >
        <div className="text-center">
          <div className="inline-flex items-center justify-center p-4 bg-brand-900 rounded-3xl shadow-xl mb-8 border border-brand-800">
            <span className="text-accent-400 font-display font-bold text-2xl tracking-tighter">TL</span>
          </div>
          <h2 className="text-4xl font-display font-bold text-brand-900 tracking-tight">
            Elite Access
          </h2>
          <p className="mt-4 text-brand-500 font-accent font-medium text-lg italic opacity-80">
            Re-enter the professional orchestration.
          </p>
        </div>
        
        <form className="space-y-8" onSubmit={handleLogin}>
          {error && (
            <motion.div 
              initial={{ opacity: 0, x: -10 }} 
              animate={{ opacity: 1, x: 0 }}
              className="bg-red-50 text-red-600 p-4 rounded-2xl text-xs font-accent font-bold uppercase tracking-widest border border-red-100"
            >
              {error}
            </motion.div>
          )}
          
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Email Identity</label>
              <input
                type="email"
                required
                placeholder="architect@elite.com"
                className="w-full px-6 py-4 bg-brand-50/30 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Secure Protocol</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                className="w-full px-6 py-4 bg-brand-50/30 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-6 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="btn-gold w-full py-5 text-[10px]"
            >
              {loading ? 'Authenticating...' : 'Commence Session'}
            </button>
            
            <div className="text-center">
              <Link to="/signup" className="text-[10px] font-accent font-bold text-brand-400 hover:text-accent-600 transition-colors uppercase tracking-[0.2em] underline underline-offset-8">
                Initiate New Account
              </Link>
            </div>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
