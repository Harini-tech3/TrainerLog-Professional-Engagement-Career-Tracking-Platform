export type UserRole = 'Professional' | 'Organizer' | 'Admin';

export interface User {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  photoURL?: string;
  createdAt: string;
  isVerified: boolean;
}

export interface Experience {
  id: string;
  title: string;
  company: string;
  location: string;
  startDate: string;
  endDate?: string;
  current: boolean;
  description: string;
}

export interface Certification {
  id: string;
  name: string;
  issuer: string;
  issueDate: string;
  expiryDate?: string;
  credentialId?: string;
  credentialUrl?: string;
}

export interface Profile {
  uid: string;
  bio: string;
  expertise: string[];
  skills: string[];
  experience: Experience[];
  certifications: Certification[];
  portfolioLinks: string[];
  location?: string;
  hourlyRate?: number;
  averageRating?: number;
  reviewCount?: number;
}

export interface Review {
  id: string;
  professionalId: string;
  organizerId: string;
  engagementId?: string;
  rating: number;
  comment: string;
  organizerName: string;
  createdAt: string;
}

export interface Engagement {
  id: string;
  professionalId: string;
  organizerId?: string;
  title: string;
  role: 'Lecturer' | 'Speaker' | 'Judge' | 'Resource Person';
  date: string;
  venue: string;
  audienceSize: number;
  description: string;
  status: 'logged' | 'verified' | 'rejected';
  certificateUrl?: string;
  createdAt: string;
}

export interface Invitation {
  id: string;
  eventId?: string;
  professionalId: string;
  organizerId: string;
  organizerName?: string;
  eventTitle?: string;
  status: 'pending' | 'accepted' | 'rejected';
  message: string;
  priority?: 'high' | 'medium' | 'low';
  createdAt: string;
}

export interface Event {
  id: string;
  organizerId: string;
  title: string;
  date: string;
  location: string;
  description: string;
  requiredExpertise: string[];
  status: 'open' | 'closed' | 'upcoming';
  createdAt: string;
  category?: string;
  tags?: string[];
  expectedAudience?: number;
}

export interface Notification {
  id: string;
  userId: string;
  content: string;
  type: string;
  read: boolean;
  createdAt: string;
}

export interface Reminder {
  id: string;
  userId: string;
  eventId: string;
  eventTitle: string;
  type: '1_day_before' | '1_hour_before' | 'custom';
  deliveryMethod: 'in_app';
  remindAt: string;
  createdAt: string;
  sent: boolean;
}
