import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { collection, query, where, getDocs, addDoc, onSnapshot, setDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../components/Auth/AuthContext';
import { User, Profile, Event } from '../types';
import { 
  Search, 
  Filter, 
  Mail, 
  Award, 
  User as UserIcon, 
  MapPin, 
  Briefcase, 
  Star,
  ChevronRight,
  X,
  Send,
  Calendar,
  Info,
  CheckCircle2,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { cn } from '../lib/utils';

export default function SearchProfessionals() {
  const { user: currentUser, firebaseUser } = useAuth();
  const [professionals, setProfessionals] = useState<(User & { profile?: Profile })[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedProf, setSelectedProf] = useState<(User & { profile?: Profile }) | null>(null);
  const [selectedEventId, setSelectedEventId] = useState('');
  const [inviteMessage, setInviteMessage] = useState('');
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  const [minRating, setMinRating] = useState(0);
  const [maxHourlyRate, setMaxHourlyRate] = useState(1000);
  const [locationFilter, setLocationFilter] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  useEffect(() => {
    const fetchProfessionals = async () => {
      try {
        const q = query(collection(db, 'users'), where('role', '==', 'Professional'));
        const snapshot = await getDocs(q);
        const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as unknown as User));
        
        const enriched = await Promise.all(users.map(async (u) => {
          const profileDoc = await getDocs(query(collection(db, 'profiles'), where('uid', '==', u.uid)));
          return { ...u, profile: !profileDoc.empty ? profileDoc.docs[0].data() as Profile : undefined };
        }));

        setProfessionals(enriched);
      } catch (err) {
        console.error(err);
        toast.error('Failed to fetch professionals');
      } finally {
        setLoading(false);
      }
    };

    const fetchEvents = () => {
      const effectiveUid = currentUser?.uid || firebaseUser?.uid;
      if (!effectiveUid) return;
      const q = query(collection(db, 'events'), where('organizerId', '==', effectiveUid));
      return onSnapshot(q, (snapshot) => {
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Event));
        setEvents(data);
      });
    };

    fetchProfessionals();
    const unsubscribeEvents = fetchEvents();
    return () => unsubscribeEvents?.();
  }, [currentUser, firebaseUser]);

  const handleInvite = async () => {
    if (!currentUser || !selectedProf || !selectedEventId) {
      toast.error('Please select an event');
      return;
    }

    try {
      await addDoc(collection(db, 'invitations'), {
        professionalId: selectedProf.uid,
        organizerId: currentUser.uid,
        eventId: selectedEventId,
        status: 'pending',
        message: inviteMessage || `I would like to invite you to collaborate on my event: ${events.find(e => e.id === selectedEventId)?.title}`,
        createdAt: new Date().toISOString(),
      });
      
      toast.success(`Invitation sent to ${selectedProf.displayName}`);
      setIsInviteModalOpen(false);
      setSelectedProf(null);
      setSelectedEventId('');
      setInviteMessage('');
    } catch (err) {
      console.error(err);
      toast.error('Failed to send invitation');
    }
  };

  const seedExampleProfessionals = async () => {
    try {
      const examples = [
        {
          uid: 'prof-1',
          displayName: 'Sarah Johnson',
          email: 'sarah.j@example.com',
          role: 'Professional',
          expertise: ['Leadership', 'Public Speaking'],
          skills: ['Communication', 'Strategy'],
          bio: 'International keynote speaker with 15+ years of experience in leadership development.'
        },
        {
          uid: 'prof-2',
          displayName: 'Marcus Chen',
          email: 'm.chen@example.com',
          role: 'Professional',
          expertise: ['Digital Transformation', 'AI'],
          skills: ['Machine Learning', 'Cloud Architecture'],
          bio: 'Tech visionary helping organizations navigate the future of AI and digital ecosystems.'
        }
      ];

      for (const ex of examples) {
        // Create user
        await setDoc(doc(db, 'users', ex.uid), {
          uid: ex.uid,
          displayName: ex.displayName,
          email: ex.email,
          role: ex.role,
          createdAt: new Date().toISOString()
        }, { merge: true });

        // Create profile
        await setDoc(doc(db, 'profiles', ex.uid), {
          uid: ex.uid,
          bio: ex.bio,
          expertise: ex.expertise,
          skills: ex.skills,
          experience: [],
          certifications: [],
          portfolioLinks: []
        }, { merge: true });
      }

      toast.success('Example professionals seeded! Refreshing...');
      window.location.reload();
    } catch (err) {
      console.error(err);
      toast.error('Failed to seed example professionals');
    }
  };

  const filtered = professionals.filter(p => {
    const matchesSearch = (p.displayName || '').toLowerCase().includes((searchTerm || '').toLowerCase()) ||
      p.profile?.expertise?.some(e => (e || '').toLowerCase().includes((searchTerm || '').toLowerCase())) ||
      p.profile?.skills?.some(s => (s || '').toLowerCase().includes((searchTerm || '').toLowerCase()));
    
    const matchesRating = (p.profile?.averageRating || 0) >= minRating;
    const matchesRate = (p.profile?.hourlyRate || 0) <= maxHourlyRate;
    const matchesLocation = !locationFilter || (p.profile?.location || '').toLowerCase().includes(locationFilter.toLowerCase());

    return matchesSearch && matchesRating && matchesRate && matchesLocation;
  });

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h1 className="text-5xl font-display font-bold text-brand-900 tracking-tight">Elite Talent Acquisition</h1>
          <p className="text-brand-500 mt-3 font-accent font-medium text-lg tracking-wide">Discover and secure global experts for your high-impact events.</p>
        </div>
        <button 
          onClick={seedExampleProfessionals}
          className="flex items-center px-8 py-4 bg-brand-900 text-accent-400 rounded-2xl text-[10px] font-accent font-bold uppercase tracking-widest hover:bg-brand-800 transition-all shadow-xl shadow-brand-200"
        >
          <Sparkles className="w-4 h-4 mr-3 text-accent-400" />
          Seed Elite Talent
        </button>
      </div>

      <div className="flex items-center space-x-6 bg-white p-6 rounded-[2rem] border border-brand-100 shadow-sm">
        <div className="flex-1 relative">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-brand-400" />
          <input
            type="text"
            placeholder="Search by name, expertise, or elite skills..."
            className="w-full pl-16 pr-6 py-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 transition-all outline-none text-base font-accent font-medium"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="relative">
          <button 
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className={cn(
              "flex items-center px-8 py-4 border rounded-2xl transition-all text-[10px] font-accent font-bold uppercase tracking-widest",
              isFilterOpen ? "border-accent-400 bg-accent-50 text-accent-600 shadow-md" : "border-brand-100 text-brand-400 hover:bg-brand-50"
            )}
          >
            <Filter className="w-4 h-4 mr-3" />
            Refine Search
            {(minRating > 0 || maxHourlyRate < 1000 || locationFilter) && (
              <span className="ml-3 w-2 h-2 bg-accent-500 rounded-full shadow-[0_0_10px_rgba(212,175,55,0.5)]" />
            )}
          </button>

          <AnimatePresence>
            {isFilterOpen && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                className="absolute right-0 mt-4 w-80 bg-white rounded-[2rem] shadow-2xl border border-brand-100 p-8 z-40 space-y-8"
              >
                <div className="space-y-4">
                  <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Minimum Rating</label>
                  <div className="flex items-center space-x-3">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setMinRating(star === minRating ? 0 : star)}
                        className={cn(
                          "p-1 transition-all duration-300 transform hover:scale-110",
                          star <= minRating ? "text-accent-500" : "text-brand-100"
                        )}
                      >
                        <Star className={cn("w-7 h-7", star <= minRating && "fill-accent-500")} />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Max Hourly Rate (${maxHourlyRate})</label>
                  <input
                    type="range"
                    min="0"
                    max="1000"
                    step="50"
                    value={maxHourlyRate}
                    onChange={(e) => setMaxHourlyRate(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-brand-50 rounded-lg appearance-none cursor-pointer accent-accent-500"
                  />
                  <div className="flex justify-between text-[10px] text-brand-400 font-accent font-bold uppercase tracking-widest">
                    <span>$0</span>
                    <span>$1000+</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Location</label>
                  <input
                    type="text"
                    placeholder="City or country..."
                    className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-xl text-sm font-accent font-medium outline-none focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 transition-all"
                    value={locationFilter}
                    onChange={(e) => setLocationFilter(e.target.value)}
                  />
                </div>

                <button
                  onClick={() => {
                    setMinRating(0);
                    setMaxHourlyRate(1000);
                    setLocationFilter('');
                  }}
                  className="w-full py-3 text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] hover:text-accent-600 transition-colors border-t border-brand-50 pt-6"
                >
                  Reset All Filters
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="bg-white p-10 rounded-[2.5rem] border border-brand-100 shadow-sm animate-pulse">
              <div className="flex items-center space-x-6 mb-8">
                <div className="w-16 h-16 bg-brand-50 rounded-2xl" />
                <div className="flex-1 space-y-3">
                  <div className="h-5 bg-brand-50 rounded w-3/4" />
                  <div className="h-4 bg-brand-50 rounded w-1/2" />
                </div>
              </div>
              <div className="space-y-4">
                <div className="h-4 bg-brand-50 rounded w-full" />
                <div className="h-4 bg-brand-50 rounded w-5/6" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {filtered.length === 0 ? (
            <div className="col-span-full bg-white p-24 rounded-[3rem] border border-brand-100 text-center shadow-2xl">
              <div className="w-24 h-24 bg-brand-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8 border border-brand-100">
                <Search className="w-12 h-12 text-brand-200" />
              </div>
              <h3 className="text-3xl font-display font-bold text-brand-900 mb-4">No elite talent found</h3>
              <p className="text-brand-500 max-w-sm mx-auto font-accent font-medium text-lg leading-relaxed">
                Try refining your search parameters or filters to discover the perfect expert for your event.
              </p>
            </div>
          ) : (
            filtered.map((prof) => (
            <motion.div
              key={prof.uid}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="premium-card group relative overflow-hidden hover:-translate-y-2"
            >
              <div className="absolute top-0 right-0 p-6 opacity-0 group-hover:opacity-100 transition-all duration-500">
                <button className="p-3 bg-accent-50 text-accent-600 rounded-2xl hover:bg-accent-100 shadow-md">
                  <Info className="w-4 h-4" />
                </button>
              </div>

              <div className="p-10">
                <div className="flex items-center space-x-6 mb-8">
                  <div className="relative">
                    <div className="w-16 h-16 bg-brand-900 rounded-[1.25rem] flex items-center justify-center text-accent-400 font-display font-bold text-2xl overflow-hidden border-2 border-brand-800 shadow-xl">
                      {prof.photoURL ? (
                        <img src={prof.photoURL} alt={prof.displayName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        prof.displayName[0]
                      )}
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-emerald-500 border-2 border-white rounded-full flex items-center justify-center shadow-md">
                      <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                    </div>
                  </div>
                  <div>
                    <Link to={`/professional/${prof.uid}`} className="hover:underline decoration-accent-400 underline-offset-4">
                      <h3 className="text-xl font-display font-bold text-brand-900 group-hover:text-accent-600 transition-colors tracking-tight">{prof.displayName}</h3>
                    </Link>
                    <div className="flex items-center text-[10px] text-brand-400 font-accent font-bold uppercase tracking-[0.2em] mt-2">
                      <Star className={cn("w-3.5 h-3.5 mr-2", (prof.profile?.averageRating || 0) > 0 ? "text-accent-500 fill-accent-500" : "text-brand-100")} />
                      {prof.profile?.averageRating ? (
                        <span className="text-accent-600">{prof.profile.averageRating.toFixed(1)} <span className="text-brand-300 ml-1">({prof.profile.reviewCount || 0} reviews)</span></span>
                      ) : (
                        'New Professional'
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-6 mb-10">
                  <div className="flex flex-wrap gap-2.5">
                    {prof.profile?.expertise.slice(0, 3).map((exp, i) => (
                      <span key={i} className="px-4 py-1.5 bg-brand-900 text-accent-400 text-[9px] font-accent font-bold uppercase rounded-full tracking-[0.2em] shadow-sm">
                        {exp}
                      </span>
                    ))}
                    {(prof.profile?.expertise.length || 0) > 3 && (
                      <span className="px-4 py-1.5 bg-brand-50 text-brand-400 text-[9px] font-accent font-bold uppercase rounded-full tracking-[0.2em] border border-brand-100">
                        +{(prof.profile?.expertise.length || 0) - 3}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-brand-500 font-accent font-medium line-clamp-2 leading-relaxed italic opacity-80">
                    {prof.profile?.bio || 'Experienced professional ready to collaborate on high-impact events and training sessions.'}
                  </p>
                  
                  <div className="flex items-center justify-between pt-6 border-t border-brand-50">
                    <div className="flex items-center text-[10px] font-accent font-bold text-brand-400 uppercase tracking-widest">
                      <MapPin className="w-4 h-4 mr-3 text-accent-500" />
                      {prof.profile?.location || 'Global / Remote'}
                    </div>
                    <div className="text-accent-600 font-display font-bold text-lg">
                      ${prof.profile?.hourlyRate || 0}<span className="text-[10px] text-brand-300 ml-1 uppercase tracking-widest">/hr</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Link
                    to={`/professional/${prof.uid}`}
                    className="btn-secondary flex-1 py-4 text-[10px]"
                  >
                    <UserIcon className="w-4 h-4 mr-2" />
                    Dossier
                  </Link>
                  <button
                    onClick={() => {
                      setSelectedProf(prof);
                      setIsInviteModalOpen(true);
                    }}
                    className="btn-gold flex-[2] py-4 text-[10px]"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Secure Talent
                  </button>
                </div>
              </div>
            </motion.div>
          )))}
        </div>
      )}

      <AnimatePresence>
        {isInviteModalOpen && selectedProf && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsInviteModalOpen(false)}
              className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[2.5rem] shadow-2xl w-full max-w-lg overflow-hidden border border-brand-100"
            >
              <div className="p-10">
                <div className="flex justify-between items-center mb-10">
                  <div className="flex items-center space-x-6">
                    <div className="w-16 h-16 bg-brand-900 rounded-2xl flex items-center justify-center text-accent-400 font-display font-bold text-2xl border border-brand-800 shadow-xl">
                      {selectedProf.photoURL ? (
                        <img src={selectedProf.photoURL} alt="" className="w-full h-full object-cover rounded-2xl" referrerPolicy="no-referrer" />
                      ) : (
                        selectedProf.displayName[0]
                      )}
                    </div>
                    <div>
                      <h2 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Secure {selectedProf.displayName}</h2>
                      <p className="text-[10px] text-brand-400 font-accent font-bold uppercase tracking-widest mt-1">Initiate Elite Collaboration</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setIsInviteModalOpen(false)}
                    className="p-3 hover:bg-brand-50 rounded-2xl transition-all"
                  >
                    <X className="w-6 h-6 text-brand-300" />
                  </button>
                </div>

                <div className="space-y-8">
                  <div className="space-y-4">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Select Target Event</label>
                    {events.length === 0 ? (
                      <div className="p-6 bg-accent-50 rounded-3xl border border-accent-100 flex items-start space-x-4">
                        <AlertCircle className="w-6 h-6 text-accent-500 mt-0.5" />
                        <div>
                          <p className="text-sm font-display font-bold text-accent-700">No events curated</p>
                          <p className="text-[10px] text-accent-600 mt-2 font-accent font-bold uppercase tracking-widest leading-relaxed">You must curate an elite event before initiating talent acquisition.</p>
                          <Link to="/events" className="text-[10px] font-accent font-bold text-brand-900 hover:text-accent-600 mt-4 block uppercase tracking-[0.2em] underline underline-offset-4">Curate Event Now</Link>
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 gap-3 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                        {events.map((event) => (
                          <button
                            key={event.id}
                            onClick={() => setSelectedEventId(event.id)}
                            className={cn(
                              "flex items-center justify-between p-4 rounded-2xl border transition-all text-left",
                              selectedEventId === event.id 
                                ? "border-accent-400 bg-accent-50 shadow-md" 
                                : "border-brand-50 hover:border-brand-100 bg-brand-50/30"
                            )}
                          >
                            <div className="flex items-center space-x-4">
                              <div className={cn(
                                "p-3 rounded-xl transition-all",
                                selectedEventId === event.id ? "bg-accent-500 text-white" : "bg-white text-brand-200"
                              )}>
                                <Calendar className="w-4 h-4" />
                              </div>
                              <div>
                                <p className="text-sm font-display font-bold text-brand-900">{event.title}</p>
                                <p className="text-[9px] text-brand-400 font-accent font-bold uppercase tracking-widest mt-1">{new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                              </div>
                            </div>
                            {selectedEventId === event.id && <CheckCircle2 className="w-5 h-5 text-accent-600" />}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Personalized Dossier Message (Optional)</label>
                    <textarea
                      placeholder="Articulate the vision for this collaboration..."
                      className="w-full p-5 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium text-sm bg-brand-50/30"
                      rows={3}
                      value={inviteMessage}
                      onChange={(e) => setInviteMessage(e.target.value)}
                    />
                  </div>

                  <button
                    onClick={handleInvite}
                    disabled={!selectedEventId}
                    className="btn-gold w-full py-5 text-[10px] disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Send className="w-4 h-4 mr-3" />
                    Dispatch Collaboration Request
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
