import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { doc, getDoc, setDoc, updateDoc, collection, query, where, getDocs, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { updateProfile } from 'firebase/auth';
import { db, storage, auth } from '../firebase';
import { useAuth } from '../components/Auth/AuthContext';
import { Profile, Experience, Certification, Engagement } from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import imageCompression from 'browser-image-compression';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Save, 
  User as UserIcon, 
  Award, 
  BookOpen, 
  Link as LinkIcon, 
  Camera, 
  Plus, 
  X, 
  Briefcase, 
  GraduationCap,
  Globe,
  Trash2,
  Edit2,
  CheckCircle2,
  MapPin,
  Star,
  Sparkles
} from 'lucide-react';
import { toast } from 'sonner';
import Footer from '../components/Layout/Footer';

export default function ProfilePage() {
  const { user, firebaseUser, isAuthReady } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [engagements, setEngagements] = useState<Engagement[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isEditing, setIsEditing] = useState(false);
  const [backupProfile, setBackupProfile] = useState<Profile | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [newSkill, setNewSkill] = useState('');
  const [newExpertise, setNewExpertise] = useState('');

  // Modals state
  const [isExpModalOpen, setIsExpModalOpen] = useState(false);
  const [isCertModalOpen, setIsCertModalOpen] = useState(false);
  const [editingExp, setEditingExp] = useState<Experience | null>(null);
  const [editingCert, setEditingCert] = useState<Certification | null>(null);

  // Form state for Experience
  const [expForm, setExpForm] = useState<Partial<Experience>>({
    title: '',
    company: '',
    location: '',
    startDate: '',
    endDate: '',
    current: false,
    description: ''
  });

  // Form state for Certification
  const [certForm, setCertForm] = useState<Partial<Certification>>({
    name: '',
    issuer: '',
    issueDate: '',
    credentialUrl: ''
  });

  useEffect(() => {
    if (!isAuthReady) return;
    
    const effectiveUid = user?.uid || firebaseUser?.uid;
    if (!effectiveUid) {
      setLoading(false);
      return;
    }

    const fetchProfile = async () => {
      try {
        // Ensure user document exists (safeguard for incomplete signups)
        const userRef = doc(db, 'users', effectiveUid);
        const userSnap = await getDoc(userRef);
        if (!userSnap.exists()) {
          console.log('Synchronizing user identity segment...');
          await setDoc(userRef, {
            uid: effectiveUid,
            email: firebaseUser?.email || '',
            displayName: firebaseUser?.displayName || 'Elite Professional',
            role: 'Professional',
            isVerified: false,
            createdAt: serverTimestamp()
          }).catch(e => console.warn('Identity synchronization deferred:', e));
        }

        const docRef = doc(db, 'profiles', effectiveUid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data() as Profile;
          setProfile({
            ...data,
            experience: data.experience || [],
            certifications: data.certifications || [],
            skills: data.skills || [],
            expertise: data.expertise || [],
            portfolioLinks: data.portfolioLinks || [],
            location: data.location || '',
            hourlyRate: data.hourlyRate || 0
          });
        } else {
          // Initialize empty profile
          const initialProfile: Profile = {
            uid: effectiveUid,
            bio: '',
            expertise: [],
            skills: [],
            experience: [],
            certifications: [],
            portfolioLinks: [],
            location: '',
            hourlyRate: 0
          };
          await setDoc(docRef, initialProfile).catch(error => handleFirestoreError(error, OperationType.WRITE, `profiles/${effectiveUid}`));
          setProfile(initialProfile);
        }

        // Fetch engagements for expertise level
        const q = query(
          collection(db, 'engagements'),
          where('professionalId', '==', effectiveUid),
          where('status', '==', 'verified')
        );
        const engSnap = await getDocs(q).catch(error => handleFirestoreError(error, OperationType.LIST, 'engagements'));
        if (engSnap) {
          setEngagements(engSnap.docs.map(d => ({ id: d.id, ...d.data() } as Engagement)));
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `profiles/${effectiveUid}`);
        toast.error('Failed to load profile');
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [user, firebaseUser, isAuthReady]);

  const startEditing = () => {
    setBackupProfile(JSON.parse(JSON.stringify(profile)));
    setIsEditing(true);
  };

  const cancelEditing = () => {
    if (backupProfile) {
      setProfile(backupProfile);
    }
    setIsEditing(false);
  };

  const handleSave = async () => {
    const effectiveUid = user?.uid || firebaseUser?.uid;
    if (!effectiveUid || !profile) return;
    setSaving(true);
    try {
      // Atomic sync for both user and profile documents
      await Promise.all([
        setDoc(doc(db, 'profiles', effectiveUid), profile),
        setDoc(doc(db, 'users', effectiveUid), {
          uid: effectiveUid,
          displayName: firebaseUser?.displayName || user?.displayName || 'Elite Professional',
          email: firebaseUser?.email || user?.email || '',
          role: user?.role || 'Professional',
          isVerified: user?.isVerified ?? false,
          createdAt: user?.createdAt || serverTimestamp()
        }, { merge: true })
      ]);
      toast.success('Professional identity synchronized!');
      setIsEditing(false);
    } catch (err) {
      console.error(err);
      toast.error('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const effectiveUid = user?.uid || firebaseUser?.uid;
    if (!file || !effectiveUid) return;

    if (file.size > 2 * 1024 * 1024) {
      toast.error('File size must be less than 2MB');
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    
    try {
      // Small files don't need compression
      let fileToUpload = file;
      
      if (file.size > 200 * 1024) {
        const options = {
          maxSizeMB: 0.5,
          maxWidthOrHeight: 800,
          useWebWorker: false // Disable web worker as it can hang in some environments
        };
        try {
          fileToUpload = await imageCompression(file, options);
        } catch (e) {
          console.warn('Compression failed, uploading original', e);
        }
      }
      
      const storageRef = ref(storage, `profiles/${effectiveUid}/avatar`);
      
      // Use uploadBytes for better reliability in this environment
      await uploadBytes(storageRef, fileToUpload);
      const url = await getDownloadURL(storageRef);
      
      // Update Auth Profile
      if (auth.currentUser) {
        await updateProfile(auth.currentUser, { photoURL: url });
      }
      
      // Update Firestore User Doc
      try {
        await updateDoc(doc(db, 'users', effectiveUid), { photoURL: url });
      } catch (e) {
        console.warn('Could not update users document with photoURL', e);
      }
      
      toast.success('Profile photo updated!');
      setUploading(false);
      setUploadProgress(100);
      setTimeout(() => window.location.reload(), 500);
    } catch (err) {
      console.error(err);
      toast.error('Failed to upload photo');
      setUploading(false);
    }
  };

  const addSkill = () => {
    if (!newSkill.trim() || !profile) return;
    if (profile.skills.includes(newSkill.trim())) {
      setNewSkill('');
      return;
    }
    setProfile({ ...profile, skills: [...profile.skills, newSkill.trim()] });
    setNewSkill('');
  };

  const removeSkill = (skill: string) => {
    if (!profile) return;
    setProfile({ ...profile, skills: profile.skills.filter(s => s !== skill) });
  };

  const addExpertise = () => {
    if (!newExpertise.trim() || !profile) return;
    if (profile.expertise.includes(newExpertise.trim())) {
      setNewExpertise('');
      return;
    }
    setProfile({ ...profile, expertise: [...profile.expertise, newExpertise.trim()] });
    setNewExpertise('');
  };

  const removeExpertise = (exp: string) => {
    if (!profile) return;
    setProfile({ ...profile, expertise: profile.expertise.filter(e => e !== exp) });
  };

  const handleAddExperience = () => {
    setEditingExp(null);
    setExpForm({
      title: '',
      company: '',
      location: '',
      startDate: '',
      endDate: '',
      current: false,
      description: ''
    });
    setIsExpModalOpen(true);
  };

  const handleEditExperience = (exp: Experience) => {
    setEditingExp(exp);
    setExpForm(exp);
    setIsExpModalOpen(true);
  };

  const handleSaveExperience = () => {
    if (!profile || !expForm.title || !expForm.company || !expForm.startDate) {
      toast.error('Please fill in all required fields');
      return;
    }

    const newExp: Experience = {
      id: editingExp?.id || Math.random().toString(36).substr(2, 9),
      title: expForm.title!,
      company: expForm.company!,
      location: expForm.location || '',
      startDate: expForm.startDate!,
      endDate: expForm.current ? undefined : expForm.endDate,
      current: expForm.current || false,
      description: expForm.description || ''
    };

    const updatedExperience = editingExp
      ? profile.experience.map(e => e.id === editingExp.id ? newExp : e)
      : [...profile.experience, newExp];

    setProfile({ ...profile, experience: updatedExperience });
    setIsExpModalOpen(false);
  };

  const removeExperience = (id: string) => {
    if (!profile) return;
    setProfile({ ...profile, experience: profile.experience.filter(e => e.id !== id) });
  };

  const handleAddCertification = () => {
    setEditingCert(null);
    setCertForm({
      name: '',
      issuer: '',
      issueDate: '',
      credentialUrl: ''
    });
    setIsCertModalOpen(true);
  };

  const handleSaveCertification = () => {
    if (!profile || !certForm.name || !certForm.issuer) {
      toast.error('Please fill in all required fields');
      return;
    }

    const newCert: Certification = {
      id: editingCert?.id || Math.random().toString(36).substr(2, 9),
      name: certForm.name!,
      issuer: certForm.issuer!,
      issueDate: certForm.issueDate || '',
      credentialUrl: certForm.credentialUrl || ''
    };

    const updatedCertifications = editingCert
      ? profile.certifications.map(c => c.id === editingCert.id ? newCert : c)
      : [...profile.certifications, newCert];

    setProfile({ ...profile, certifications: updatedCertifications });
    setIsCertModalOpen(false);
  };

  const removeCertification = (id: string) => {
    if (!profile) return;
    setProfile({ ...profile, certifications: profile.certifications.filter(c => c.id !== id) });
  };

  const getExpertiseLevel = () => {
    if (!profile) return { level: 1, label: 'Emerging Professional' };
    const score = (engagements.length * 2) + (profile.skills?.length || 0);
    if (score > 20) return { level: 5, label: 'Elite Professional' };
    if (score > 12) return { level: 4, label: 'Senior Professional' };
    if (score > 6) return { level: 3, label: 'Established Professional' };
    if (score > 2) return { level: 2, label: 'Rising Professional' };
    return { level: 1, label: 'Emerging Professional' };
  };

  const expertise = getExpertiseLevel();

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto space-y-10 pb-20">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 bg-white p-10 rounded-[3rem] border border-brand-100 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-50/30 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        
        <div className="flex items-center space-x-8 relative z-10">
          <div className="relative group">
            <div className="w-32 h-32 bg-brand-900 rounded-[2rem] flex items-center justify-center text-accent-400 text-5xl font-display font-bold overflow-hidden border-4 border-white shadow-2xl relative">
              {user?.photoURL ? (
                <img src={user.photoURL} alt={user.displayName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                user?.displayName?.[0]
              )}
              {uploading && (
                <div className="absolute inset-0 bg-brand-900/80 backdrop-blur-sm flex flex-col items-center justify-center">
                  <div className="w-12 h-12 border-4 border-white/20 border-t-accent-500 rounded-full animate-spin mb-2" />
                  <span className="text-[10px] font-accent font-bold text-white uppercase tracking-widest animate-pulse">Syncing...</span>
                </div>
              )}
            </div>
            {isEditing && (
              <button 
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="absolute -bottom-2 -right-2 p-3 bg-accent-500 text-white rounded-2xl shadow-xl hover:bg-accent-600 transition-all active:scale-95 disabled:opacity-50 border-4 border-white"
              >
                <Camera className="w-5 h-5" />
              </button>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handlePhotoUpload} 
            />
          </div>
          <div>
            <h1 className="text-4xl font-display font-bold text-brand-900 tracking-tight">{user?.displayName}</h1>
            <p className="text-brand-500 font-accent font-medium text-lg mt-1">{user?.role} • {user?.email}</p>
            <div className="flex items-center mt-4 space-x-4">
              <span className="px-4 py-1.5 rounded-full text-[9px] font-accent font-bold bg-brand-900 text-accent-400 uppercase tracking-[0.2em] shadow-sm">Level {expertise.level} {expertise.label}</span>
              {profile?.averageRating && (
                <>
                  <div className="w-1 h-1 bg-brand-200 rounded-full" />
                  <div className="flex items-center text-accent-600 font-accent font-bold text-[10px] uppercase tracking-widest">
                    <Star className="w-4 h-4 mr-2 fill-accent-500 text-accent-500" />
                    {profile.averageRating.toFixed(1)} <span className="text-brand-300 ml-1">({profile.reviewCount || 0} reviews)</span>
                  </div>
                </>
              )}
              <div className="w-1 h-1 bg-brand-200 rounded-full" />
              <span className="text-[10px] text-brand-300 font-accent font-bold uppercase tracking-widest">Joined {new Date(user?.createdAt || Date.now()).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto relative z-10">
          {!isEditing ? (
            <button
              onClick={startEditing}
              className="btn-secondary w-full md:w-auto px-10 py-4 text-[10px]"
            >
              <Edit2 className="w-4 h-4 mr-3 text-accent-600" />
              Refine Profile
            </button>
          ) : (
            <>
              <button
                onClick={cancelEditing}
                className="flex-1 md:flex-none bg-white text-brand-400 border border-brand-100 px-8 py-4 rounded-2xl font-accent font-bold text-[10px] uppercase tracking-widest hover:bg-brand-50 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="btn-gold flex-1 md:flex-none px-10 py-4 text-[10px]"
              >
                {saving ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3" />
                ) : (
                  <Save className="w-4 h-4 mr-3" />
                )}
                {saving ? 'Securing...' : 'Commit Changes'}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Portfolio Sharing Section */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-brand-900 rounded-[2.5rem] p-10 text-white shadow-2xl relative overflow-hidden group border border-brand-800"
      >
        <div className="absolute top-0 right-0 p-16 opacity-5 group-hover:scale-110 transition-transform duration-700">
          <Globe className="w-48 h-48 text-accent-500" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="max-w-xl">
            <h3 className="text-2xl font-display font-bold mb-3 flex items-center">
              <Sparkles className="w-8 h-8 mr-4 text-accent-400" />
              Elite Portfolio Live
            </h3>
            <p className="text-brand-200 text-sm font-accent font-medium leading-relaxed">
              Your professional legacy is meticulously organized and ready for global scrutiny. Copy your unique protocol identifier to share with elite curators and organizations.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 items-center">
            <div className="px-6 py-3.5 bg-white/10 rounded-2xl border border-white/10 backdrop-blur-md flex items-center gap-4 group/link">
              <span className="text-[10px] font-accent font-bold text-accent-400 tracking-widest uppercase truncate max-w-[200px]">
                {window.location.origin}/u/{user?.uid}
              </span>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(`${window.location.origin}/u/${user?.uid}`);
                  toast.success('Portfolio link copied to clipboard!');
                }}
                className="p-2 hover:bg-white/10 rounded-lg transition-all text-white/50 hover:text-white"
              >
                <LinkIcon className="w-4 h-4" />
              </button>
            </div>
            <Link 
              to={`/u/${user?.uid}`} 
              target="_blank"
              className="px-8 py-3.5 bg-accent-500 text-brand-900 font-accent font-bold text-[10px] uppercase tracking-[0.2em] rounded-2xl hover:bg-accent-400 transition-all shadow-lg hover:shadow-accent-500/20 active:scale-95"
            >
              Preview Interface
            </Link>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Left Column: Bio & Links */}
        <div className="lg:col-span-1 space-y-10">
          {/* Service Details */}
          <div className="premium-card p-8 space-y-6">
            <div className="flex items-center space-x-4 text-brand-900 font-display font-bold">
              <div className="p-3 bg-brand-50 rounded-2xl">
                <Briefcase className="w-5 h-5 text-accent-600" />
              </div>
              <span className="tracking-tight">Service Parameters</span>
            </div>
            <div className="space-y-6">
              <div className="space-y-3">
                <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Global Location</label>
                {isEditing ? (
                  <input
                    type="text"
                    className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                    placeholder="e.g. London, UK or Global"
                    value={profile?.location || ''}
                    onChange={(e) => setProfile(prev => prev ? { ...prev, location: e.target.value } : null)}
                  />
                ) : (
                  <div className="flex items-center text-sm text-brand-600 font-accent font-bold uppercase tracking-widest">
                    <MapPin className="w-4 h-4 mr-4 text-accent-500" />
                    {profile?.location || 'Global / Remote'}
                  </div>
                )}
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Elite Hourly Rate</label>
                {isEditing ? (
                  <input
                    type="number"
                    className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                    placeholder="0.00"
                    value={profile?.hourlyRate || ''}
                    onChange={(e) => setProfile(prev => prev ? { ...prev, hourlyRate: parseFloat(e.target.value) || 0 } : null)}
                  />
                ) : (
                  <div className="flex items-center text-brand-600 font-accent font-bold">
                    <span className="text-accent-600 font-display font-bold text-3xl mr-2">${profile?.hourlyRate || 0}</span>
                    <span className="text-[10px] text-brand-300 uppercase tracking-widest">/ hour</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Bio Section */}
          <div className="premium-card p-8 space-y-6">
            <div className="flex items-center space-x-4 text-brand-900 font-display font-bold">
              <div className="p-3 bg-brand-50 rounded-2xl">
                <UserIcon className="w-5 h-5 text-accent-600" />
              </div>
              <span className="tracking-tight">Professional Dossier</span>
            </div>
            {isEditing ? (
              <textarea
                rows={6}
                className="w-full rounded-[2rem] border-brand-100 bg-brand-50/50 text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 transition-all resize-none p-6 outline-none"
                placeholder="Articulate your professional journey and elite impact..."
                value={profile?.bio || ''}
                onChange={(e) => setProfile(prev => prev ? { ...prev, bio: e.target.value } : null)}
              />
            ) : (
              <p className="text-brand-500 text-sm font-accent font-medium leading-relaxed whitespace-pre-wrap italic opacity-80">
                {profile?.bio || 'Your professional narrative is waiting to be articulated.'}
              </p>
            )}
          </div>

          {/* Portfolio Links */}
          <div className="premium-card p-8 space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-brand-900 font-display font-bold">
                <div className="p-3 bg-brand-50 rounded-2xl">
                  <Globe className="w-5 h-5 text-accent-600" />
                </div>
                <span className="tracking-tight">Elite Presence</span>
              </div>
              {isEditing && (
                <button 
                  onClick={() => setProfile(prev => prev ? { ...prev, portfolioLinks: [...prev.portfolioLinks, ''] } : null)}
                  className="p-2 text-accent-600 hover:bg-accent-50 rounded-xl transition-all"
                >
                  <Plus className="w-5 h-5" />
                </button>
              )}
            </div>
            <div className="space-y-4">
              {profile?.portfolioLinks.map((link, idx) => (
                <div key={idx} className="flex items-center space-x-3 group">
                  <div className="flex-1 relative">
                    <LinkIcon className="w-3.5 h-3.5 absolute left-4 top-1/2 -translate-y-1/2 text-brand-200" />
                    {isEditing ? (
                      <input
                        type="url"
                        placeholder="https://linkedin.com/in/..."
                        className="w-full pl-12 pr-4 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-xs font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                        value={link}
                        onChange={(e) => {
                          const newLinks = [...(profile?.portfolioLinks || [])];
                          newLinks[idx] = e.target.value;
                          setProfile(prev => prev ? { ...prev, portfolioLinks: newLinks } : null);
                        }}
                      />
                    ) : (
                      <a 
                        href={link} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block w-full pl-12 pr-4 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-[10px] font-accent font-bold text-accent-600 hover:text-accent-700 uppercase tracking-widest truncate transition-all"
                      >
                        {link.replace(/^https?:\/\/(www\.)?/, '')}
                      </a>
                    )}
                  </div>
                  {isEditing && (
                    <button 
                      onClick={() => setProfile(prev => prev ? { ...prev, portfolioLinks: prev.portfolioLinks.filter((_, i) => i !== idx) } : null)}
                      className="p-3 text-brand-200 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
              {profile?.portfolioLinks.length === 0 && (
                <p className="text-[10px] text-brand-300 font-accent font-bold uppercase tracking-widest text-center py-6 bg-brand-50/30 rounded-2xl border border-dashed border-brand-100">No digital footprints established.</p>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Skills, Experience, Certs */}
        <div className="lg:col-span-2 space-y-10">
          {/* Skills & Expertise */}
          <div className="premium-card p-10 space-y-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {/* Skills */}
              <div className="space-y-6">
                <div className="flex items-center space-x-4 text-brand-900 font-display font-bold">
                  <div className="p-3 bg-brand-50 rounded-2xl">
                    <Award className="w-5 h-5 text-accent-600" />
                  </div>
                  <span className="tracking-tight">Core Competencies</span>
                </div>
                <div className="flex flex-wrap gap-3">
                  <AnimatePresence>
                    {profile?.skills.map((skill) => (
                      <motion.span
                        key={skill}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className="inline-flex items-center px-5 py-2 bg-brand-900 text-accent-400 rounded-full text-[9px] font-accent font-bold uppercase tracking-[0.2em] shadow-sm"
                      >
                        {skill}
                        {isEditing && (
                          <button onClick={() => removeSkill(skill)} className="ml-3 hover:text-white transition-colors">
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </motion.span>
                    ))}
                  </AnimatePresence>
                </div>
                {isEditing && (
                  <div className="flex space-x-3">
                    <input
                      type="text"
                      placeholder="Add competency..."
                      className="flex-1 px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-xs font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                      value={newSkill}
                      onChange={(e) => setNewSkill(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addSkill()}
                    />
                    <button 
                      onClick={addSkill}
                      className="p-3 bg-brand-900 text-accent-400 rounded-2xl hover:bg-brand-800 transition-all shadow-lg shadow-brand-100"
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Expertise */}
              <div className="space-y-6">
                <div className="flex items-center space-x-4 text-brand-900 font-display font-bold">
                  <div className="p-3 bg-brand-50 rounded-2xl">
                    <BookOpen className="w-5 h-5 text-accent-600" />
                  </div>
                  <span className="tracking-tight">Elite Expertise</span>
                </div>
                <div className="flex flex-wrap gap-3">
                  <AnimatePresence>
                    {profile?.expertise.map((exp) => (
                      <motion.span
                        key={exp}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className="inline-flex items-center px-5 py-2 bg-brand-50 text-brand-600 rounded-full text-[9px] font-accent font-bold uppercase tracking-[0.2em] border border-brand-100 shadow-sm"
                      >
                        {exp}
                        {isEditing && (
                          <button onClick={() => removeExpertise(exp)} className="ml-3 hover:text-brand-900 transition-colors">
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </motion.span>
                    ))}
                  </AnimatePresence>
                </div>
                {isEditing && (
                  <div className="flex space-x-3">
                    <input
                      type="text"
                      placeholder="Add expertise..."
                      className="flex-1 px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-xs font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                      value={newExpertise}
                      onChange={(e) => setNewExpertise(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addExpertise()}
                    />
                    <button 
                      onClick={addExpertise}
                      className="p-3 bg-brand-900 text-accent-400 rounded-2xl hover:bg-brand-800 transition-all shadow-lg shadow-brand-100"
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Experience Section */}
          <div className="premium-card p-10 space-y-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-brand-900 font-display font-bold">
                <div className="p-3 bg-brand-50 rounded-2xl">
                  <Briefcase className="w-5 h-5 text-accent-600" />
                </div>
                <span className="tracking-tight">Elite Professional History</span>
              </div>
              {isEditing && (
                <button 
                  onClick={handleAddExperience}
                  className="text-[10px] font-accent font-bold text-accent-600 hover:text-accent-700 flex items-center uppercase tracking-widest"
                >
                  <Plus className="w-4 h-4 mr-2" /> Add History
                </button>
              )}
            </div>
            <div className="space-y-10">
              {profile?.experience.length === 0 ? (
                <div className="text-center py-16 bg-brand-50/30 rounded-[2.5rem] border border-dashed border-brand-100">
                  <Briefcase className="w-12 h-12 text-brand-100 mx-auto mb-4" />
                  <p className="text-[10px] text-brand-300 font-accent font-bold uppercase tracking-widest">No professional history documented.</p>
                </div>
              ) : (
                profile?.experience.map((exp) => (
                  <div key={exp.id} className="flex space-x-8 group relative">
                    <div className="w-16 h-16 bg-brand-50 rounded-[1.25rem] flex items-center justify-center flex-shrink-0 border border-brand-100 shadow-sm group-hover:bg-white transition-colors duration-500">
                      <Briefcase className="w-8 h-8 text-accent-500" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="text-xl font-display font-bold text-brand-900 tracking-tight">{exp.title}</h4>
                          <p className="text-sm text-brand-500 font-accent font-bold uppercase tracking-widest mt-1">{exp.company} <span className="text-brand-200 mx-2">•</span> {exp.location}</p>
                        </div>
                        {isEditing && (
                          <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-all duration-500">
                            <button 
                              onClick={() => handleEditExperience(exp)}
                              className="p-3 text-brand-300 hover:text-accent-600 hover:bg-accent-50 rounded-2xl transition-all"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => removeExperience(exp.id)}
                              className="p-3 text-brand-300 hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </div>
                      <p className="text-[10px] text-accent-600 font-accent font-bold uppercase tracking-[0.2em] mt-3">
                        {new Date(exp.startDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })} — {exp.current ? 'Present' : exp.endDate ? new Date(exp.endDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : 'N/A'}
                      </p>
                      <p className="text-sm text-brand-500 font-accent font-medium mt-4 leading-relaxed italic opacity-80">{exp.description}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Certifications Section */}
          <div className="premium-card p-10 space-y-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-brand-900 font-display font-bold">
                <div className="p-3 bg-brand-50 rounded-2xl">
                  <GraduationCap className="w-5 h-5 text-accent-600" />
                </div>
                <span className="tracking-tight">Elite Certifications</span>
              </div>
              {isEditing && (
                <button 
                  onClick={handleAddCertification}
                  className="text-[10px] font-accent font-bold text-accent-600 hover:text-accent-700 flex items-center uppercase tracking-widest"
                >
                  <Plus className="w-4 h-4 mr-2" /> Add Certification
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {profile?.certifications.length === 0 ? (
                <div className="col-span-2 text-center py-16 bg-brand-50/30 rounded-[2.5rem] border border-dashed border-brand-100">
                  <GraduationCap className="w-12 h-12 text-brand-100 mx-auto mb-4" />
                  <p className="text-[10px] text-brand-300 font-accent font-bold uppercase tracking-widest">No elite certifications documented.</p>
                </div>
              ) : (
                profile?.certifications.map((cert) => (
                  <div key={cert.id} className="p-6 bg-brand-50/50 rounded-[2rem] border border-brand-100 flex items-center space-x-5 group hover:bg-white hover:shadow-xl transition-all duration-500">
                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow-sm border border-brand-50">
                      <Award className="w-6 h-6 text-accent-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-display font-bold text-brand-900 truncate tracking-tight">{cert.name}</h4>
                      <p className="text-[10px] text-brand-400 font-accent font-bold uppercase tracking-widest mt-1 truncate">{cert.issuer}</p>
                    </div>
                    {isEditing && (
                      <button 
                        onClick={() => removeCertification(cert.id)}
                        className="p-3 text-brand-200 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Experience Modal */}
      <AnimatePresence>
        {isExpModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsExpModalOpen(false)}
              className="absolute inset-0 bg-brand-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[3rem] shadow-2xl w-full max-w-lg overflow-hidden border border-brand-100"
            >
              <div className="p-10 space-y-8">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-display font-bold text-brand-900 tracking-tight">{editingExp ? 'Refine Experience' : 'Document Experience'}</h2>
                  <button onClick={() => setIsExpModalOpen(false)} className="p-3 hover:bg-brand-50 rounded-2xl transition-all">
                    <X className="w-6 h-6 text-brand-300" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Professional Title</label>
                      <input
                        type="text"
                        className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                        value={expForm.title}
                        onChange={(e) => setExpForm({ ...expForm, title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Organization</label>
                      <input
                        type="text"
                        className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                        value={expForm.company}
                        onChange={(e) => setExpForm({ ...expForm, company: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Location</label>
                    <input
                      type="text"
                      className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                      value={expForm.location}
                      onChange={(e) => setExpForm({ ...expForm, location: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Commencement Date</label>
                      <input
                        type="date"
                        className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                        value={expForm.startDate}
                        onChange={(e) => setExpForm({ ...expForm, startDate: e.target.value })}
                      />
                    </div>
                    {!expForm.current && (
                      <div className="space-y-2">
                        <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Conclusion Date</label>
                        <input
                          type="date"
                          className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                          value={expForm.endDate}
                          onChange={(e) => setExpForm({ ...expForm, endDate: e.target.value })}
                        />
                      </div>
                    )}
                  </div>

                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      id="current"
                      className="w-5 h-5 rounded-lg border-brand-100 text-accent-500 focus:ring-accent-500/20"
                      checked={expForm.current}
                      onChange={(e) => setExpForm({ ...expForm, current: e.target.checked })}
                    />
                    <label htmlFor="current" className="text-[10px] font-accent font-bold text-brand-500 uppercase tracking-widest cursor-pointer">Active Engagement</label>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Professional Narrative</label>
                    <textarea
                      rows={3}
                      className="w-full px-5 py-4 bg-brand-50/50 border border-brand-100 rounded-[2rem] text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all resize-none"
                      value={expForm.description}
                      onChange={(e) => setExpForm({ ...expForm, description: e.target.value })}
                    />
                  </div>
                </div>

                <button
                  onClick={handleSaveExperience}
                  className="btn-gold w-full py-5 text-[10px]"
                >
                  Commit History
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Certification Modal */}
      <AnimatePresence>
        {isCertModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCertModalOpen(false)}
              className="absolute inset-0 bg-brand-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[3rem] shadow-2xl w-full max-w-lg overflow-hidden border border-brand-100"
            >
              <div className="p-10 space-y-8">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Elite Certification</h2>
                  <button onClick={() => setIsCertModalOpen(false)} className="p-3 hover:bg-brand-50 rounded-2xl transition-all">
                    <X className="w-6 h-6 text-brand-300" />
                  </button>
                </div>

                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Credential Name</label>
                    <input
                      type="text"
                      className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                      value={certForm.name}
                      onChange={(e) => setCertForm({ ...certForm, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Issuing Authority</label>
                    <input
                      type="text"
                      className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                      value={certForm.issuer}
                      onChange={(e) => setCertForm({ ...certForm, issuer: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Conferral Date</label>
                      <input
                        type="date"
                        className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                        value={certForm.issueDate}
                        onChange={(e) => setCertForm({ ...certForm, issueDate: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Verification URL (Optional)</label>
                      <input
                        type="url"
                        className="w-full px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                        value={certForm.credentialUrl}
                        onChange={(e) => setCertForm({ ...certForm, credentialUrl: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleSaveCertification}
                  className="btn-gold w-full py-5 text-[10px]"
                >
                  Validate Credential
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
