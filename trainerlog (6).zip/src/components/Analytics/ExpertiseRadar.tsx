import React from 'react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer 
} from 'recharts';
import { Engagement } from '../../types';
import { Award } from 'lucide-react';
import { motion } from 'framer-motion';

interface ExpertiseRadarProps {
  engagements: Engagement[];
}

const ALL_COMMON_ROLES = [
  'Lecturer', 
  'Speaker', 
  'Judge', 
  'Resource Person', 
  'Panelist', 
  'Consultant', 
  'Trainer',
  'Mentor',
  'Moderator',
  'Guest Speaker',
  'Facilitator',
  'Exhibitor'
];

export default function ExpertiseRadar({ engagements }: ExpertiseRadarProps) {
  // Derive roles dynamically from data, but always include standard ones for a consistent grid
  const dataRoles = Array.from(new Set([
    ...ALL_COMMON_ROLES,
    ...engagements.map(e => e.role).filter(Boolean)
  ]));

  const data = dataRoles.map(role => {
    // Case-insensitive matching to ensure all logs are captured
    const count = engagements.filter(e => 
      e.role?.toLowerCase() === role.toLowerCase()
    ).length;

    return {
      subject: role,
      A: count,
      // Dynamic fullMark ensures small data still occupies visible space, but scales as you grow
      fullMark: Math.max(...dataRoles.map(r => 
        engagements.filter(e => e.role?.toLowerCase() === r.toLowerCase()).length
      ), 3),
    };
  });

  // Limit to top N roles for the radar to keep it readable if there are many custom roles
  const sortedData = data.sort((a, b) => b.A - a.A).slice(0, 10);

  return (
    <div className="premium-card p-8 h-full flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h3 className="text-xl font-display font-bold text-brand-900 tracking-tight">Expertise Radar</h3>
          <p className="text-[10px] font-accent font-bold text-brand-400 mt-1 uppercase tracking-widest">Role distribution analysis</p>
        </div>
        <div className="p-3 bg-brand-50 rounded-2xl">
          <Award className="w-5 h-5 text-accent-600" />
        </div>
      </div>

      <div className="flex-1 min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart cx="50%" cy="50%" outerRadius="80%" data={sortedData}>
            <PolarGrid stroke="#E2E8F0" />
            <PolarAngleAxis 
              dataKey="subject" 
              tick={{ fill: '#64748B', fontSize: 10, fontWeight: 600, fontFamily: 'Outfit' }}
            />
            <PolarRadiusAxis 
              angle={30} 
              domain={[0, 'auto']} 
              tick={false}
              axisLine={false}
            />
            <Radar
              name="Expertise"
              dataKey="A"
              stroke="#c9a23f"
              fill="#c9a23f"
              fillOpacity={0.4}
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-6 pt-6 border-t border-brand-100 grid grid-cols-2 gap-4">
        <div className="text-center p-3 bg-brand-50/50 rounded-2xl">
          <p className="text-[9px] font-accent font-bold text-brand-400 uppercase tracking-widest mb-1">Top Role</p>
          <p className="text-sm font-display font-bold text-brand-900">
            {sortedData[0]?.A > 0 ? sortedData[0].subject : 'N/A'}
          </p>
        </div>
        <div className="text-center p-3 bg-brand-50/50 rounded-2xl">
          <p className="text-[9px] font-accent font-bold text-brand-400 uppercase tracking-widest mb-1">Total Logs</p>
          <p className="text-sm font-display font-bold text-brand-900">{engagements.length}</p>
        </div>
      </div>
    </div>
  );
}
