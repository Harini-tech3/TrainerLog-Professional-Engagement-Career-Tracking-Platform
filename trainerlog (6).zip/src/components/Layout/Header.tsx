import React, { useState, useEffect } from 'react';
import { Bell, Search, User as UserIcon, LogOut, Settings, ChevronDown, Menu, X } from 'lucide-react';
import { useAuth } from '../Auth/AuthContext';
import { useLayout } from './LayoutContext';
import { useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { collection, query, where, onSnapshot, limit, orderBy } from 'firebase/firestore';
import { db } from '../../firebase';
import { Notification } from '../../types';
import { cn } from '../../lib/utils';

export default function Header() {
  const { user, signOut } = useAuth();
  const { isSidebarOpen, toggleSidebar } = useLayout();
  const navigate = useNavigate();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc'),
      limit(5)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notifs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification));
      setNotifications(notifs);
      setUnreadCount(notifs.filter(n => !n.read).length);
    });

    return () => unsubscribe();
  }, [user]);

  return (
    <header className="h-24 bg-white/90 backdrop-blur-xl border-b border-brand-100 sticky top-0 z-40 flex items-center justify-between px-8 md:px-12 shadow-sm">
      <div className="flex items-center">
        {/* Menu Toggle */}
        <button 
          onClick={toggleSidebar}
          className="p-3.5 -ml-2 text-brand-900 bg-white hover:bg-brand-50 rounded-2xl transition-all active:scale-95 shadow-md border border-brand-100 mr-8 flex items-center justify-center group"
          title={isSidebarOpen ? "Collapse Sidebar" : "Expand Sidebar"}
        >
          {isSidebarOpen ? (
            <X className="w-6 h-6 text-accent-600 transition-all" />
          ) : (
            <Menu className="w-6 h-6 transition-all" />
          )}
          {!isSidebarOpen && <span className="ml-2 text-[10px] font-accent font-bold uppercase tracking-widest hidden sm:inline">Menu</span>}
        </button>
      </div>

      {/* Search Bar - Premium Style */}
      <div className="hidden md:flex items-center flex-1 max-w-md relative group">
        <Search className="w-4 h-4 absolute left-5 text-brand-300 group-focus-within:text-accent-500 transition-colors" />
        <input
          type="text"
          placeholder="Search engagements, professionals..."
          className="w-full pl-14 pr-6 py-3.5 bg-brand-50/50 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:outline-none focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 focus:bg-white transition-all placeholder:text-brand-300 tracking-wide"
        />
      </div>

      {/* Right Side Actions */}
      <div className="flex items-center space-x-6 ml-auto">
        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-3.5 text-brand-400 hover:bg-brand-50 rounded-2xl transition-all relative group border border-transparent hover:border-brand-100 hover:shadow-sm"
          >
            <Bell className="w-5 h-5 group-hover:text-brand-900 transition-colors" />
            {unreadCount > 0 && (
              <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-accent-500 rounded-full border-2 border-white shadow-sm animate-pulse" />
            )}
          </button>

          <AnimatePresence>
            {showNotifications && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowNotifications(false)} 
                />
                <motion.div
                  initial={{ opacity: 0, y: 15, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 15, scale: 0.95 }}
                  className="absolute right-0 mt-4 w-96 bg-white border border-brand-100 rounded-[2rem] shadow-2xl z-50 overflow-hidden ring-1 ring-brand-900/5"
                >
                  <div className="p-8 border-b border-brand-50 flex justify-between items-center bg-brand-50/30">
                    <h3 className="font-display font-bold text-xl text-brand-900 tracking-tight">Notifications</h3>
                    <button className="text-[10px] text-accent-600 hover:text-accent-700 font-accent font-bold uppercase tracking-widest">Mark all as read</button>
                  </div>
                  <div className="max-h-[400px] overflow-y-auto">
                    {notifications.length > 0 ? (
                      notifications.map((notif) => (
                        <div key={notif.id} className={`p-6 border-b border-brand-50 hover:bg-brand-50 transition-colors cursor-pointer group ${!notif.read ? 'bg-accent-50/20' : ''}`}>
                          <p className="text-sm text-brand-600 font-medium group-hover:text-brand-900 transition-colors leading-relaxed">{notif.content}</p>
                          <span className="text-[10px] text-brand-300 font-accent font-bold uppercase tracking-widest mt-3 block">
                            {new Date(notif.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                          </span>
                        </div>
                      ))
                    ) : (
                      <div className="p-16 text-center">
                        <div className="w-20 h-20 bg-brand-50 rounded-full flex items-center justify-center mx-auto mb-6">
                          <Bell className="w-10 h-10 text-brand-200" />
                        </div>
                        <p className="text-sm text-brand-400 font-medium">No new notifications</p>
                      </div>
                    )}
                  </div>
                  <Link 
                    to="/notifications" 
                    className="block p-5 text-center text-[10px] font-accent font-bold text-brand-400 hover:text-accent-600 hover:bg-brand-50 border-t border-brand-50 transition-all uppercase tracking-widest"
                    onClick={() => setShowNotifications(false)}
                  >
                    View all notifications
                  </Link>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

        {/* User Menu */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center space-x-4 p-2.5 hover:bg-brand-50 rounded-2xl transition-all border border-transparent hover:border-brand-100 hover:shadow-sm group"
          >
            <div className="w-11 h-11 rounded-2xl bg-brand-900 flex items-center justify-center text-white font-display font-bold text-lg overflow-hidden shadow-lg shadow-brand-900/10 group-hover:scale-105 transition-transform border border-brand-800">
              {user?.photoURL ? (
                <img src={user.photoURL} alt={user.displayName} className="w-full h-full object-cover" />
              ) : (
                user?.displayName?.[0]
              )}
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-sm font-accent font-bold text-brand-900 leading-none group-hover:text-accent-600 transition-colors">{user?.displayName}</p>
              <p className="text-[10px] text-brand-400 font-accent font-bold uppercase tracking-widest mt-2 opacity-70">{user?.role}</p>
            </div>
            <ChevronDown className={`w-4 h-4 text-brand-300 transition-all group-hover:text-brand-900 ${showUserMenu ? 'rotate-180' : ''}`} />
          </button>

          <AnimatePresence>
            {showUserMenu && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowUserMenu(false)} 
                />
                <motion.div
                  initial={{ opacity: 0, y: 15, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 15, scale: 0.95 }}
                  className="absolute right-0 mt-4 w-72 bg-white border border-brand-100 rounded-[2rem] shadow-2xl z-50 overflow-hidden ring-1 ring-brand-900/5"
                >
                  <div className="p-8 border-b border-brand-50 bg-brand-50/30">
                    <p className="text-lg font-display font-bold text-brand-900 tracking-tight">{user?.displayName}</p>
                    <p className="text-xs text-brand-400 font-medium truncate mt-1">{user?.email}</p>
                  </div>
                  <div className="p-4">
                    <Link
                      to="/profile"
                      className="flex items-center space-x-4 px-5 py-4 text-sm font-accent font-bold text-brand-600 hover:text-brand-900 hover:bg-brand-50 rounded-2xl transition-all group"
                      onClick={() => setShowUserMenu(false)}
                    >
                      <UserIcon className="w-5 h-5 opacity-40 group-hover:opacity-100 transition-opacity" />
                      <span>My Profile</span>
                    </Link>
                    <Link
                      to="/settings"
                      className="flex items-center space-x-4 px-5 py-4 text-sm font-accent font-bold text-brand-600 hover:text-brand-900 hover:bg-brand-50 rounded-2xl transition-all group"
                      onClick={() => setShowUserMenu(false)}
                    >
                      <Settings className="w-5 h-5 opacity-40 group-hover:opacity-100 transition-opacity" />
                      <span>Settings</span>
                    </Link>
                  </div>
                  <div className="p-4 border-t border-brand-50 bg-brand-50/10">
                    <button
                      onClick={() => {
                        signOut();
                        navigate('/login');
                      }}
                      className="w-full flex items-center space-x-4 px-5 py-4 text-sm font-accent font-bold text-accent-600 hover:bg-accent-50 rounded-2xl transition-all group"
                    >
                      <LogOut className="w-5 h-5 opacity-40 group-hover:opacity-100 transition-opacity" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
}
