import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, updateDoc, deleteDoc, where, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../components/Auth/AuthContext';
import { User, Engagement } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Shield, 
  Users, 
  CheckCircle, 
  XCircle, 
  Trash2, 
  ExternalLink, 
  MoreVertical, 
  Search, 
  Filter,
  BarChart3,
  TrendingUp,
  UserCheck,
  AlertCircle,
  Eye
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '../lib/utils';

export default function Admin() {
  const { user: currentUser, isAuthReady } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [pendingEngagements, setPendingEngagements] = useState<Engagement[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEngagement, setSelectedEngagement] = useState<Engagement | null>(null);

  useEffect(() => {
    if (!isAuthReady) return;
    if (!currentUser || currentUser.role !== 'Admin') {
      setLoading(false);
      return;
    }

    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setUsers(snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as unknown as User)));
    });

    const unsubEngs = onSnapshot(
      query(collection(db, 'engagements'), where('status', '==', 'logged')),
      (snapshot) => {
        setPendingEngagements(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as unknown as Engagement)));
      }
    );

    setLoading(false);
    return () => {
      unsubUsers();
      unsubEngs();
    };
  }, [currentUser]);

  const handleVerification = async (eng: Engagement, status: 'verified' | 'rejected') => {
    try {
      await updateDoc(doc(db, 'engagements', eng.id), { status });
      
      // Create Notification for the professional
      await addDoc(collection(db, 'notifications'), {
        userId: eng.professionalId,
        content: `Your engagement "${eng.title}" has been ${status}.`,
        type: status === 'verified' ? 'success' : 'error',
        read: false,
        createdAt: new Date().toISOString()
      });

      toast.success(`Engagement ${status} successfully`);
      setSelectedEngagement(null);
    } catch (err) {
      console.error(err);
      toast.error('Failed to update engagement status');
    }
  };

  const handleRoleChange = async (userId: string, newRole: string) => {
    try {
      await updateDoc(doc(db, 'users', userId), { role: newRole });
      toast.success(`User role updated to ${newRole}`);
    } catch (err) {
      console.error(err);
      toast.error('Failed to update user role');
    }
  };

  const deleteUser = async (id: string) => {
    if (window.confirm('Are you sure you want to permanently delete this user? This action cannot be undone.')) {
      try {
        await deleteDoc(doc(db, 'users', id));
        toast.success('User deleted successfully');
      } catch (err) {
        toast.error('Failed to delete user');
      }
    }
  };

  const filteredUsers = users.filter(u => 
    (u.displayName || '').toLowerCase().includes((searchTerm || '').toLowerCase()) ||
    (u.email || '').toLowerCase().includes((searchTerm || '').toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (currentUser?.role !== 'Admin') {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center">
          <AlertCircle className="w-8 h-8 text-red-600" />
        </div>
        <h1 className="text-2xl font-bold text-slate-900">Access Denied</h1>
        <p className="text-slate-500">You do not have the required permissions to view this page.</p>
      </div>
    );
  }

  return (
    <div className="space-y-10 pb-20">
      {/* Header & Stats */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 bg-white p-10 rounded-[3rem] border border-brand-100 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-50/30 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold text-brand-900 tracking-tight flex items-center">
            <Shield className="w-10 h-10 text-accent-500 mr-4" />
            Elite Command Center
          </h1>
          <p className="text-brand-500 font-accent font-medium mt-2 text-lg">Orchestrate platform governance and validate professional excellence.</p>
        </div>
        <div className="flex space-x-4 relative z-10">
          <div className="bg-brand-50 px-6 py-3 rounded-2xl border border-brand-100 shadow-sm flex items-center space-x-4">
            <div className="p-2.5 bg-white rounded-xl shadow-sm">
              <Users className="w-5 h-5 text-brand-900" />
            </div>
            <div>
              <p className="text-[9px] font-accent font-bold text-brand-300 uppercase tracking-widest">Total Assets</p>
              <p className="text-lg font-display font-bold text-brand-900">{users.length}</p>
            </div>
          </div>
          <div className="bg-accent-50 px-6 py-3 rounded-2xl border border-accent-100 shadow-sm flex items-center space-x-4">
            <div className="p-2.5 bg-white rounded-xl shadow-sm">
              <TrendingUp className="w-5 h-5 text-accent-600" />
            </div>
            <div>
              <p className="text-[9px] font-accent font-bold text-accent-600 uppercase tracking-widest">Pending</p>
              <p className="text-lg font-display font-bold text-accent-700">{pendingEngagements.length}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* User Management Table */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-[3rem] border border-brand-100 shadow-xl overflow-hidden">
            <div className="p-10 border-b border-brand-50 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight flex items-center">
                <Users className="w-7 h-7 mr-4 text-accent-500" /> 
                Asset Directory
              </h3>
              <div className="relative w-full md:w-80">
                <Search className="w-5 h-5 absolute left-5 top-1/2 -translate-y-1/2 text-brand-200" />
                <input
                  type="text"
                  placeholder="Search elite assets..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-14 pr-6 py-4 bg-brand-50/30 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="text-[10px] text-brand-300 font-accent font-bold uppercase tracking-[0.2em] bg-brand-50/30 border-b border-brand-50">
                    <th className="px-10 py-6">Professional Identity</th>
                    <th className="px-10 py-6">Architectural Role</th>
                    <th className="px-10 py-6">Onboarding</th>
                    <th className="px-10 py-6 text-right">Operations</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-brand-50">
                  {filteredUsers.map((u) => (
                    <tr key={u.uid} className="hover:bg-brand-50/20 transition-colors group">
                      <td className="px-10 py-6">
                        <div className="flex items-center">
                          <div className="w-12 h-12 rounded-2xl bg-brand-900 flex items-center justify-center text-accent-400 font-display font-bold text-lg mr-5 overflow-hidden border border-brand-800 shadow-lg">
                            {u.photoURL ? <img src={u.photoURL} className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : u.displayName[0]}
                          </div>
                          <div>
                            <p className="text-base font-display font-bold text-brand-900 group-hover:text-accent-600 transition-colors">{u.displayName}</p>
                            <p className="text-[10px] text-brand-400 font-accent font-bold uppercase tracking-widest mt-1">{u.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-10 py-6">
                        <select
                          value={u.role}
                          onChange={(e) => handleRoleChange(u.uid, e.target.value)}
                          className={cn(
                            "px-4 py-2 rounded-xl text-[9px] font-accent font-bold uppercase tracking-[0.2em] border-none focus:ring-4 focus:ring-accent-500/10 outline-none cursor-pointer transition-all shadow-sm",
                            u.role === 'Admin' ? 'bg-brand-900 text-accent-400' :
                            u.role === 'Organizer' ? 'bg-accent-50 text-accent-600' :
                            'bg-brand-50 text-brand-600'
                          )}
                        >
                          <option value="Professional">Professional</option>
                          <option value="Organizer">Organizer</option>
                          <option value="Admin">Admin</option>
                        </select>
                      </td>
                      <td className="px-10 py-6 text-[10px] text-brand-400 font-accent font-bold uppercase tracking-widest">
                        {new Date(u.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </td>
                      <td className="px-10 py-6 text-right">
                        <button 
                          onClick={() => deleteUser(u.uid)}
                          className="p-3 text-brand-200 hover:text-red-600 hover:bg-red-50 rounded-2xl transition-all"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Pending Verifications Sidebar */}
        <div className="space-y-8">
          <div className="bg-white rounded-[2.5rem] border border-brand-100 shadow-xl overflow-hidden">
            <div className="p-8 border-b border-brand-50 flex items-center justify-between bg-brand-50/20">
              <h3 className="text-xl font-display font-bold text-brand-900 tracking-tight flex items-center">
                <CheckCircle className="w-6 h-6 mr-3 text-accent-500" /> 
                Pending Validation
              </h3>
              <span className="bg-accent-500 text-white text-[10px] font-accent font-bold px-3 py-1 rounded-full shadow-lg shadow-accent-200">
                {pendingEngagements.length}
              </span>
            </div>
            <div className="p-6 space-y-6 max-h-[700px] overflow-y-auto custom-scrollbar">
              {pendingEngagements.length === 0 ? (
                <div className="text-center py-20">
                  <CheckCircle className="w-16 h-16 text-brand-50 mx-auto mb-6" />
                  <p className="text-[10px] text-brand-300 font-accent font-bold uppercase tracking-[0.2em]">All protocols verified.</p>
                </div>
              ) : (
                pendingEngagements.map((eng) => (
                  <motion.div 
                    layout
                    key={eng.id} 
                    className="p-6 bg-brand-50/30 rounded-[2rem] border border-brand-50 space-y-6 hover:border-accent-400 transition-all duration-500 group"
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1 min-w-0">
                        <p className="font-display font-bold text-brand-900 text-lg truncate group-hover:text-accent-600 transition-colors">{eng.title}</p>
                        <p className="text-[9px] text-brand-400 font-accent font-bold uppercase tracking-widest mt-1">{eng.role} • {eng.venue}</p>
                      </div>
                      <button 
                        onClick={() => setSelectedEngagement(eng)}
                        className="p-2.5 text-brand-200 hover:text-accent-600 hover:bg-white rounded-xl transition-all shadow-sm"
                      >
                        <Eye className="w-5 h-5" />
                      </button>
                    </div>
                    <div className="flex space-x-3">
                      <button 
                        onClick={() => handleVerification(eng, 'verified')}
                        className="flex-1 bg-white text-emerald-600 border border-emerald-100 text-[9px] font-accent font-bold uppercase tracking-widest py-3 rounded-xl hover:bg-emerald-600 hover:text-white transition-all shadow-sm"
                      >
                        Validate
                      </button>
                      <button 
                        onClick={() => handleVerification(eng, 'rejected')}
                        className="flex-1 bg-white text-red-600 border border-red-100 text-[9px] font-accent font-bold uppercase tracking-widest py-3 rounded-xl hover:bg-red-600 hover:text-white transition-all shadow-sm"
                      >
                        Decline
                      </button>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Engagement Detail Modal */}
      <AnimatePresence>
        {selectedEngagement && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedEngagement(null)}
              className="absolute inset-0 bg-brand-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[3rem] w-full max-w-3xl overflow-hidden shadow-2xl border border-brand-100"
            >
              <div className="p-10 border-b border-brand-50 flex justify-between items-center bg-brand-50/20">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-white rounded-2xl shadow-sm">
                    <CheckCircle className="w-6 h-6 text-accent-500" />
                  </div>
                  <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Validation Dossier</h3>
                </div>
                <button 
                  onClick={() => setSelectedEngagement(null)}
                  className="p-3 hover:bg-brand-100 rounded-2xl transition-all"
                >
                  <XCircle className="w-8 h-8 text-brand-200" />
                </button>
              </div>
              <div className="p-12 space-y-10 max-h-[70vh] overflow-y-auto custom-scrollbar">
                <div className="grid grid-cols-2 gap-10">
                  <div className="space-y-2">
                    <p className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Engagement Title</p>
                    <p className="text-xl font-display font-bold text-brand-900 bg-brand-50/30 p-4 rounded-2xl border border-brand-50">{selectedEngagement.title}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Architectural Role</p>
                    <p className="text-xl font-display font-bold text-brand-900 bg-brand-50/30 p-4 rounded-2xl border border-brand-50">{selectedEngagement.role}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Elite Venue</p>
                    <p className="text-xl font-display font-bold text-brand-900 bg-brand-50/30 p-4 rounded-2xl border border-brand-50">{selectedEngagement.venue}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Temporal Marker</p>
                    <p className="text-xl font-display font-bold text-brand-900 bg-brand-50/30 p-4 rounded-2xl border border-brand-50">{new Date(selectedEngagement.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <p className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Strategic Description</p>
                  <p className="text-base text-brand-500 leading-relaxed font-accent font-medium bg-brand-50/30 p-6 rounded-[2rem] border border-brand-50 italic opacity-80">{selectedEngagement.description}</p>
                </div>

                {selectedEngagement.certificateUrl && (
                  <div className="space-y-4">
                    <p className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Empirical Evidence / Credentials</p>
                    <div className="relative group rounded-[2.5rem] overflow-hidden border border-brand-100 aspect-video bg-brand-50 flex items-center justify-center shadow-inner">
                      {selectedEngagement.certificateUrl.match(/\.(jpg|jpeg|png|gif)$/i) ? (
                        <img 
                          src={selectedEngagement.certificateUrl} 
                          alt="Certificate" 
                          className="w-full h-full object-contain"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="text-center">
                          <ExternalLink className="w-16 h-16 text-brand-100 mx-auto mb-4" />
                          <p className="text-[10px] text-brand-300 font-accent font-bold uppercase tracking-widest">Encrypted PDF Document</p>
                        </div>
                      )}
                      <a 
                        href={selectedEngagement.certificateUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="absolute inset-0 bg-brand-900/40 opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center text-accent-400 font-accent font-bold uppercase tracking-[0.2em] text-xs backdrop-blur-sm"
                      >
                        <ExternalLink className="w-6 h-6 mr-3" />
                        Access Full Dossier
                      </a>
                    </div>
                  </div>
                )}
              </div>
              <div className="p-10 bg-brand-50/20 border-t border-brand-50 flex space-x-6">
                <button 
                  onClick={() => handleVerification(selectedEngagement, 'verified')}
                  className="btn-gold flex-1 py-5 text-[10px]"
                >
                  Authorize Validation
                </button>
                <button 
                  onClick={() => handleVerification(selectedEngagement, 'rejected')}
                  className="flex-1 bg-white text-red-600 border border-red-100 font-accent font-bold uppercase tracking-[0.2em] text-[10px] py-5 rounded-2xl hover:bg-red-600 hover:text-white transition-all shadow-lg shadow-red-100"
                >
                  Decline Validation
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
