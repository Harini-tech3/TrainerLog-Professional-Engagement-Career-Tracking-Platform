import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, getDoc, addDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../components/Auth/AuthContext';
import { Invitation, Event, User } from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mail, 
  Check, 
  X, 
  Calendar, 
  MapPin, 
  User as UserIcon, 
  Clock, 
  AlertCircle,
  CheckCircle2,
  XCircle,
  ArrowRight,
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '../lib/utils';
import Footer from '../components/Layout/Footer';

export default function Invitations() {
  const { user, isAuthReady } = useAuth();
  const [invitations, setInvitations] = useState<(Invitation & { event?: Event, organizer?: User })[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthReady) return;
    if (!user) {
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, 'invitations'),
      where('professionalId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const invs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Invitation));
      
      const enrichedInvs = await Promise.all(invs.map(async (inv) => {
        try {
          let eventData = undefined;
          let organizerData = undefined;

          if (inv.eventId) {
            const eventDoc = await getDoc(doc(db, 'events', inv.eventId));
            if (eventDoc.exists()) {
              eventData = { id: eventDoc.id, ...eventDoc.data() } as Event;
            }
          }

          if (inv.organizerId && inv.organizerId !== 'system-seed-organizer') {
            const organizerDoc = await getDoc(doc(db, 'users', inv.organizerId));
            if (organizerDoc.exists()) {
              organizerData = { id: organizerDoc.id, ...organizerDoc.data() } as unknown as User;
            }
          }

          return { 
            ...inv, 
            event: eventData,
            organizer: organizerData
          };
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `events/${inv.eventId} or users/${inv.organizerId}`);
          return inv;
        }
      }));

      setInvitations(enrichedInvs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'invitations');
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (!loading && invitations.length === 0 && user) {
      seedExampleInvitations();
    }
  }, [loading, invitations.length, user]);

  const handleStatus = async (id: string, status: 'accepted' | 'rejected') => {
    try {
      await updateDoc(doc(db, 'invitations', id), { status })
        .catch(error => handleFirestoreError(error, OperationType.UPDATE, `invitations/${id}`));
      toast.success(`Invitation ${status}`);
    } catch (err) {
      console.error(err);
      toast.error('Failed to update invitation status');
    }
  };

  const seedExampleInvitations = async () => {
    if (!user) return;
    try {
      // Create the invitation directly with denormalized data to avoid permission issues with other collections
      // The security rules allow users to create invitations where they are the professionalId
      await addDoc(collection(db, 'invitations'), {
        professionalId: user.uid,
        organizerId: 'system-seed-organizer',
        organizerName: 'Global Tech Events',
        eventTitle: 'Future of AI Summit 2026',
        status: 'pending',
        message: 'We would love for you to be a keynote speaker at our upcoming summit! Your expertise in the field is highly valued.',
        createdAt: serverTimestamp(),
        priority: 'high'
      }).catch(error => handleFirestoreError(error, OperationType.CREATE, 'invitations'));

      toast.success('Example invitation created!');
    } catch (err) {
      console.error(err);
      toast.error('Failed to seed example invitation');
    }
  };

  return (
    <div className="space-y-10 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 bg-white p-10 rounded-[3rem] border border-brand-100 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-50/30 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold text-brand-900 tracking-tight">Elite Invitations</h1>
          <p className="text-brand-500 font-accent font-medium mt-2 text-lg">Review and curate collaboration requests from global organizers.</p>
        </div>
        <div className="flex items-center gap-4 relative z-10">
          <button 
            onClick={seedExampleInvitations}
            className="flex items-center px-6 py-3 bg-brand-50 text-brand-600 rounded-2xl text-[10px] font-accent font-bold uppercase tracking-widest hover:bg-brand-100 transition-all border border-brand-100"
          >
            <Sparkles className="w-4 h-4 mr-3 text-accent-500" />
            Seed Elite Invite
          </button>
        </div>
      </div>

      {loading ? (
        <div className="space-y-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-white p-10 rounded-[3rem] border border-brand-50 shadow-sm animate-pulse">
              <div className="h-8 bg-brand-50 rounded-xl w-1/3 mb-6" />
              <div className="h-4 bg-brand-50 rounded-xl w-1/2 mb-10" />
              <div className="h-24 bg-brand-50/30 rounded-[2rem]" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-8">
          {invitations.length === 0 ? (
            <div className="bg-white p-24 rounded-[3rem] border-2 border-dashed border-brand-100 text-center">
              <div className="w-24 h-24 bg-brand-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8">
                <Mail className="w-12 h-12 text-brand-100" />
              </div>
              <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight mb-3">No Invitations Discovered</h3>
              <p className="text-brand-500 max-w-xs mx-auto font-accent font-medium italic opacity-80">
                When elite organizers request your presence, their invitations will materialize here for your review.
              </p>
            </div>
          ) : (
            <AnimatePresence>
              {invitations.map((inv) => (
                <motion.div
                  key={inv.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="premium-card overflow-hidden group"
                >
                  <div className="p-10">
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-10">
                      <div className="flex-1 space-y-8">
                        <div className="flex items-center space-x-4">
                          <div className={cn(
                            "px-4 py-1.5 rounded-full text-[9px] font-accent font-bold uppercase tracking-[0.2em] shadow-sm",
                            inv.status === 'accepted' ? "bg-brand-900 text-accent-400" :
                            inv.status === 'rejected' ? "bg-red-50 text-red-600" :
                            "bg-brand-50 text-brand-600"
                          )}>
                            {inv.status}
                          </div>
                          <span className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] flex items-center">
                            <Clock className="w-4 h-4 mr-2 text-brand-200" />
                            {new Date(inv.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                          </span>
                        </div>

                        <div>
                          <h3 className="text-3xl font-display font-bold text-brand-900 tracking-tight mb-3">
                            {inv.eventTitle || inv.event?.title || 'Elite Collaboration Request'}
                          </h3>
                          <div className="flex flex-wrap items-center gap-y-3 gap-x-8 text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">
                            <span className="flex items-center">
                              <Calendar className="w-4 h-4 mr-2 text-accent-500" />
                              {inv.event?.date ? new Date(inv.event.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : 'Schedule TBD'}
                            </span>
                            <span className="flex items-center">
                              <MapPin className="w-4 h-4 mr-2 text-accent-500" />
                              {inv.event?.location || 'Venue TBD'}
                            </span>
                            <span className="flex items-center">
                              <UserIcon className="w-4 h-4 mr-2 text-accent-500" />
                              Host: <span className="text-brand-900 ml-2">{inv.organizerName || inv.organizer?.displayName || 'Elite Organizer'}</span>
                            </span>
                          </div>
                        </div>

                        <div className="bg-brand-50/30 p-8 rounded-[2rem] border border-brand-100 relative">
                          <MessageSquare className="absolute top-6 right-6 w-6 h-6 text-brand-100 opacity-50" />
                          <p className="text-[9px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] mb-3">Organizer's Narrative</p>
                          <p className="text-sm text-brand-600 leading-relaxed font-accent font-medium italic opacity-80">
                            "{inv.message}"
                          </p>
                        </div>
                      </div>

                      <div className="flex lg:flex-col gap-4">
                        {inv.status === 'pending' ? (
                          <>
                            <button
                              onClick={() => handleStatus(inv.id, 'accepted')}
                              className="btn-gold flex-1 lg:w-48 py-4 text-[10px]"
                            >
                              <Check className="w-4 h-4 mr-3" />
                              Accept Invite
                            </button>
                            <button
                              onClick={() => handleStatus(inv.id, 'rejected')}
                              className="btn-secondary flex-1 lg:w-48 py-4 text-[10px]"
                            >
                              <X className="w-4 h-4 mr-3" />
                              Decline
                            </button>
                          </>
                        ) : (
                          <div className={cn(
                            "flex items-center px-8 py-4 rounded-2xl font-accent font-bold text-[10px] uppercase tracking-widest shadow-sm",
                            inv.status === 'accepted' ? "bg-brand-900 text-accent-400" : "bg-red-50 text-red-600"
                          )}>
                            {inv.status === 'accepted' ? (
                              <CheckCircle2 className="w-5 h-5 mr-3" />
                            ) : (
                              <XCircle className="w-5 h-5 mr-3" />
                            )}
                            Invitation {inv.status}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          )}
        </div>
      )}
    </div>
  );
}
