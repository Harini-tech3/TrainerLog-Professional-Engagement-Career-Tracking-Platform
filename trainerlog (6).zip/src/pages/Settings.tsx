import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Settings as SettingsIcon, 
  Lock, 
  Bell, 
  Shield, 
  Eye, 
  Globe, 
  Smartphone,
  ChevronRight,
  CheckCircle2,
  Terminal
} from 'lucide-react';
import { useAuth } from '../components/Auth/AuthContext';
import { db } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { toast } from 'sonner';
import { cn } from '../lib/utils';

export default function Settings() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('account');

  const tabs = [
    { id: 'account', name: 'Account Settings', icon: SettingsIcon },
    { id: 'security', name: 'Security & Password', icon: Lock },
    { id: 'notifications', name: 'Notification Preferences', icon: Bell },
    { id: 'privacy', name: 'Privacy & Visibility', icon: Shield },
    { id: 'testing', name: 'Developer / Testing', icon: Terminal },
  ];

  const handleSave = () => {
    toast.success('Settings saved successfully');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 bg-white p-10 rounded-[3rem] border border-brand-100 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-50/30 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold text-brand-900 tracking-tight">Elite Configuration</h1>
          <p className="text-brand-500 font-accent font-medium mt-2 text-lg">Orchestrate your account preferences and security protocols.</p>
        </div>
        <button
          onClick={handleSave}
          className="btn-gold px-10 py-4 text-[10px] relative z-10"
        >
          <CheckCircle2 className="w-4 h-4 mr-3" />
          Save Configurations
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-10">
        {/* Sidebar Tabs */}
        <div className="lg:w-80 flex-shrink-0">
          <div className="bg-white rounded-[2.5rem] border border-brand-100 p-3 space-y-2 shadow-xl sticky top-24">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "w-full flex items-center space-x-4 px-6 py-4 rounded-2xl text-[10px] font-accent font-bold uppercase tracking-[0.2em] transition-all duration-300",
                  activeTab === tab.id 
                    ? "bg-brand-900 text-accent-400 shadow-lg shadow-brand-200" 
                    : "text-brand-400 hover:bg-brand-50 hover:text-brand-900"
                )}
              >
                <tab.icon className={cn("w-5 h-5", activeTab === tab.id ? "text-accent-400" : "text-brand-200")} />
                <span>{tab.name}</span>
                {activeTab === tab.id && <ChevronRight className="w-4 h-4 ml-auto text-accent-400" />}
              </button>
            ))}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 space-y-8">
          {activeTab === 'account' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              <div className="bg-white rounded-[3rem] border border-brand-100 p-10 shadow-xl space-y-10">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Personal Dossier</h3>
                  <div className="h-px flex-1 bg-brand-50 mx-8" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Full Identity</label>
                    <input 
                      type="text" 
                      defaultValue={user?.displayName}
                      className="w-full px-6 py-4 bg-brand-50/30 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Secure Email</label>
                    <input 
                      type="email" 
                      defaultValue={user?.email}
                      disabled
                      className="w-full px-6 py-4 bg-brand-50 border border-brand-100 rounded-2xl text-sm font-accent font-medium text-brand-300 cursor-not-allowed"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-[3rem] border border-brand-100 p-10 shadow-xl space-y-10">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Regional Logistics</h3>
                  <div className="h-px flex-1 bg-brand-50 mx-8" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Primary Language</label>
                    <div className="relative">
                      <Globe className="w-5 h-5 absolute left-5 top-1/2 -translate-y-1/2 text-brand-200" />
                      <select className="w-full pl-14 pr-6 py-4 bg-brand-50/30 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all appearance-none">
                        <option>English (Global)</option>
                        <option>Spanish (Elite)</option>
                        <option>French (Premium)</option>
                      </select>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Temporal Zone</label>
                    <select className="w-full px-6 py-4 bg-brand-50/30 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all appearance-none">
                      <option>(GMT-08:00) Pacific Standard</option>
                      <option>(GMT+00:00) Universal Coordinate</option>
                      <option>(GMT+05:30) India Standard</option>
                    </select>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'security' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              <div className="bg-white rounded-[3rem] border border-brand-100 p-10 shadow-xl space-y-10">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Access Credentials</h3>
                  <div className="h-px flex-1 bg-brand-50 mx-8" />
                </div>
                <div className="space-y-6 max-w-lg">
                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Current Protocol</label>
                    <input 
                      type="password" 
                      className="w-full px-6 py-4 bg-brand-50/30 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">New Protocol</label>
                    <input 
                      type="password" 
                      className="w-full px-6 py-4 bg-brand-50/30 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Verify New Protocol</label>
                    <input 
                      type="password" 
                      className="w-full px-6 py-4 bg-brand-50/30 border border-brand-100 rounded-2xl text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all"
                    />
                  </div>
                  <button className="text-[10px] font-accent font-bold text-brand-900 hover:text-accent-600 transition-colors uppercase tracking-[0.2em] underline underline-offset-8 mt-4 block">
                    Initiate Recovery Protocol
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-[3rem] border border-brand-100 p-10 shadow-xl space-y-10">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Multi-Factor Authentication</h3>
                    <span className="px-4 py-1 rounded-full text-[9px] font-accent font-bold bg-brand-50 text-brand-400 uppercase tracking-widest">Inactive</span>
                  </div>
                  <div className="h-px flex-1 bg-brand-50 mx-8" />
                </div>
                <div className="flex items-start space-x-8 p-8 bg-brand-50/30 rounded-[2rem] border border-brand-100">
                  <div className="p-5 bg-white rounded-2xl shadow-lg border border-brand-50">
                    <Smartphone className="w-8 h-8 text-accent-500" />
                  </div>
                  <div className="flex-1">
                    <p className="text-xl font-display font-bold text-brand-900">SMS Verification</p>
                    <p className="text-sm text-brand-500 mt-2 font-accent font-medium leading-relaxed">Augment your security perimeter by requiring a temporal code dispatched to your mobile device.</p>
                  </div>
                  <button className="btn-gold px-8 py-4 text-[10px]">
                    Activate
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'testing' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              <div className="bg-white rounded-[3rem] border border-brand-100 p-10 shadow-xl space-y-10">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-accent-50 rounded-xl">
                      <Terminal className="w-6 h-6 text-accent-600" />
                    </div>
                    <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Elite Testing Environment</h3>
                  </div>
                  <div className="h-px flex-1 bg-brand-50 mx-8" />
                </div>
                
                <div className="space-y-8">
                  <div className="p-8 bg-accent-50/50 rounded-[2rem] border border-accent-100">
                    <p className="text-lg font-display font-bold text-accent-900">Persona Simulation</p>
                    <p className="text-sm text-accent-700 mt-2 font-accent font-medium leading-relaxed italic opacity-80">Toggle your architectural role to validate multi-dimensional application flows.</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    {['Professional', 'Organizer', 'Admin'].map((role) => (
                      <button
                        key={role}
                        onClick={async () => {
                          if (!user) return;
                          try {
                            await updateDoc(doc(db, 'users', user.uid), { role });
                            toast.success(`Persona shifted to ${role}. Architectural realignment complete.`);
                          } catch (err) {
                            toast.error('Failed to shift persona');
                          }
                        }}
                        className={cn(
                          "p-8 rounded-[2rem] border-2 transition-all duration-500 text-center group",
                          user?.role === role 
                            ? "border-brand-900 bg-brand-900 text-accent-400 shadow-2xl scale-105" 
                            : "border-brand-50 hover:border-accent-400 bg-brand-50/30 text-brand-400 hover:text-brand-900"
                        )}
                      >
                        <p className="text-lg font-display font-bold">{role}</p>
                        {user?.role === role && <p className="text-[9px] font-accent font-bold uppercase tracking-[0.2em] mt-2 text-accent-500">Active Persona</p>}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-[3rem] border border-brand-100 p-10 shadow-xl space-y-8">
                <h3 className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] ml-2">Architectural Debug Dossier</h3>
                <div className="bg-brand-900 p-8 rounded-[2rem] font-mono text-[10px] text-accent-400 overflow-x-auto shadow-inner">
                  <pre className="opacity-80">{JSON.stringify(user, null, 2)}</pre>
                </div>
              </div>
            </motion.div>
          )}

          {(activeTab === 'notifications' || activeTab === 'privacy') && (
            <div className="bg-white rounded-[3rem] border border-brand-100 p-24 shadow-xl text-center">
              <div className="w-24 h-24 bg-brand-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8 border border-brand-100">
                <Eye className="w-12 h-12 text-brand-100" />
              </div>
              <h3 className="text-3xl font-display font-bold text-brand-900 tracking-tight">Under Elite Development</h3>
              <p className="text-brand-500 mt-4 font-accent font-medium text-lg italic opacity-80">We are currently refining these protocols to ensure an unparalleled experience.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
