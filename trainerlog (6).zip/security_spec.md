# Security Specification - TrainerLog

## Data Invariants
1. A User must have a unique UID matching their Auth UID.
2. A Profile must belong to a valid User.
3. An Engagement must have a `professionalId` matching the creator's UID.
4. An Invitation must be created by an Organizer or a Professional for themselves.
5. An Event must be created by an Organizer.
6. A Review must be created by an Organizer for a Professional they have an engagement with.
7. Timestamps (`createdAt`, `updatedAt`) must be set by the server.
8. Status fields must follow strict state transitions.

## The "Dirty Dozen" Payloads (Denial Targets)

1. **Identity Theft (Engagement)**: User A tries to log an engagement for User B.
   - Path: `/engagements/{id}`
   - Payload: `{ "professionalId": "user_b_uid", "title": "...", ... }`
   - Expect: `PERMISSION_DENIED`

2. **Privilege Escalation (User)**: A Professional tries to make themselves an Admin.
   - Path: `/users/{my_uid}`
   - Payload: `{ "role": "Admin", ... }`
   - Expect: `PERMISSION_DENIED`

3. **Orphaned Write (Engagement)**: Creating an engagement without a required field.
   - Path: `/engagements/{id}`
   - Payload: `{ "professionalId": "my_uid", "title": "Title" }` (missing date)
   - Expect: `PERMISSION_DENIED`

4. **Resource Poisoning (Engagement)**: Injecting a massive string into the title.
   - Path: `/engagements/{id}`
   - Payload: `{ "title": "A".repeat(1000), ... }`
   - Expect: `PERMISSION_DENIED`

5. **State Shortcut (Engagement)**: Setting status to 'verified' directly.
   - Path: `/engagements/{id}` (Create)
   - Payload: `{ "status": "verified", ... }`
   - Expect: `PERMISSION_DENIED`

6. **Unauthorized Read (PII)**: User A tries to read User B's private settings/notifications. (Actually PII isolation pillar)
   - Path: `/notifications/{notif_id}` (where notif_id belongs to User B)
   - Expect: `PERMISSION_DENIED`

7. **Shadow Key Injection (Engagement)**: Adding a field like `isGlobalAdmin` to an engagement.
   - Path: `/engagements/{id}`
   - Payload: `{ "isGlobalAdmin": true, ... }`
   - Expect: `PERMISSION_DENIED`

8. **ID Poisoning (Event)**: Using a 2KB string as a document ID.
   - Path: `/events/{long_id}`
   - Expect: `PERMISSION_DENIED`

9. **Ghost Organizer (Engagement)**: Setting an `organizerId` that doesn't exist.
   - Path: `/engagements/{id}`
   - Expect: `PERMISSION_DENIED`

10. **Immutability Bypass (Engagement)**: Updating the `professionalId` of an existing engagement.
    - Path: `/engagements/{id}` (Update)
    - Payload: `{ "professionalId": "new_uid", ... }`
    - Expect: `PERMISSION_DENIED`

11. **Future Dating (Timestamp)**: Sending a client-side timestamp for `createdAt`.
    - Path: `/engagements/{id}`
    - Payload: `{ "createdAt": "2030-01-01T00:00:00Z", ... }`
    - Expect: `PERMISSION_DENIED`

12. **Blind Scraping (Notifications)**: Attempting to list all notifications without a filter.
    - Path: `/notifications` (List)
    - Expect: `PERMISSION_DENIED`
