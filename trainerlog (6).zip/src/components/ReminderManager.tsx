import React, { useEffect } from 'react';
import { collection, query, where, onSnapshot, updateDoc, doc, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from './Auth/AuthContext';
import { Reminder } from '../types';
import { toast } from 'sonner';
import { Bell } from 'lucide-react';

export default function ReminderManager() {
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'reminders'),
      where('userId', '==', user.uid),
      where('sent', '==', false)
    );

    const checkReminders = (docs: any[]) => {
      const now = new Date();
      docs.forEach(async (document) => {
        const reminder = { id: document.id, ...document.data() } as Reminder;
        const remindAt = new Date(reminder.remindAt);

        if (remindAt <= now) {
          // Show notification
          toast.info(`Reminder: ${reminder.eventTitle}`, {
            description: `You have an upcoming event!`,
            icon: <Bell className="w-4 h-4 text-indigo-600" />,
            duration: 10000,
          });

          // Mark as sent
          try {
            await updateDoc(doc(db, 'reminders', reminder.id), {
              sent: true
            });

            // Also add to notifications collection
            await addDoc(collection(db, 'notifications'), {
              userId: user.uid,
              content: `Reminder: ${reminder.eventTitle} is coming up!`,
              type: 'reminder',
              read: false,
              createdAt: new Date().toISOString()
            });
          } catch (err) {
            console.error('Failed to update reminder status:', err);
          }
        }
      });
    };

    let currentDocs: any[] = [];
    const unsubscribe = onSnapshot(q, (snapshot) => {
      currentDocs = snapshot.docs;
      checkReminders(currentDocs);
    });

    // Check every 30 seconds for reminders that become due as time passes
    const interval = setInterval(() => {
      checkReminders(currentDocs);
    }, 30000);

    return () => {
      unsubscribe();
      clearInterval(interval);
    };
  }, [user]);

  return null;
}
