import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './components/Auth/AuthContext';
import { LayoutProvider, useLayout } from './components/Layout/LayoutContext';
import Sidebar from './components/Layout/Sidebar';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import Engagements from './pages/Engagements';
import Invitations from './pages/Invitations';
import Events from './pages/Events';
import MyCollaborations from './pages/MyCollaborations';
import Admin from './pages/Admin';
import SearchProfessionals from './pages/SearchProfessionals';
import ProfessionalProfile from './pages/ProfessionalProfile';
import PublicPortfolio from './pages/PublicPortfolio';
import Settings from './pages/Settings';
import { Toaster } from 'sonner';
import { motion } from 'framer-motion';
import ErrorBoundary from './components/ErrorBoundary';
import Loading from './components/Loading';
import ReminderManager from './components/ReminderManager';

function PrivateRoute({ children, allowedRoles }: { children: React.ReactNode, allowedRoles?: string[] }) {
  const { firebaseUser, user, loading } = useAuth();
  if (loading) return <Loading />;
  if (!firebaseUser) return <Navigate to="/login" />;
  
  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    return <Navigate to="/" />;
  }
  
  return <>{children}</>;
}

function AppContent() {
  const { firebaseUser } = useAuth();
  const { isSidebarOpen } = useLayout();
  const location = useLocation();
  const isPublicPortfolio = location.pathname.startsWith('/u/');

  if (isPublicPortfolio) {
    return (
      <div className="min-h-screen bg-[#FDFDFB] scroll-smooth">
        <Toaster position="top-right" richColors closeButton />
        <Routes>
          <Route path="/u/:id" element={<PublicPortfolio />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    );
  }

  return (
    <div className="h-screen flex overflow-hidden bg-[#F8F9FA]">
      {/* Background aesthetic */}
      <div className="fixed inset-0 bg-gradient-to-br from-brand-50/50 via-white to-accent-50/30 pointer-events-none" />
      
      <Toaster position="top-right" richColors closeButton />
      {firebaseUser && <ReminderManager />}
      
      {firebaseUser && (
        <motion.div 
          initial={false}
          animate={{ width: isSidebarOpen ? 288 : 0 }}
          className="flex-shrink-0 h-full z-20 border-r border-brand-100/50 bg-white shadow-xl shadow-brand-900/5 overflow-hidden hidden lg:block"
        >
          <div className="w-72 h-full">
            <Sidebar />
          </div>
        </motion.div>
      )}
      
      {/* Mobile Sidebar overlay logic handled inside Sidebar component */}
      <div className="lg:hidden">
        <Sidebar />
      </div>

      <div className="flex-1 flex flex-col min-w-0 relative z-10 transition-all duration-300 ease-in-out">
        {firebaseUser && <Header />}
        <main className="flex-1 overflow-y-auto overflow-x-hidden scroll-smooth custom-scrollbar relative">
          <div className={firebaseUser ? "w-full max-w-[1920px] mx-auto p-4 md:p-8 lg:p-10" : ""}>
            <Routes>
              <Route path="/login" element={!firebaseUser ? <Login /> : <Navigate to="/" />} />
              <Route path="/signup" element={!firebaseUser ? <Signup /> : <Navigate to="/" />} />
              
              <Route path="/" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
              <Route path="/profile" element={<PrivateRoute><Profile /></PrivateRoute>} />
              <Route path="/engagements" element={<PrivateRoute allowedRoles={['Professional', 'Admin']}><Engagements /></PrivateRoute>} />
              <Route path="/invitations" element={<PrivateRoute allowedRoles={['Professional', 'Admin']}><Invitations /></PrivateRoute>} />
              <Route path="/collaborations" element={<PrivateRoute allowedRoles={['Organizer', 'Admin']}><MyCollaborations /></PrivateRoute>} />
              <Route path="/events" element={<PrivateRoute allowedRoles={['Organizer', 'Admin']}><Events /></PrivateRoute>} />
              <Route path="/search" element={<PrivateRoute allowedRoles={['Organizer', 'Admin']}><SearchProfessionals /></PrivateRoute>} />
              <Route path="/professional/:id" element={<PrivateRoute allowedRoles={['Organizer', 'Admin']}><ProfessionalProfile /></PrivateRoute>} />
              <Route path="/u/:id" element={<PublicPortfolio />} />
              <Route path="/admin" element={<PrivateRoute allowedRoles={['Admin']}><Admin /></PrivateRoute>} />
              <Route path="/settings" element={<PrivateRoute><Settings /></PrivateRoute>} />
              
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
            {firebaseUser && <Footer />}
          </div>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AuthProvider>
          <LayoutProvider>
            <AppContent />
          </LayoutProvider>
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
