import React from 'react';
import { Share2, Link as LinkIcon, Twitter, Linkedin, Facebook, QrCode } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

interface SharePortfolioProps {
  uid: string;
}

export default function SharePortfolio({ uid }: SharePortfolioProps) {
  const shareUrl = `${window.location.origin}/u/${uid}`;

  const copyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    toast.success('Portfolio link copied!', {
      description: 'You can now share your achievements with the world.',
    });
  };

  const shareActions = [
    { name: 'Twitter', icon: Twitter, color: 'text-sky-500', url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=Check out my professional portfolio on TrainerLog!` },
    { name: 'LinkedIn', icon: Linkedin, color: 'text-blue-700', url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}` },
    { name: 'Facebook', icon: Facebook, color: 'text-blue-600', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}` },
  ];

  return (
    <div className="premium-card p-8 group relative overflow-hidden">
      <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:scale-110 transition-transform duration-700">
        <Share2 className="w-40 h-40 text-accent-500" />
      </div>

      <div className="relative z-10 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-display font-bold text-brand-900 tracking-tight">Share Your Impact</h3>
            <p className="text-[10px] font-accent font-bold text-brand-400 mt-1 uppercase tracking-widest">Global Reach Protocol</p>
          </div>
          <div className="p-3 bg-brand-50 rounded-2xl group-hover:bg-accent-50 transition-colors">
            <Share2 className="w-5 h-5 text-accent-600" />
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex-1 px-5 py-3 bg-brand-50/50 border border-brand-100 rounded-2xl text-[10px] font-accent font-bold text-brand-400 truncate uppercase tracking-widest backdrop-blur-sm">
            {shareUrl}
          </div>
          <button 
            onClick={copyLink}
            className="p-4 bg-brand-900 text-accent-400 rounded-2xl hover:bg-brand-800 transition-all shadow-lg active:scale-95"
            title="Copy Portfolio Link"
          >
            <LinkIcon className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center gap-4 justify-between pt-2">
          <div className="flex gap-4">
            {shareActions.map((action) => (
              <a 
                key={action.name}
                href={action.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-white border border-brand-50 rounded-xl hover:shadow-md transition-all hover:-translate-y-1"
                title={`Share on ${action.name}`}
              >
                <action.icon className={`w-5 h-5 ${action.color}`} />
              </a>
            ))}
          </div>
          <button 
            className="flex items-center gap-2 text-[10px] font-accent font-bold text-brand-400 uppercase tracking-widest hover:text-accent-600 transition-colors"
            onClick={() => toast.info('QR Code generation coming soon to Elite Tier')}
          >
            <QrCode className="w-4 h-4" />
            Generate QR
          </button>
        </div>
      </div>
    </div>
  );
}
