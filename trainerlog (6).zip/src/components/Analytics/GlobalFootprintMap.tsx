import React from 'react';
import { 
  ComposableMap, 
  Geographies, 
  Geography, 
  Marker,
  Sphere,
  Graticule
} from "react-simple-maps";
import { Engagement } from '../../types';
import { motion } from 'framer-motion';
import { MapPin, Sparkles } from 'lucide-react';

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

// Map common venues to coordinates for the demo
const venueCoordinates: Record<string, [number, number]> = {
  // Expanded South India & Global Hubs
  "Chennai": [80.2707, 13.0827],
  "Coimbatore": [76.9616, 11.0168],
  "Madurai": [78.1198, 9.9252],
  "Trichy": [78.7047, 10.7905],
  "Tiruchirappalli": [78.7047, 10.7905],
  "Salem": [78.1460, 11.6643],
  "Tiruppur": [77.3411, 11.1085],
  "Erode": [77.7172, 11.3410],
  "Vellore": [79.1333, 12.9165],
  "Thoothukudi": [78.1348, 8.8052],
  "Tuticorin": [78.1348, 8.8052],
  "Tirunelveli": [77.7567, 8.7139],
  "Thanjavur": [79.1378, 10.7870],
  "Dindigul": [77.9806, 10.3673],
  "Ranipet": [79.3333, 12.9333],
  "Sivakasi": [77.8000, 9.4500],
  "Virudhunagar": [77.9500, 9.5800],
  "Kancheepuram": [79.7037, 12.8342],
  "Karur": [78.0833, 10.9500],
  "Namakkal": [78.1667, 11.2333],
  "Nagarcoil": [77.4103, 8.1833],
  "Hosur": [77.8268, 12.7409],
  "Bangalore": [77.5946, 12.9716],
  "Bengaluru": [77.5946, 12.9716],
  "Mysore": [76.6394, 12.2958],
  "Pondicherry": [79.8083, 11.9416],
  "Puducherry": [79.8083, 11.9416],
  "Hyderabad": [78.4867, 17.3850],
  "Mumbai": [72.8777, 19.0760],
  "Delhi": [77.1025, 28.7041],
  "Singapore": [103.8198, 1.3521],
  "Dubai": [55.2708, 25.2048]
};

interface GlobalFootprintMapProps {
  engagements: Engagement[];
}

export default function GlobalFootprintMap({ engagements }: GlobalFootprintMapProps) {
  // Map ALL engagements for a richer networking visualization
  const markers = engagements
    .map(e => {
      if (!e.venue) return null;
      const venueLower = e.venue.toLowerCase();
      
      // Match city name in venue string
      const matchedKey = Object.keys(venueCoordinates).find(city => 
        venueLower.includes(city.toLowerCase())
      );
      
      const coords = matchedKey ? venueCoordinates[matchedKey] : null;
      
      if (!coords) return null;
      return {
        id: e.id,
        name: e.title,
        coordinates: coords,
        city: matchedKey,
        isVerified: e.status === 'verified'
      };
    })
    .filter((m): m is any => m !== null);

  return (
    <div className="premium-card p-10 group overflow-hidden">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Regional Synergy Network</h3>
          <p className="text-[10px] font-accent font-bold text-brand-400 mt-1 uppercase tracking-widest italic">Tamil Nadu & South India Presence</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="px-3 py-1 bg-accent-50 border border-accent-100 rounded-full">
            <span className="text-[9px] font-accent font-bold text-accent-700 uppercase tracking-tighter">
              {markers.length} Active Nodes
            </span>
          </div>
          <div className="w-12 h-12 bg-brand-50 rounded-2xl flex items-center justify-center shadow-inner border border-brand-100">
            <MapPin className="w-6 h-6 text-accent-500" />
          </div>
        </div>
      </div>

      <div className="relative bg-[#1e263b] rounded-[2.5rem] p-6 shadow-2xl border border-brand-800 lg:h-[500px] flex items-center justify-center group/map overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(201,162,63,0.15),transparent)] pointer-events-none" />
        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,transparent,rgba(0,0,0,0.4))] pointer-events-none" />
        
        <ComposableMap
          projectionConfig={{
            rotate: [-78.5, -11, 0], // Centered on Tamil Nadu
            scale: 4500 // Ultra-zoom for Tamil Nadu focus
          }}
          style={{ width: "100%", height: "100%" }}
        >
          <Sphere stroke="#2d3748" strokeWidth={0.5} id="sphere" fill="transparent" />
          <Graticule stroke="#2d3748" strokeWidth={0.5} opacity={0.3} />
          
          <Geographies geography={geoUrl}>
            {({ geographies }) =>
              geographies.map((geo) => {
                const isIndia = geo.properties.name === "India";
                return (
                  <Geography 
                    key={geo.rsmKey} 
                    geography={geo} 
                    fill={isIndia ? "#31456a" : "#1e293b"}
                    stroke={isIndia ? "#5a6f9a" : "#2d3748"}
                    strokeWidth={isIndia ? 2 : 0.5}
                    style={{
                      default: { outline: "none" },
                      hover: { fill: "#2d3a5a", outline: "none" },
                      pressed: { outline: "none" }
                    }}
                  />
                );
              })
            }
          </Geographies>

          {markers.map((marker, i) => (
            <Marker key={marker.id} coordinates={marker.coordinates}>
              <motion.g
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: i * 0.1, type: "spring", stiffness: 260, damping: 20 }}
                className="cursor-pointer"
              >
                {/* Floating Pin Line */}
                <line x1="0" y1="0" x2="0" y2="-20" stroke={marker.isVerified ? "#c9a23f" : "#94a3b8"} strokeWidth="1.5" strokeDasharray="2 2" opacity={0.8} />
                
                {/* Outer Glow Effect */}
                <circle r={14} fill={marker.isVerified ? "#c9a23f" : "#94a3b8"} opacity={0.15} className={marker.isVerified ? "animate-pulse" : ""} />
                
                {/* Sonar Effect for Verified Only */}
                {marker.isVerified && (
                  <circle 
                    r={20} 
                    fill="none" 
                    stroke="#c9a23f" 
                    strokeWidth={0.5} 
                    className="animate-ping" 
                    style={{ animationDuration: '3s' }} 
                  />
                )}

                {/* Map Pin Icon */}
                <path
                  d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"
                  fill={marker.isVerified ? "#c9a23f" : "#475569"}
                  stroke="#ffffff"
                  strokeWidth="0.8"
                  transform="translate(-10, -28) scale(0.9)"
                  className="filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.5)]"
                />

                {/* Small checkmark inside verified pins */}
                {marker.isVerified && (
                   <path
                     d="M9 11l2 2 4-4"
                     stroke="white"
                     strokeWidth="1.5"
                     fill="none"
                     transform="translate(-11.5, -27) scale(0.7)"
                   />
                )}
                
                {/* Verification Base Dot */}
                <circle r={3} fill={marker.isVerified ? "#c9a23f" : "#475569"} stroke="#ffffff" strokeWidth={0.8} />
                
                {/* Secondary verification ring */}
                {marker.isVerified && (
                  <circle 
                    r={18} 
                    fill="none" 
                    stroke="#c9a23f" 
                    strokeWidth={0.5} 
                    strokeDasharray="3 3" 
                    className="animate-[spin_8s_linear_infinite]" 
                  />
                )}

                {/* HIGH VISIBILITY LABEL */}
                <g transform="translate(14, -18)">
                  <rect
                    x={-4}
                    y={-12}
                    width={marker.city.length * 7 + 12}
                    height={16}
                    fill={marker.isVerified ? "#c9a23f" : "#475569"}
                    rx={4}
                    className="opacity-95 shadow-2xl"
                  />
                  <text
                    x={4}
                    y={0}
                    className="text-[9px] font-accent font-black fill-white pointer-events-none"
                    style={{ textTransform: 'uppercase', letterSpacing: '0.05em' }}
                  >
                    {marker.city}
                  </text>
                </g>
              </motion.g>
            </Marker>
          ))}
        </ComposableMap>

        {/* Dynamic Help Overlay if no markers */}
        {markers.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="bg-brand-900/40 backdrop-blur-md border border-accent-500/30 p-6 rounded-3xl text-center max-w-xs animate-in fade-in zoom-in duration-700">
              <Sparkles className="w-8 h-8 text-accent-500 mx-auto mb-3" />
              <p className="text-xs font-accent font-bold text-accent-400 uppercase tracking-widest leading-loose">
                Map Ready for Expansion<br/>
                <span className="text-[10px] text-white opacity-60">Log engagements with venues like "Chennai" or "Coimbatore" to activate your networking nodes.</span>
              </p>
            </div>
          </div>
        )}
        
        {/* Region Labels overlay */}
        <div className="absolute top-8 left-8 space-y-3">
            <div className="flex items-center gap-3 group/leg">
                <div className="relative">
                  <div className="w-2.5 h-2.5 bg-accent-500 rounded-full shadow-[0_0_10px_rgba(201,162,63,0.8)]" />
                  <div className="absolute inset-0 w-2.5 h-2.5 bg-accent-500 rounded-full animate-ping opacity-40" />
                </div>
                <span className="text-[10px] font-accent font-bold text-accent-400 uppercase tracking-widest">Verified Nodes</span>
            </div>
            <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 bg-slate-500 rounded-full border border-slate-400" />
                <span className="text-[10px] font-accent font-bold text-slate-400 uppercase tracking-widest">Logged Activity</span>
            </div>
            <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 bg-white/5 rounded-full border border-white/10" />
                <span className="text-[9px] font-accent font-bold text-white/20 uppercase tracking-widest">Potential Markets</span>
            </div>
        </div>

        {/* Legend */}
        <div className="absolute bottom-8 right-8">
          <div className="bg-black/20 backdrop-blur-md border border-white/10 px-4 py-2 rounded-2xl">
            <p className="text-[8px] font-accent font-bold text-accent-500/60 uppercase tracking-widest text-center">Tamil Nadu Strategic Hub</p>
          </div>
        </div>
      </div>
    </div>
  );
}
