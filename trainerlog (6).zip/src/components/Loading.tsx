import React from 'react';
import { Loader2 } from 'lucide-react';

export default function Loading() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#FDFDFB] p-4 relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute -top-48 -left-48 w-[40rem] h-[40rem] bg-accent-50/50 rounded-full blur-[100px]" />
        <div className="absolute -bottom-48 -right-48 w-[40rem] h-[40rem] bg-brand-50/50 rounded-full blur-[100px]" />
      </div>

      <div className="relative z-10 flex flex-col items-center">
        <div className="relative mb-12">
          {/* Elite Spinner */}
          <div className="w-24 h-24 rounded-[2rem] border-2 border-brand-100 flex items-center justify-center relative">
            <div className="absolute inset-0 rounded-[2rem] border-t-2 border-accent-500 animate-[spin_2s_linear_infinite]" />
            <div className="w-12 h-12 bg-brand-900 rounded-2xl flex items-center justify-center shadow-xl border border-brand-800">
              <span className="text-accent-400 font-display font-bold text-lg tracking-tighter">TL</span>
            </div>
          </div>
          
          <div className="absolute -inset-4 bg-accent-400/5 rounded-[3rem] animate-pulse blur-xl" />
        </div>
        
        <div className="text-center space-y-3">
          <h2 className="text-2xl font-display font-bold text-brand-900 tracking-tight">TrainerLog Elite</h2>
          <div className="flex items-center justify-center space-x-2">
            <span className="w-1.5 h-1.5 bg-accent-500 rounded-full animate-bounce [animation-delay:-0.3s]" />
            <span className="w-1.5 h-1.5 bg-accent-500 rounded-full animate-bounce [animation-delay:-0.15s]" />
            <span className="w-1.5 h-1.5 bg-accent-500 rounded-full animate-bounce" />
          </div>
          <p className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.3em] mt-4">Orchestrating Platform...</p>
        </div>
      </div>

      <div className="absolute bottom-12 text-[10px] text-brand-200 font-accent font-bold uppercase tracking-widest">
        Architectural Integrity Verified
      </div>
    </div>
  );
}
