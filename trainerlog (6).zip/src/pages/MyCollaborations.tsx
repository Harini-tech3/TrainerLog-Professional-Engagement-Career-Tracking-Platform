import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../components/Auth/AuthContext';
import { Invitation, Event, User } from '../types';
import { handleFirestoreError, OperationType } from '../lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mail, 
  Calendar, 
  MapPin, 
  User as UserIcon, 
  Clock, 
  CheckCircle2,
  XCircle,
  MessageSquare,
  Star,
  ChevronRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '../lib/utils';

export default function MyCollaborations() {
  const { user, isAuthReady } = useAuth();
  const [invitations, setInvitations] = useState<(Invitation & { event?: Event, professional?: User })[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthReady || !user) {
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, 'invitations'),
      where('organizerId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const invs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Invitation));
      
      const enrichedInvs = await Promise.all(invs.map(async (inv) => {
        try {
          let eventData = undefined;
          let profData = undefined;

          if (inv.eventId) {
            const eventDoc = await getDoc(doc(db, 'events', inv.eventId));
            if (eventDoc.exists()) {
              eventData = { id: eventDoc.id, ...eventDoc.data() } as Event;
            }
          }

          if (inv.professionalId) {
            const profDoc = await getDoc(doc(db, 'users', inv.professionalId));
            if (profDoc.exists()) {
              profData = { id: profDoc.id, ...profDoc.data() } as unknown as User;
            }
          }

          return { 
            ...inv, 
            event: eventData,
            professional: profData
          };
        } catch (error) {
          console.error(error);
          return inv;
        }
      }));

      setInvitations(enrichedInvs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'invitations');
    });

    return () => unsubscribe();
  }, [user, isAuthReady]);

  if (loading) return (
    <div className="space-y-4">
      {[1, 2, 3].map(i => (
        <div key={i} className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm animate-pulse h-40" />
      ))}
    </div>
  );

  return (
    <div className="space-y-10 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 bg-white p-10 rounded-[3rem] border border-brand-100 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent-50/30 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
        
        <div className="relative z-10">
          <h1 className="text-4xl font-display font-bold text-brand-900 tracking-tight">Elite Collaborations</h1>
          <p className="text-brand-500 font-accent font-medium mt-2 text-lg">Track your elite partnerships and manage professional relationships.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8">
        {invitations.length === 0 ? (
          <div className="bg-white p-24 rounded-[3rem] border-2 border-dashed border-brand-100 text-center">
            <div className="w-24 h-24 bg-brand-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8">
              <Mail className="w-12 h-12 text-brand-100" />
            </div>
            <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight mb-3">No Collaborations Discovered</h3>
            <p className="text-brand-500 max-w-xs mx-auto font-accent font-medium italic opacity-80">
              Begin your elite journey by inviting global professionals to your curated events.
            </p>
            <Link to="/search" className="btn-gold mt-10 px-10 py-5 text-[10px]">
              Discover Elite Talent
            </Link>
          </div>
        ) : (
          invitations.map((inv) => (
            <motion.div
              key={inv.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="premium-card overflow-hidden group"
            >
              <div className="p-10">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-10">
                  <div className="flex-1 space-y-8">
                    <div className="flex items-center space-x-4">
                      <div className={cn(
                        "px-4 py-1.5 rounded-full text-[9px] font-accent font-bold uppercase tracking-[0.2em] shadow-sm",
                        inv.status === 'accepted' ? "bg-brand-900 text-accent-400" :
                        inv.status === 'rejected' ? "bg-red-50 text-red-600" :
                        "bg-brand-50 text-brand-600"
                      )}>
                        {inv.status}
                      </div>
                      <span className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] flex items-center">
                        <Clock className="w-4 h-4 mr-2 text-brand-200" />
                        Sent {new Date(inv.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </span>
                    </div>

                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-3xl font-display font-bold text-brand-900 tracking-tight mb-3">
                          {inv.eventTitle || inv.event?.title || 'Elite Collaboration Request'}
                        </h3>
                        <div className="flex flex-wrap items-center gap-y-3 gap-x-8 text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">
                          <span className="flex items-center">
                            <Calendar className="w-4 h-4 mr-2 text-accent-500" />
                            {inv.event?.date ? new Date(inv.event.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : 'Schedule TBD'}
                          </span>
                          <span className="flex items-center">
                            <MapPin className="w-4 h-4 mr-2 text-accent-500" />
                            {inv.event?.location || 'Venue TBD'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-6 p-6 bg-brand-50/30 rounded-[2rem] border border-brand-100 group-hover:bg-white transition-all duration-500">
                      <div className="w-16 h-16 bg-brand-900 rounded-2xl flex items-center justify-center text-accent-400 font-display font-bold text-xl shadow-xl border border-brand-800 overflow-hidden">
                        {inv.professional?.photoURL ? (
                          <img src={inv.professional.photoURL} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          inv.professional?.displayName?.[0] || '?'
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-[9px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em] mb-1">Elite Professional</p>
                        <p className="text-lg font-display font-bold text-brand-900">{inv.professional?.displayName || 'Unknown Professional'}</p>
                      </div>
                      <Link 
                        to={`/professional/${inv.professionalId}`}
                        className="p-4 bg-white text-brand-600 rounded-2xl border border-brand-100 hover:bg-brand-900 hover:text-accent-400 transition-all shadow-sm hover:shadow-xl"
                      >
                        <ChevronRight className="w-6 h-6" />
                      </Link>
                    </div>
                  </div>

                  <div className="flex lg:flex-col gap-4">
                    {inv.status === 'accepted' && (
                      <Link
                        to={`/professional/${inv.professionalId}`}
                        className="btn-gold flex-1 lg:w-48 py-4 text-[10px]"
                      >
                        <Star className="w-4 h-4 mr-3" />
                        Leave Review
                      </Link>
                    )}
                    <div className={cn(
                      "flex items-center px-8 py-4 rounded-2xl font-accent font-bold text-[10px] uppercase tracking-widest shadow-sm",
                      inv.status === 'accepted' ? "bg-brand-900 text-accent-400" : 
                      inv.status === 'rejected' ? "bg-red-50 text-red-600" : "bg-brand-50 text-brand-600"
                    )}>
                      {inv.status === 'accepted' ? (
                        <CheckCircle2 className="w-5 h-5 mr-3" />
                      ) : inv.status === 'rejected' ? (
                        <XCircle className="w-5 h-5 mr-3" />
                      ) : (
                        <Clock className="w-5 h-5 mr-3" />
                      )}
                      {inv.status}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
