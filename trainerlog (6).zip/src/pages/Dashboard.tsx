import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, orderBy, limit, getDoc, doc, setDoc, addDoc, updateDoc, deleteDoc, getDocs, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../components/Auth/AuthContext';
import { Engagement, Invitation, Profile } from '../types';
import { cn, handleFirestoreError, OperationType } from '../lib/utils';
import { 
  Users, 
  Calendar, 
  CheckCircle, 
  Clock,
  TrendingUp,
  ArrowUpRight,
  ArrowRight,
  Plus,
  Search,
  Award,
  Zap,
  Mail,
  ChevronRight,
  AlertCircle,
  Sparkles,
  User as UserIcon,
  Upload,
  RefreshCw,
  Activity
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import ExpertiseRadar from '../components/Analytics/ExpertiseRadar';
import ImpactSummarizer from '../components/Analytics/ImpactSummarizer';
import GlobalFootprintMap from '../components/Analytics/GlobalFootprintMap';
import SharePortfolio from '../components/Analytics/SharePortfolio';
import Footer from '../components/Layout/Footer';

export default function Dashboard() {
  const { user, firebaseUser, isAuthReady } = useAuth();
  const [engagements, setEngagements] = useState<Engagement[]>([]);
  const [globalActivity, setGlobalActivity] = useState<(Engagement & { professionalName: string })[]>([]);
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [globalStats, setGlobalStats] = useState({ totalEngagements: 0, verifiedLogs: 0, audienceReach: 0, totalUsers: 0 });
  const [profileData, setProfileData] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [timeRange, setTimeRange] = useState('Last 6 Months');

  useEffect(() => {
    if (!isAuthReady) return;
    
    const effectiveUid = user?.uid || firebaseUser?.uid;
    if (!effectiveUid) {
      setLoading(false);
      return;
    }

    // Show welcome toast if empty
    if (engagements.length === 0 && invitations.length === 0 && !loading) {
      toast("Welcome to your dashboard!", {
        description: "Click 'Upload Sample History' to see how analytics and logs work.",
        icon: <Sparkles className="w-4 h-4 text-indigo-600" />,
      });
    }
  }, [isAuthReady, engagements.length, invitations.length, loading]);

  useEffect(() => {
    if (!isAuthReady) return;
    
    const effectiveUid = user?.uid || firebaseUser?.uid;
    if (!effectiveUid) {
      setLoading(false);
      return;
    }

    // Fetch profile data for completion check
    const unsubscribeProfile = onSnapshot(doc(db, 'profiles', effectiveUid), (docSnap) => {
      if (docSnap.exists()) {
        setProfileData(docSnap.data() as any);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `profiles/${effectiveUid}`);
    });

    // User's engagements (or all if admin)
    const q = user?.role === 'Admin'
      ? query(collection(db, 'engagements'), orderBy('date', 'desc'), limit(50))
      : query(
          collection(db, 'engagements'),
          where('professionalId', '==', effectiveUid),
          orderBy('date', 'desc')
        );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Engagement));
      setEngagements(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'engagements');
    });

    // Global verified activity
    const globalQ = query(
      collection(db, 'engagements'),
      where('status', '==', 'verified'),
      orderBy('date', 'desc'),
      limit(5)
    );

    const unsubscribeGlobal = onSnapshot(globalQ, async (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Engagement));
      // Fast path: map currently known users to avoid async gaps for self
      const enriched = await Promise.all(data.map(async (e) => {
        try {
          if (!e.professionalId) return { ...e, professionalName: 'Verified Architect' };
          
          // Optimization: If it's me, use local state immediately
          if (e.professionalId === effectiveUid && (user?.displayName || firebaseUser?.displayName)) {
            return { ...e, professionalName: user?.displayName || firebaseUser?.displayName || 'Elite Pro' };
          }

          const profDoc = await getDoc(doc(db, 'users', e.professionalId));
          return { 
            ...e, 
            professionalName: profDoc.exists() ? (profDoc.data().displayName || 'Verified Architect') : 'Verified Architect' 
          };
        } catch (error) {
          return { ...e, professionalName: 'Verified Architect' };
        }
      }));
      setGlobalActivity(enriched);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'engagements');
    });

    // Pending Invitations
    const invQ = query(
      collection(db, 'invitations'),
      where('professionalId', '==', effectiveUid),
      where('status', '==', 'pending')
    );

    const unsubscribeInv = onSnapshot(invQ, (snapshot) => {
      setInvitations(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Invitation)));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'invitations');
    });

    // Global Stats for Admins
    let unsubscribeAllEngs = () => {};
    let unsubscribeAllUsers = () => {};

    if (user?.role === 'Admin') {
      unsubscribeAllEngs = onSnapshot(collection(db, 'engagements'), (snapshot) => {
        const data = snapshot.docs.map(doc => doc.data() as Engagement);
        setGlobalStats(prev => ({
          ...prev,
          totalEngagements: data.length,
          verifiedLogs: data.filter(e => e.status === 'verified').length,
          audienceReach: data.reduce((acc, curr) => acc + (Number(curr.audienceSize) || 0), 0)
        }));
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'engagements');
      });

      unsubscribeAllUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
        setGlobalStats(prev => ({ ...prev, totalUsers: snapshot.size }));
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'users');
      });
    }

    return () => {
      unsubscribe();
      unsubscribeGlobal();
      unsubscribeInv();
      unsubscribeAllEngs();
      unsubscribeAllUsers();
      unsubscribeProfile();
    };
  }, [user, firebaseUser, isAuthReady]);

  const seedMyData = async () => {
    const effectiveUid = user?.uid || firebaseUser?.uid;
    if (!effectiveUid || !firebaseUser) return;
    
    setIsUploading(true);
    
    try {
      // Simulate upload progress
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // 1. Initialize User
      await setDoc(doc(db, 'users', effectiveUid), {
        uid: effectiveUid,
        displayName: firebaseUser.displayName || 'Professional User',
        email: firebaseUser.email,
        role: user?.role || 'Professional',
        isVerified: true, // Mark as verified for demo/seed purposes
        createdAt: serverTimestamp()
      }, { merge: true }).catch(error => handleFirestoreError(error, OperationType.WRITE, `users/${effectiveUid}`));

      // 2. Initialize Profile
      await setDoc(doc(db, 'profiles', effectiveUid), {
        uid: effectiveUid,
        bio: 'Experienced professional with a passion for excellence and community engagement. Specializing in strategic planning and event execution.',
        expertise: ['Strategic Planning', 'Public Speaking', 'Leadership'],
        skills: ['Project Management', 'Communication', 'Problem Solving'],
        experience: [
          {
            id: 'exp1',
            title: 'Senior Consultant',
            company: 'Global Solutions Inc.',
            location: 'New York, NY',
            startDate: '2022-01-01',
            current: true,
            description: 'Leading strategic initiatives and managing high-impact projects.'
          }
        ],
        certifications: [
          {
            id: 'cert1',
            name: 'PMP Certification',
            issuer: 'Project Management Institute',
            issueDate: '2021-05-15'
          }
        ],
        portfolioLinks: ['https://linkedin.com', 'https://github.com']
      }).catch(error => handleFirestoreError(error, OperationType.WRITE, `profiles/${effectiveUid}`));

      // 3. Create Example Engagements
      const engagementsRef = collection(db, 'engagements');
      const exampleEngagements = [
        {
          professionalId: effectiveUid,
          title: 'Tech Summit 2024 Keynote',
          role: 'Speaker',
          description: 'Delivered a keynote on the future of AI in professional services.',
          date: new Date().toISOString(),
          venue: 'San Francisco, CA',
          audienceSize: 500,
          status: 'verified',
          tags: ['AI', 'Tech', 'Keynote'],
          createdAt: serverTimestamp()
        },
        {
          professionalId: effectiveUid,
          title: 'Leadership Workshop',
          role: 'Lecturer',
          description: 'Facilitated a 2-day workshop for emerging leaders.',
          date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          venue: 'Remote',
          audienceSize: 50,
          status: 'logged',
          tags: ['Leadership', 'Workshop'],
          createdAt: serverTimestamp()
        },
        {
          professionalId: effectiveUid,
          title: 'Global AI Conference',
          role: 'Panelist',
          description: 'Discussed ethical implications of generative AI.',
          date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
          venue: 'London, UK',
          audienceSize: 1200,
          status: 'verified',
          tags: ['AI', 'Ethics', 'Panel'],
          createdAt: serverTimestamp()
        },
        {
          professionalId: effectiveUid,
          title: 'Guest Lecture: Modern Systems',
          role: 'Guest Speaker',
          description: 'Invited lecture for senior architecture students.',
          date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(),
          venue: 'Stanford University',
          audienceSize: 150,
          status: 'verified',
          tags: ['Education', 'Tech'],
          createdAt: serverTimestamp()
        },
        {
          professionalId: effectiveUid,
          title: 'Design Critique Moderator',
          role: 'Moderator',
          description: 'Moderated a high-stakes design review for a Fortune 500.',
          date: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
          venue: 'San Francisco, CA',
          audienceSize: 15,
          status: 'verified',
          tags: ['Design', 'Moderation'],
          createdAt: serverTimestamp()
        },
        {
          professionalId: effectiveUid,
          title: 'Corporate Strategy Session',
          role: 'Consultant',
          description: 'Advised on digital transformation strategy.',
          date: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(),
          venue: 'New York, NY',
          audienceSize: 25,
          status: 'logged',
          tags: ['Strategy', 'Consulting'],
          createdAt: serverTimestamp()
        },
        {
          professionalId: effectiveUid,
          title: 'Innovation Expo 2023',
          role: 'Exhibitor',
          description: 'Showcased new product prototypes.',
          date: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
          venue: 'Berlin, Germany',
          audienceSize: 3000,
          status: 'verified',
          tags: ['Innovation', 'Product'],
          createdAt: serverTimestamp()
        },
        {
          professionalId: effectiveUid,
          title: 'Global Tech Forum 2023',
          role: 'Speaker',
          description: 'Keynote on sustainable technology.',
          date: new Date(Date.now() - 270 * 24 * 60 * 60 * 1000).toISOString(),
          venue: 'Tokyo, Japan',
          audienceSize: 800,
          status: 'verified',
          tags: ['Sustainability', 'Tech'],
          createdAt: serverTimestamp()
        },
        {
          professionalId: effectiveUid,
          title: 'Leadership Retreat 2023',
          role: 'Facilitator',
          description: 'Executive leadership training.',
          date: new Date(Date.now() - 360 * 24 * 60 * 60 * 1000).toISOString(),
          venue: 'Aspen, CO',
          audienceSize: 40,
          status: 'verified',
          tags: ['Leadership', 'Executive'],
          createdAt: serverTimestamp()
        }
      ];

      for (const eng of exampleEngagements) {
        await addDoc(engagementsRef, eng).catch(error => handleFirestoreError(error, OperationType.CREATE, 'engagements'));
      }

      // 4. Create Example Invitations
      const invitationsRef = collection(db, 'invitations');
      await addDoc(invitationsRef, {
        professionalId: effectiveUid,
        organizerId: 'system_organizer',
        organizerName: 'Elite Events Group',
        eventTitle: 'Industry Leaders Forum',
        message: 'We would love to have you speak at our upcoming forum.',
        status: 'pending',
        priority: 'high',
        createdAt: serverTimestamp()
      }).catch(error => handleFirestoreError(error, OperationType.CREATE, 'invitations'));
      
      await addDoc(invitationsRef, {
        professionalId: effectiveUid,
        organizerId: 'tech_events_corp',
        organizerName: 'TechEvents Corp',
        eventTitle: 'AI & Future Workshop',
        message: 'Your expertise in AI would be a great addition to our workshop.',
        status: 'pending',
        priority: 'medium',
        createdAt: serverTimestamp()
      }).catch(error => handleFirestoreError(error, OperationType.CREATE, 'invitations'));

      await addDoc(invitationsRef, {
        professionalId: effectiveUid,
        organizerId: 'creative_minds',
        organizerName: 'Creative Minds Agency',
        eventTitle: 'Design Thinking Seminar',
        message: 'We are looking for a professional to lead our next seminar.',
        status: 'pending',
        createdAt: serverTimestamp()
      }).catch(error => handleFirestoreError(error, OperationType.CREATE, 'invitations'));

      await addDoc(invitationsRef, {
        professionalId: effectiveUid,
        organizerId: 'edu_summit',
        organizerName: 'Education Summit 2024',
        eventTitle: 'Panel Discussion: Future of Learning',
        message: 'We would like to invite you as a panelist for our upcoming summit.',
        status: 'pending',
        createdAt: serverTimestamp()
      }).catch(error => handleFirestoreError(error, OperationType.CREATE, 'invitations'));

      await addDoc(invitationsRef, {
        professionalId: effectiveUid,
        organizerId: 'startup_hub',
        organizerName: 'Startup Hub',
        eventTitle: 'Mentor Connect',
        message: 'Our startups are looking for mentors with your background.',
        status: 'pending',
        createdAt: serverTimestamp()
      }).catch(error => handleFirestoreError(error, OperationType.CREATE, 'invitations'));
      
      toast.success('Sample data imported successfully!', {
        description: 'Your dashboard has been populated with professional history.',
      });
      // No reload needed if we want to show the data immediately via onSnapshot
    } catch (err) {
      console.error(err);
      toast.error('Failed to import sample data');
    } finally {
      setIsUploading(false);
    }
  };

  const resetData = async () => {
    const effectiveUid = user?.uid || firebaseUser?.uid;
    if (!effectiveUid) return;

    try {
      setIsUploading(true);
      // Delete engagements
      const engSnapshot = await getDocs(query(collection(db, 'engagements'), where('professionalId', '==', effectiveUid)));
      await Promise.all(engSnapshot.docs.map(d => deleteDoc(d.ref)));

      // Delete invitations
      const invSnapshot = await getDocs(query(collection(db, 'invitations'), where('professionalId', '==', effectiveUid)));
      await Promise.all(invSnapshot.docs.map(d => deleteDoc(d.ref)));

      toast.success('Data reset successfully!', {
        description: 'Your professional history has been cleared. You can now re-import sample data.',
      });
    } catch (err) {
      console.error(err);
      toast.error('Failed to reset data');
    } finally {
      setIsUploading(false);
    }
  };

  const calculateProfileCompletion = () => {
    if (!profileData) return 0;
    const fields = ['bio', 'expertise', 'skills', 'experience', 'certifications', 'portfolioLinks'];
    const completed = fields.filter(f => {
      const val = (profileData as any)[f];
      if (!val) return false;
      if (Array.isArray(val)) {
        // For arrays, ensure at least one non-empty item
        return val.some(item => {
          if (typeof item === 'string') return item.trim().length > 0;
          if (typeof item === 'object' && item !== null) return Object.keys(item).length > 0;
          return !!item;
        });
      }
      if (typeof val === 'string') return val.trim().length > 0;
      return true;
    }).length;
    return Math.round((completed / fields.length) * 100);
  };

  const getExpertiseLevel = () => {
    const score = (engagements.filter(e => e.status === 'verified').length * 2) + (profileData?.skills?.length || 0);
    if (score > 20) return { level: 5, label: 'Elite Professional' };
    if (score > 12) return { level: 4, label: 'Senior Professional' };
    if (score > 6) return { level: 3, label: 'Established Professional' };
    if (score > 2) return { level: 2, label: 'Rising Professional' };
    return { level: 1, label: 'Emerging Professional' };
  };

  const expertise = getExpertiseLevel();
  const completion = calculateProfileCompletion();

  const handleUpdateInvitationStatus = async (invitationId: string, status: 'accepted' | 'rejected') => {
    try {
      await updateDoc(doc(db, 'invitations', invitationId), { status })
        .catch(error => handleFirestoreError(error, OperationType.UPDATE, `invitations/${invitationId}`));
      
      toast.success(`Invitation ${status === 'accepted' ? 'accepted' : 'rejected'} successfully!`, {
        description: status === 'accepted' ? 'The organizer has been notified.' : 'The invitation has been declined.'
      });
    } catch (err) {
      console.error(err);
      toast.error(`Failed to ${status} invitation.`);
    }
  };

  const [showVerifiedOnly, setShowVerifiedOnly] = useState(false);

  const chartData = React.useMemo(() => {
    const activeEngagements = showVerifiedOnly 
      ? engagements.filter(e => e.status === 'verified')
      : engagements;

    if (activeEngagements.length === 0) return [];

    const now = new Date();
    const monthsToSubtract = timeRange === 'Last Year' ? 12 : 6;
    
    // Create an array of the last N months
    const months = [];
    for (let i = monthsToSubtract - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push({
        name: d.toLocaleDateString(undefined, { month: 'short' }),
        month: d.getMonth(),
        year: d.getFullYear(),
        audience: 0,
        logs: 0
      });
    }

    // Aggregate audience size and log count by month
    activeEngagements.forEach(e => {
      const d = new Date(e.date);
      const m = months.find(month => month.month === d.getMonth() && month.year === d.getFullYear());
      if (m) {
        m.audience += Number(e.audienceSize) || 0;
        m.logs += 1;
      }
    });

    return months;
  }, [engagements, timeRange, showVerifiedOnly]);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
  );

  const stats = user?.role === 'Admin' 
    ? [
        { name: 'Global Engagements', value: globalStats.totalEngagements, icon: Calendar, color: 'text-indigo-600', bg: 'bg-indigo-50', trend: '+14%' },
        { name: 'Platform Verified', value: globalStats.verifiedLogs, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50', trend: '+18%' },
        { name: 'Total Users', value: globalStats.totalUsers, icon: Users, color: 'text-amber-600', bg: 'bg-amber-50', trend: '+5%' },
        { name: 'Global Reach', value: globalStats.audienceReach.toLocaleString(), icon: TrendingUp, color: 'text-violet-600', bg: 'bg-violet-50', trend: '+32%' },
      ]
    : user?.role === 'Organizer'
    ? [
        { name: 'My Events', value: engagements.length, icon: Calendar, color: 'text-indigo-600', bg: 'bg-indigo-50', trend: '+12%' },
        { name: 'Sent Invitations', value: invitations.length, icon: Mail, color: 'text-emerald-600', bg: 'bg-emerald-50', trend: '+20%' },
        { name: 'Active Collaborations', value: invitations.filter(i => i.status === 'accepted').length, icon: CheckCircle, color: 'text-amber-600', bg: 'bg-amber-50', trend: '+15%' },
        { name: 'Total Budget Spent', value: `$${(invitations.filter(i => i.status === 'accepted').length * 500).toLocaleString()}`, icon: TrendingUp, color: 'text-violet-600', bg: 'bg-violet-50', trend: '+8%' },
      ]
    : [
        { name: 'Total Engagements', value: engagements.length, icon: Calendar, color: 'text-indigo-600', bg: 'bg-indigo-50', trend: '+8%' },
        { name: 'Verified Logs', value: engagements.filter(e => e.status === 'verified').length, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50', trend: '+12%' },
        { name: 'Active Skills', value: profileData?.skills?.length || 0, icon: Award, color: 'text-amber-600', bg: 'bg-amber-50', trend: '0%' },
        { name: 'Audience Reach', value: engagements.reduce((acc, curr) => acc + (Number(curr.audienceSize) || 0), 0).toLocaleString(), icon: Users, color: 'text-violet-600', bg: 'bg-violet-50', trend: '+24%' },
      ];

  return (
    <div className="space-y-8 pb-12">
      {/* System Status Banner - Premium Style */}
      <div className="bg-brand-50/30 border border-brand-100 rounded-2xl px-8 py-4 flex items-center justify-between backdrop-blur-sm shadow-sm">
        <div className="flex items-center space-x-4 text-brand-700">
          <div className="w-2.5 h-2.5 bg-accent-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(201,162,63,0.5)]" />
          <span className="text-[10px] font-accent font-bold uppercase tracking-[0.2em]">Elite Network Status: Operational</span>
        </div>
        <div className="flex items-center space-x-8 text-[10px] font-accent font-bold text-brand-400 uppercase tracking-[0.2em]">
          <span className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-accent-500" />
            v2.2.0 Elite
          </span>
          <span className="flex items-center">
            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2 animate-pulse" />
            Real-time Sync
          </span>
        </div>
      </div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h1 className="text-4xl md:text-6xl font-display font-bold text-brand-900 tracking-tighter flex flex-wrap items-center gap-4">
            Welcome back, <span className="gold-text-gradient italic font-medium">{user?.displayName || firebaseUser?.displayName || 'Elite'}</span>
            <div className="flex gap-2">
              <button 
                onClick={seedMyData}
                className="text-[9px] font-accent font-bold uppercase tracking-widest text-brand-400 hover:text-accent-600 transition-all border border-brand-100 px-4 py-2 rounded-full bg-white/50 hover:bg-white shadow-sm cursor-pointer"
                title="Import sample data to explore the platform"
              >
                {isUploading ? 'Importing...' : 'Import Samples'}
              </button>
              <button 
                onClick={resetData}
                className="text-[9px] font-accent font-bold uppercase tracking-widest text-red-400 hover:text-red-600 transition-all border border-red-100 px-4 py-2 rounded-full bg-white/50 hover:bg-white shadow-sm cursor-pointer"
                title="Reset all your data"
              >
                Reset Data
              </button>
            </div>
          </h1>
          <p className="text-brand-400 mt-3 font-accent font-medium text-lg tracking-wide italic opacity-80 border-l-2 border-accent-500 pl-4">Your professional ecosystem at a glance.</p>
        </div>
        <div className="flex items-center space-x-4">
          <button className="btn-secondary">
            <TrendingUp className="w-4 h-4 mr-2 text-accent-600" />
            Analytics
          </button>
          <Link to="/engagements" className="btn-primary">
            <Plus className="w-4 h-4 mr-2 text-accent-400" />
            Log Activity
          </Link>
        </div>
      </div>

      {/* Empty State / Get Started Section */}
      {engagements.length === 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-16 rounded-[2.5rem] border border-brand-100 flex flex-col items-center text-center relative overflow-hidden shadow-2xl"
        >
          {isUploading && (
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: '100%' }}
              transition={{ duration: 1.5 }}
              className="absolute top-0 left-0 h-1 bg-accent-500"
            />
          )}

          <div className="w-24 h-24 bg-brand-50 rounded-3xl flex items-center justify-center mb-8 border border-brand-100 shadow-sm">
            {isUploading ? (
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600" />
            ) : (
              <Upload className="w-12 h-12 text-accent-600" />
            )}
          </div>
          <h2 className="text-3xl font-display font-bold text-brand-900 mb-4">
            {isUploading ? 'Curating Your Elite Portfolio...' : 'Begin Your Elite Journey'}
          </h2>
          <p className="text-brand-500 max-w-md mb-10 font-accent font-medium text-lg leading-relaxed">
            {isUploading 
              ? 'We are meticulously organizing your professional history and verifying your global impact.' 
              : 'Your digital ecosystem is ready for expansion. Start by documenting your recent triumphs or import our curated sample history.'}
          </p>
          
          {!isUploading && (
            <div className="flex flex-col sm:flex-row gap-6">
              <button 
                onClick={seedMyData}
                className="btn-gold px-10 py-5 text-base"
              >
                <Upload className="w-5 h-5 mr-3" />
                Import Elite History
              </button>
              <Link 
                to="/engagements"
                className="btn-secondary px-10 py-5 text-base"
              >
                <Plus className="w-5 h-5 mr-3" />
                Manual Documentation
              </Link>
            </div>
          )}
        </motion.div>
      )}

      {completion < 100 && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="premium-gradient rounded-[2.5rem] p-10 text-white shadow-2xl relative overflow-hidden group border border-brand-800"
        >
          <div className="absolute top-0 right-0 p-16 opacity-5 group-hover:scale-110 transition-transform duration-700">
            <Zap className="w-64 h-64 text-accent-500" />
          </div>
          <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-10">
            <div className="max-w-2xl">
              <h3 className="text-3xl font-display font-bold mb-4 flex items-center">
                <Award className="w-10 h-10 mr-4 text-accent-400" />
                Refine Your Professional Identity
              </h3>
              <p className="text-brand-200 text-lg font-accent font-medium mb-8 leading-relaxed">
                An elite profile commands 4x more engagement from global organizers. Complete your documentation to unlock premium opportunities.
              </p>
              <div className="flex items-center space-x-8">
                <div className="flex-1 h-2.5 bg-white/10 rounded-full overflow-hidden backdrop-blur-sm border border-white/5">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${completion}%` }}
                    transition={{ duration: 1.5, ease: "circOut" }}
                    className="h-full bg-accent-500 shadow-[0_0_20px_rgba(201,162,63,0.6)]"
                  />
                </div>
                <span className="text-xl font-accent font-bold text-accent-400">{completion}%</span>
              </div>
            </div>
            <Link to="/profile" className="btn-gold px-10 py-5">
              Complete Profile
            </Link>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="premium-card p-8 group cursor-default hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-8">
              <div className={cn("p-4 rounded-2xl transition-all duration-500 group-hover:scale-110 group-hover:shadow-lg", stat.bg)}>
                <stat.icon className={cn("w-8 h-8", stat.color)} />
              </div>
              <span className={cn(
                "px-3 py-1.5 rounded-full text-[9px] font-accent font-bold flex items-center shadow-sm border",
                stat.trend.startsWith('+') ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-brand-50 text-brand-500 border-brand-100"
              )}>
                {stat.trend} <ArrowUpRight className="w-3 h-3 ml-1" />
              </span>
            </div>
            <p className="text-[10px] font-accent font-bold text-brand-400 uppercase tracking-[0.2em]">{stat.name}</p>
            <p className="text-4xl font-display font-bold text-brand-900 mt-3 tracking-tight">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          {/* Pending Invitations Section */}
          {invitations.length > 0 && (
            <div className="premium-card p-10">
              <div className="flex items-center justify-between mb-10">
                <div>
                  <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Elite Invitations</h3>
                  <p className="text-sm font-accent font-medium text-brand-400 mt-1 uppercase tracking-widest">Review your {invitations.length} pending requests</p>
                </div>
                <Link to="/invitations" className="text-[10px] font-accent font-bold text-accent-600 hover:text-accent-700 uppercase tracking-[0.2em] flex items-center group">
                  View All
                  <ChevronRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
              <div className="space-y-8">
                <AnimatePresence mode="popLayout">
                  {invitations.map((inv) => (
                    <motion.div
                      key={inv.id}
                      layout
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="group relative bg-brand-50/30 rounded-3xl p-8 border border-transparent hover:border-accent-200 hover:bg-white hover:shadow-2xl transition-all duration-500"
                    >
                      {inv.priority === 'high' && (
                        <div className="absolute top-0 right-0 mt-8 mr-8">
                          <span className="px-4 py-1.5 bg-accent-50 text-accent-600 text-[9px] font-accent font-bold rounded-full uppercase tracking-[0.2em] shadow-sm border border-accent-100">
                            Priority
                          </span>
                        </div>
                      )}
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
                        <div className="flex-1">
                          <div className="flex items-center gap-4 mb-3">
                            <span className="text-[10px] font-accent font-bold text-accent-600 uppercase tracking-[0.2em]">
                              {inv.organizerName || 'Organizer'}
                            </span>
                            <div className="w-1 h-1 bg-brand-200 rounded-full" />
                            <span className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-widest">
                              {new Date(inv.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                            </span>
                          </div>
                          <h4 className="text-xl font-display font-bold text-brand-900 mb-3 group-hover:text-accent-600 transition-colors">{inv.eventTitle || 'Untitled Event'}</h4>
                          <p className="text-sm text-brand-500 line-clamp-2 font-accent font-medium italic leading-relaxed opacity-80">
                            "{inv.message || 'No message provided.'}"
                          </p>
                        </div>
                        <div className="flex items-center gap-4">
                          <button
                            onClick={() => handleUpdateInvitationStatus(inv.id!, 'rejected')}
                            className="px-8 py-3.5 bg-white text-brand-600 font-accent font-bold text-[10px] uppercase tracking-widest rounded-full border border-brand-100 hover:bg-red-50 hover:text-red-600 hover:border-red-100 transition-all shadow-sm"
                          >
                            Decline
                          </button>
                          <button
                            onClick={() => handleUpdateInvitationStatus(inv.id!, 'accepted')}
                            className="btn-gold px-8 py-3.5 text-[10px]"
                          >
                            Accept
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>
          )}

          <div className="premium-card p-10 group">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-12 gap-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-brand-50 rounded-2xl group-hover:rotate-12 transition-transform">
                  <TrendingUp className="w-6 h-6 text-accent-500" />
                </div>
                <div>
                  <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Global Impact</h3>
                  <p className="text-sm font-accent font-medium text-brand-400 mt-1 uppercase tracking-widest leading-none">Audience reach trajectory</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setShowVerifiedOnly(!showVerifiedOnly)}
                  className={cn(
                    "px-4 py-3 rounded-xl text-[9px] font-accent font-bold uppercase tracking-widest transition-all",
                    showVerifiedOnly 
                      ? "bg-brand-900 text-accent-400 shadow-lg shadow-brand-100" 
                      : "bg-brand-50 text-brand-400 hover:bg-brand-100"
                  )}
                >
                  {showVerifiedOnly ? 'Verified Only' : 'All Logs'}
                </button>
                <select 
                  value={timeRange}
                  onChange={(e) => setTimeRange(e.target.value)}
                  className="bg-brand-50 border-brand-100 text-[10px] font-accent font-bold uppercase tracking-widest rounded-xl px-5 py-3 outline-none focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 transition-all cursor-pointer"
                >
                  <option value="Last 6 Months">Last 6 Months</option>
                  <option value="Last Year">Last Year</option>
                </select>
              </div>
            </div>
            <div className="h-96 relative">
              {chartData.length === 0 ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center space-y-4 bg-brand-50/10 rounded-3xl border-2 border-dashed border-brand-100">
                  <Activity className="w-12 h-12 text-brand-100 animate-pulse" />
                  <p className="text-xs font-accent font-bold text-brand-300 uppercase tracking-widest">Awaiting impact data...</p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorAudience" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#c9a23f" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#c9a23f" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                    <XAxis 
                      dataKey="name" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 700, fontFamily: 'Outfit' }}
                      dy={20}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 700, fontFamily: 'Outfit' }}
                    />
                    <Tooltip 
                      content={({ active, payload, label }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-[#0f172a] p-5 rounded-[1.5rem] shadow-2xl border border-white/5 backdrop-blur-md">
                              <p className="text-[9px] font-accent font-bold text-brand-400 uppercase tracking-widest mb-3">{label} Impact</p>
                              <div className="space-y-2">
                                <div className="flex items-center justify-between gap-8">
                                  <span className="text-[10px] font-accent font-medium text-white/60">Audience</span>
                                  <span className="text-sm font-display font-bold text-accent-400">{payload[0].value.toLocaleString()}</span>
                                </div>
                                <div className="flex items-center justify-between gap-8">
                                  <span className="text-[10px] font-accent font-medium text-white/60">Engagements</span>
                                  <span className="text-sm font-display font-bold text-white">{payload[0].payload.logs}</span>
                                </div>
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="audience" 
                      stroke="#c9a23f" 
                      strokeWidth={5}
                      fillOpacity={1} 
                      fill="url(#colorAudience)" 
                      animationDuration={2500}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <ExpertiseRadar engagements={engagements} />
            <SharePortfolio uid={firebaseUser?.uid || ''} />
          </div>
          <GlobalFootprintMap engagements={engagements} />
          <ImpactSummarizer engagements={engagements} profile={profileData} />
        </div>

        <div className="space-y-12">
          <div className="premium-card p-10">
            <h3 className="text-xl font-display font-bold text-brand-900 mb-10 tracking-tight">Elite Actions</h3>
            <div className="grid grid-cols-1 gap-6">
              {user?.role === 'Organizer' ? (
                <>
                  <Link to="/search" className="flex items-center p-6 rounded-3xl bg-brand-50/50 hover:bg-white transition-all group border border-transparent hover:border-accent-200 shadow-sm hover:shadow-2xl">
                    <div className="p-4 bg-white rounded-2xl shadow-sm mr-6 group-hover:text-accent-600 transition-colors border border-brand-100">
                      <Search className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <p className="text-base font-display font-bold text-brand-900 group-hover:text-accent-600 transition-colors">Find Professionals</p>
                      <p className="text-xs text-brand-400 font-accent font-medium uppercase tracking-widest mt-1">Global Talent Search</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-brand-200 group-hover:text-accent-600 transition-all group-hover:translate-x-1" />
                  </Link>
                  <Link to="/events" className="flex items-center p-6 rounded-3xl bg-brand-50/50 hover:bg-white transition-all group border border-transparent hover:border-accent-200 shadow-sm hover:shadow-2xl">
                    <div className="p-4 bg-white rounded-2xl shadow-sm mr-6 group-hover:text-accent-600 transition-colors border border-brand-100">
                      <Calendar className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <p className="text-base font-display font-bold text-brand-900 group-hover:text-accent-600 transition-colors">Manage Events</p>
                      <p className="text-xs text-brand-400 font-accent font-medium uppercase tracking-widest mt-1">Elite Event Curation</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-brand-200 group-hover:text-accent-600 transition-all group-hover:translate-x-1" />
                  </Link>
                </>
              ) : (
                <>
                  <Link to="/search" className="flex items-center p-6 rounded-3xl bg-brand-50/50 hover:bg-white transition-all group border border-transparent hover:border-accent-200 shadow-sm hover:shadow-2xl">
                    <div className="p-4 bg-white rounded-2xl shadow-sm mr-6 group-hover:text-accent-600 transition-colors border border-brand-100">
                      <Search className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <p className="text-base font-display font-bold text-brand-900 group-hover:text-accent-600 transition-colors">Find Events</p>
                      <p className="text-xs text-brand-400 font-accent font-medium uppercase tracking-widest mt-1">Premium Opportunities</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-brand-200 group-hover:text-accent-600 transition-all group-hover:translate-x-1" />
                  </Link>
                  <Link to="/profile" className="flex items-center p-6 rounded-3xl bg-brand-50/50 hover:bg-white transition-all group border border-transparent hover:border-accent-200 shadow-sm hover:shadow-2xl">
                    <div className="p-4 bg-white rounded-2xl shadow-sm mr-6 group-hover:text-accent-600 transition-colors border border-brand-100">
                      <Award className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <p className="text-base font-display font-bold text-brand-900 group-hover:text-accent-600 transition-colors">Refine Identity</p>
                      <p className="text-xs text-brand-400 font-accent font-medium uppercase tracking-widest mt-1">Profile Optimization</p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-brand-200 group-hover:text-accent-600 transition-all group-hover:translate-x-1" />
                  </Link>
                </>
              )}
            </div>
          </div>

          <div className="premium-card p-10">
            <div className="flex items-center justify-between mb-10">
              <h3 className="text-xl font-display font-bold text-brand-900 tracking-tight">Network Pulse</h3>
              <div className="px-4 py-1.5 bg-emerald-50 text-emerald-600 text-[9px] font-accent font-bold uppercase rounded-full tracking-[0.2em] shadow-sm border border-emerald-100 animate-pulse">Live Feed</div>
            </div>
            <div className="space-y-8">
              {globalActivity.length === 0 ? (
                <div className="text-center py-12">
                  <AlertCircle className="w-16 h-16 text-brand-100 mx-auto mb-4" />
                  <p className="text-sm text-brand-300 font-accent font-bold uppercase tracking-widest">Awaiting Activity</p>
                </div>
              ) : (
                globalActivity.map((e) => (
                  <div key={e.id} className="flex items-start space-x-5 group cursor-default">
                    <div className="w-12 h-12 rounded-2xl bg-brand-100 flex items-center justify-center text-brand-900 font-display font-bold text-lg shrink-0 border border-brand-200 group-hover:bg-accent-500 group-hover:text-white group-hover:scale-110 transition-all duration-500 shadow-sm overflow-hidden">
                      {e.professionalName?.[0] || 'A'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-display font-bold text-brand-900 truncate group-hover:text-accent-600 transition-colors">
                        {e.professionalName} <span className="font-accent font-bold text-emerald-600 text-[9px] uppercase tracking-[0.2em] ml-2">Verified</span>
                      </p>
                      <p className="text-xs text-brand-500 font-accent font-medium truncate mt-1 italic opacity-85">{e.title}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="premium-card p-10">
            <div className="flex items-center justify-between mb-10">
              <h3 className="text-xl font-display font-bold text-brand-900 tracking-tight">Recent Logs</h3>
              <Link to="/engagements" className="text-[10px] font-accent font-bold text-accent-600 hover:text-accent-700 uppercase tracking-[0.2em]">View All</Link>
            </div>
            <div className="space-y-8">
              {engagements.length === 0 ? (
                <div className="text-center py-12">
                  <AlertCircle className="w-16 h-16 text-brand-100 mx-auto mb-4" />
                  <p className="text-sm text-brand-300 font-accent font-bold uppercase tracking-widest">No Recent Logs</p>
                </div>
              ) : (
                engagements.slice(0, 4).map((e) => (
                  <div key={e.id} className="flex items-center space-x-6 group">
                    <div className={cn(
                      "w-3.5 h-3.5 rounded-full shadow-lg transition-transform group-hover:scale-125",
                      e.status === 'verified' ? "bg-emerald-500 shadow-emerald-200" : "bg-accent-500 shadow-accent-200"
                    )} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-display font-bold text-brand-900 truncate group-hover:text-accent-600 transition-colors">{e.title}</p>
                      <p className="text-[9px] text-brand-400 font-accent font-bold uppercase mt-1.5 tracking-widest">{new Date(e.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                    </div>
                    <span className={cn(
                      "px-4 py-1.5 text-[9px] font-accent font-bold uppercase rounded-full tracking-widest shadow-sm border",
                      e.status === 'verified' ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-accent-50 text-accent-600 border-accent-100"
                    )}>
                      {e.status}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
