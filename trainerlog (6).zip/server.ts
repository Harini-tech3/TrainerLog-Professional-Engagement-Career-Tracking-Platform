import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Initialize Gemini
if (!process.env.GEMINI_API_KEY) {
  console.warn("⚠️  GEMINI_API_KEY is missing from .env! AI features (Narrative Synthesis) will fail locally.");
}

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || "dummy_key",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

app.use(express.json());

// API Routes
app.post("/api/ai/analyze-impact", async (req, res) => {
  try {
    const { engagements, profile } = req.body;
    console.log("Analyzing impact for:", profile?.displayName || "Anonymous Professional");

    if (!engagements || !Array.isArray(engagements)) {
      return res.status(400).json({ error: "Missing engagements data" });
    }

    const prompt = `
      As an elite executive coach, analyze the following professional engagement history and profile to write a single, powerful, "data-driven professional narrative" (approx 80-120 words).
      The tone should be "Ultra-Premium", "Sophisticated", and "Authoritative". 
      Focus on the scale of impact, audience reach, and the variety of roles (Keynote Speaker, Lecturer, etc.).
      
      User Profile:
      - Name: ${profile?.displayName || 'The Professional'}
      - Bio: ${profile?.bio || 'Experienced professional'}
      - Expertise: ${profile?.expertise?.join(', ') || 'Various domains'}
      
      Engagements:
      ${engagements.map(e => `- ${e.title} (${e.role}) at ${e.venue}. Audience: ${e.audienceSize}. Status: ${e.status}`).join('\n')}
      
      Output constraints:
      - Format as a high-end prose paragraph.
      - Highlight specific numbers (e.g., "reached over 5,000 professionals").
      - Use sophisticated vocabulary (e.g., "catalyzing", "unprecedented", "global footprint").
      - Return ONLY a JSON object with a single key "narrative".
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            narrative: { type: Type.STRING }
          }
        }
      }
    });

    const result = JSON.parse(response.text || '{"narrative": "Professional narrative currently being optimized by elite intelligence."}');
    res.json(result);
  } catch (error) {
    console.error("AI Analysis Error:", error);
    res.status(500).json({ error: "Failed to catalyze professional narrative. Please check your secure credentials." });
  }
});

// Vite middleware for development
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting Sophisticated Vite Engine...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Frontend environment stabilized. Ready for traversal.");
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Elite Server energized at http://localhost:${PORT}`);
  });
}

startServer();
