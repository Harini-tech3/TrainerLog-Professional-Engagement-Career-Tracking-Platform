import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCw, ShieldAlert, Database, User as UserIcon, Lock } from 'lucide-react';
import { FirestoreErrorInfo } from '../lib/utils';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  firestoreError: FirestoreErrorInfo | null;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      firestoreError: null,
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    let firestoreError = null;
    try {
      if (error.message.startsWith('{')) {
        firestoreError = JSON.parse(error.message) as FirestoreErrorInfo;
      }
    } catch (e) {
      // Not a JSON error
    }
    return { hasError: true, error, firestoreError };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      const isPermissionError = this.state.firestoreError?.error.includes('insufficient permissions');

      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
          <div className="max-w-2xl w-full bg-white rounded-3xl shadow-2xl p-8 md:p-12 border border-gray-100">
            <div className="flex flex-col items-center text-center mb-8">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 ${isPermissionError ? 'bg-amber-50' : 'bg-red-50'}`}>
                {isPermissionError ? (
                  <ShieldAlert className="w-10 h-10 text-amber-600" />
                ) : (
                  <AlertCircle className="w-10 h-10 text-red-600" />
                )}
              </div>
              <h1 className="text-3xl font-extrabold text-gray-900 mb-3 tracking-tight">
                {isPermissionError ? 'Access Restricted' : 'Something went wrong'}
              </h1>
              <p className="text-gray-500 max-w-md font-medium">
                {isPermissionError 
                  ? "You don't have the necessary permissions to access this data. Please check your account role or contact support."
                  : "We encountered an unexpected error. Our team has been notified and we're working on a fix."}
              </p>
            </div>

            {this.state.firestoreError && (
              <div className="bg-gray-50 rounded-2xl p-6 mb-8 border border-gray-100">
                <h2 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4 flex items-center">
                  <Database className="w-4 h-4 mr-2" />
                  Technical Details
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="space-y-1">
                    <p className="text-gray-400 font-medium">Operation</p>
                    <p className="text-gray-900 font-bold capitalize">{this.state.firestoreError.operationType}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-gray-400 font-medium">Path</p>
                    <p className="text-gray-900 font-bold font-mono text-xs truncate" title={this.state.firestoreError.path || 'N/A'}>
                      {this.state.firestoreError.path || 'N/A'}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-gray-400 font-medium">User ID</p>
                    <p className="text-gray-900 font-bold font-mono text-xs truncate">
                      {this.state.firestoreError.authInfo.userId || 'Not Authenticated'}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-gray-400 font-medium">Email</p>
                    <p className="text-gray-900 font-bold truncate">
                      {this.state.firestoreError.authInfo.email || 'N/A'}
                    </p>
                  </div>
                </div>
                {this.state.firestoreError.authInfo.email && !this.state.firestoreError.authInfo.emailVerified && (
                  <div className="mt-4 p-3 bg-amber-50 rounded-xl border border-amber-100 flex items-start">
                    <Lock className="w-4 h-4 text-amber-600 mr-2 mt-0.5" />
                    <p className="text-xs text-amber-700 font-medium">
                      Your email address is not verified. Some permissions may be restricted until verification is complete.
                    </p>
                  </div>
                )}
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => window.location.reload()}
                className="flex-1 flex items-center justify-center px-8 py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100"
              >
                <RefreshCw className="w-5 h-5 mr-2" />
                Reload Application
              </button>
              <button
                onClick={() => window.location.href = '/'}
                className="flex-1 px-8 py-4 bg-white text-gray-700 font-bold rounded-2xl border border-gray-200 hover:bg-gray-50 transition-all"
              >
                Go to Home
              </button>
            </div>
            
            {process.env.NODE_ENV === 'development' && !this.state.firestoreError && (
              <div className="mt-8 p-4 bg-gray-50 rounded-xl text-left overflow-auto max-h-40 border border-gray-200">
                <p className="text-xs font-mono text-red-600">{this.state.error?.toString()}</p>
              </div>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
