import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, updateDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../components/Auth/AuthContext';
import { Event, Invitation, User } from '../types';
import { handleFirestoreError, OperationType, cn } from '../lib/utils';
import { 
  Plus, 
  Calendar, 
  MapPin, 
  Users, 
  Trash2, 
  Edit, 
  MoreVertical,
  Search,
  Filter,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Clock,
  X,
  Bell,
  BellRing
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { Reminder } from '../types';

export default function Events() {
  const { user, isAuthReady } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [isReminderModalOpen, setIsReminderModalOpen] = useState(false);
  const [selectedEventForReminder, setSelectedEventForReminder] = useState<Event | null>(null);
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedEventForDetails, setSelectedEventForDetails] = useState<Event | null>(null);
  const [eventInvitations, setEventInvitations] = useState<(Invitation & { professionalName?: string, professionalPhoto?: string })[]>([]);

  const [reminderData, setReminderData] = useState({
    type: '1_day_before' as '1_day_before' | '1_hour_before' | 'custom',
    deliveryMethod: 'in_app' as 'in_app',
    customDate: ''
  });

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    location: '',
    expectedAudience: 0,
    category: 'Workshop',
    tags: ''
  });

  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  useEffect(() => {
    if (!isAuthReady) return;
    if (!user) {
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, 'events'),
      where('organizerId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Event));
      setEvents(data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      setLoading(false);
    });

    const remindersQ = query(
      collection(db, 'reminders'),
      where('userId', '==', user.uid)
    );

    const unsubscribeReminders = onSnapshot(remindersQ, (snapshot) => {
      setReminders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reminder)));
    });

    return () => {
      unsubscribe();
      unsubscribeReminders();
    };
  }, [user]);

  useEffect(() => {
    if (!selectedEventForDetails) {
      setEventInvitations([]);
      return;
    }

    const invQ = query(
      collection(db, 'invitations'),
      where('eventId', '==', selectedEventForDetails.id),
      where('organizerId', '==', user.uid)
    );

    const unsubscribeInv = onSnapshot(invQ, async (snapshot) => {
      const invs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Invitation));
      const enrichedInvs = await Promise.all(invs.map(async (inv) => {
        const profDoc = await getDoc(doc(db, 'users', inv.professionalId));
        if (profDoc.exists()) {
          const profData = profDoc.data() as User;
          return { ...inv, professionalName: profData.displayName, professionalPhoto: profData.photoURL };
        }
        return inv;
      }));
      setEventInvitations(enrichedInvs);
    });

    return () => unsubscribeInv();
  }, [selectedEventForDetails]);

  const handleSetReminder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedEventForReminder) return;

    try {
      let remindAt = '';
      const eventDate = new Date(selectedEventForReminder.date);

      if (reminderData.type === '1_day_before') {
        remindAt = new Date(eventDate.getTime() - 24 * 60 * 60 * 1000).toISOString();
      } else if (reminderData.type === '1_hour_before') {
        remindAt = new Date(eventDate.getTime() - 60 * 60 * 1000).toISOString();
      } else {
        remindAt = new Date(reminderData.customDate).toISOString();
      }

      await addDoc(collection(db, 'reminders'), {
        userId: user.uid,
        eventId: selectedEventForReminder.id,
        eventTitle: selectedEventForReminder.title,
        type: reminderData.type,
        deliveryMethod: reminderData.deliveryMethod,
        remindAt,
        createdAt: serverTimestamp(),
        sent: false
      }).catch(error => handleFirestoreError(error, OperationType.CREATE, 'reminders'));

      toast.success('Reminder set successfully');
      setIsReminderModalOpen(false);
    } catch (err) {
      toast.error('Failed to set reminder');
      console.error(err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const tagsArray = formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag !== '');
      
      if (editingEvent) {
        await updateDoc(doc(db, 'events', editingEvent.id), {
          ...formData,
          tags: tagsArray,
          updatedAt: serverTimestamp()
        }).catch(error => handleFirestoreError(error, OperationType.UPDATE, `events/${editingEvent.id}`));
        toast.success('Event updated successfully');
      } else {
        await addDoc(collection(db, 'events'), {
          ...formData,
          tags: tagsArray,
          organizerId: user.uid,
          status: 'upcoming',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        }).catch(error => handleFirestoreError(error, OperationType.CREATE, 'events'));
        toast.success('Event created successfully');
      }
      setIsModalOpen(false);
      setEditingEvent(null);
      setFormData({ title: '', description: '', date: '', location: '', expectedAudience: 0, category: 'Workshop', tags: '' });
    } catch (err) {
      toast.error('Failed to save event');
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this event?')) return;
    try {
      await deleteDoc(doc(db, 'events', id));
      toast.success('Event deleted');
    } catch (err) {
      toast.error('Failed to delete event');
    }
  };

  const filteredEvents = events.filter(e => {
    const matchesSearch = (e.title || '').toLowerCase().includes((searchTerm || '').toLowerCase()) ||
      (e.location || '').toLowerCase().includes((searchTerm || '').toLowerCase());
    
    const matchesCategory = selectedCategory === 'All' || 
      e.category === selectedCategory || 
      e.tags?.includes(selectedCategory);
    
    return matchesSearch && matchesCategory;
  });

  const categories = ['Workshop', 'Conference', 'Seminar', 'Webinar', 'Panel Discussion', 'Technical', 'Leadership', 'AI'];
  const filterCategories = ['All', ...categories];

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h1 className="text-5xl font-display font-bold text-brand-900 tracking-tight">Elite Event Curation</h1>
          <p className="text-brand-500 mt-3 font-accent font-medium text-lg tracking-wide">Orchestrate your professional ecosystem with precision.</p>
        </div>
        <button 
          onClick={() => {
            setEditingEvent(null);
            setFormData({ title: '', description: '', date: '', location: '', expectedAudience: 0, category: 'Workshop', tags: '' });
            setIsModalOpen(true);
          }}
          className="btn-gold px-10 py-5"
        >
          <Plus className="w-5 h-5 mr-3" />
          Curate New Event
        </button>
      </div>

      <div className="flex flex-col space-y-6">
        <div className="flex items-center space-x-6 bg-white p-6 rounded-[2rem] border border-brand-100 shadow-sm">
          <div className="flex-1 relative">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-brand-400" />
            <input
              type="text"
              placeholder="Search elite events by title or location..."
              className="w-full pl-16 pr-6 py-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 transition-all outline-none text-base font-accent font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center space-x-3">
            <Filter className="w-4 h-4 text-brand-400" />
            <select
              className="px-6 py-4 border border-brand-100 rounded-2xl bg-brand-50/50 hover:bg-white transition-all text-[10px] font-accent font-bold text-brand-600 uppercase tracking-widest outline-none cursor-pointer"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              {filterCategories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3">
          {filterCategories.filter(c => c !== 'All').map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(selectedCategory === cat ? 'All' : cat)}
              className={cn(
                "px-6 py-2.5 rounded-full text-[10px] font-accent font-bold uppercase tracking-widest transition-all border",
                selectedCategory === cat 
                  ? 'bg-brand-900 border-brand-900 text-accent-400 shadow-lg shadow-brand-200' 
                  : 'bg-white border-brand-100 text-brand-400 hover:border-accent-400 hover:text-accent-600'
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        {filteredEvents.length === 0 ? (
          <div className="col-span-full bg-white p-24 rounded-[3rem] border border-brand-100 text-center shadow-2xl">
            <div className="w-24 h-24 bg-brand-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8 border border-brand-100">
              <Calendar className="w-12 h-12 text-brand-200" />
            </div>
            <h3 className="text-3xl font-display font-bold text-brand-900 mb-4">No elite events curated</h3>
            <p className="text-brand-500 max-w-sm mx-auto mb-10 font-accent font-medium text-lg leading-relaxed">
              Your professional calendar is a blank canvas. Begin by curating your first global event.
            </p>
            <button 
              onClick={() => setIsModalOpen(true)}
              className="btn-gold px-10 py-4"
            >
              Curate Your First Event <ArrowRight className="w-5 h-5 ml-3" />
            </button>
          </div>
        ) : (
          filteredEvents.map((event) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="premium-card group cursor-default hover:-translate-y-2"
            >
              <div className="p-10">
                  <div className="flex flex-wrap gap-3 mb-6">
                    <span className="px-4 py-1.5 bg-brand-900 text-accent-400 text-[9px] font-accent font-bold uppercase rounded-full tracking-[0.2em] shadow-sm">
                      {event.category || 'Event'}
                    </span>
                    {event.tags?.map((tag, i) => (
                      <span key={i} className="px-4 py-1.5 bg-brand-50 text-brand-400 text-[9px] font-accent font-bold uppercase rounded-full tracking-[0.2em] border border-brand-100">
                        #{tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-all duration-500 ml-auto">
                    <button 
                      onClick={() => {
                        setSelectedEventForReminder(event);
                        setIsReminderModalOpen(true);
                      }}
                      className={cn(
                        "p-3 rounded-2xl transition-all duration-300",
                        reminders.some(r => r.eventId === event.id)
                          ? 'text-accent-600 bg-accent-50 shadow-sm'
                          : 'text-brand-300 hover:text-accent-600 hover:bg-accent-50 hover:shadow-md'
                      )}
                      title="Set Reminder"
                    >
                      {reminders.some(r => r.eventId === event.id) ? (
                        <BellRing className="w-4 h-4" />
                      ) : (
                        <Bell className="w-4 h-4" />
                      )}
                    </button>
                    <button 
                      onClick={() => {
                        setEditingEvent(event);
                        setFormData({
                          title: event.title,
                          description: event.description,
                          date: event.date,
                          location: event.location,
                          expectedAudience: event.expectedAudience || 0,
                          category: event.category || 'Workshop',
                          tags: event.tags?.join(', ') || ''
                        });
                        setIsModalOpen(true);
                      }}
                      className="p-3 text-brand-300 hover:text-accent-600 hover:bg-accent-50 rounded-2xl transition-all duration-300 hover:shadow-md"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleDelete(event.id)}
                      className="p-3 text-brand-300 hover:text-red-600 hover:bg-red-50 rounded-2xl transition-all duration-300 hover:shadow-md"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <h3 
                  onClick={() => {
                    setSelectedEventForDetails(event);
                    setIsDetailModalOpen(true);
                  }}
                  className="text-2xl font-display font-bold text-brand-900 mb-4 group-hover:text-accent-600 transition-colors cursor-pointer tracking-tight"
                >
                  {event.title}
                </h3>
                <p className="text-sm text-brand-500 font-accent font-medium mb-8 line-clamp-2 italic opacity-80 leading-relaxed">
                  {event.description}
                </p>

                <div className="space-y-4 pt-6 border-t border-brand-50">
                  <div className="flex items-center text-sm text-brand-600 font-accent font-bold uppercase tracking-widest">
                    <Calendar className="w-4 h-4 mr-4 text-accent-500" />
                    {new Date(event.date).toLocaleDateString('en-US', { 
                      month: 'long', 
                      day: 'numeric', 
                      year: 'numeric' 
                    })}
                  </div>
                  <div className="flex items-center text-sm text-brand-600 font-accent font-bold uppercase tracking-widest">
                    <MapPin className="w-4 h-4 mr-4 text-accent-500" />
                    {event.location}
                  </div>
                  <div className="flex items-center text-sm text-brand-600 font-accent font-bold uppercase tracking-widest">
                    <Users className="w-4 h-4 mr-4 text-accent-500" />
                    {Number(event.expectedAudience) || 0} Expected Attendees
                  </div>
                </div>
              </div>
              
              <div className="px-10 py-6 bg-brand-50/50 flex items-center justify-between border-t border-brand-100 group-hover:bg-white transition-colors duration-500">
                <button 
                  onClick={() => {
                    setSelectedEventForDetails(event);
                    setIsDetailModalOpen(true);
                  }}
                  className="flex items-center group/btn"
                >
                  <div className="flex -space-x-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="w-8 h-8 rounded-2xl border-2 border-white bg-brand-200 flex items-center justify-center text-[10px] font-accent font-bold text-brand-600 shadow-sm">
                        {i}
                      </div>
                    ))}
                  </div>
                  <span className="text-[10px] font-accent font-bold text-brand-400 ml-4 uppercase tracking-[0.2em] group-hover/btn:text-accent-600 transition-colors">
                    Review Guest List
                  </span>
                </button>
                <Link 
                  to="/search" 
                  className="text-accent-600 font-accent font-bold text-[10px] uppercase tracking-[0.2em] hover:text-accent-700 flex items-center group/link"
                >
                  Invite More <ArrowRight className="w-3 h-3 ml-2 transition-transform group-hover/link:translate-x-1" />
                </Link>
              </div>
            </motion.div>
          ))
        )}
      </div>

      <AnimatePresence>
        {isDetailModalOpen && selectedEventForDetails && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsDetailModalOpen(false)}
              className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[2.5rem] shadow-2xl w-full max-w-2xl overflow-hidden border border-brand-100"
            >
              <div className="p-10">
                <div className="flex justify-between items-center mb-10">
                  <div>
                    <h2 className="text-3xl font-display font-bold text-brand-900 tracking-tight">{selectedEventForDetails.title}</h2>
                    <div className="flex flex-wrap gap-3 mt-4">
                      <span className="px-4 py-1.5 bg-brand-900 text-accent-400 text-[9px] font-accent font-bold uppercase rounded-full tracking-[0.2em] shadow-sm">
                        {selectedEventForDetails.category || 'Event'}
                      </span>
                      {selectedEventForDetails.tags?.map((tag, i) => (
                        <span key={i} className="px-4 py-1.5 bg-brand-50 text-brand-400 text-[9px] font-accent font-bold uppercase rounded-full tracking-[0.2em] border border-brand-100">
                          #{tag}
                        </span>
                      ))}
                    </div>
                    <p className="text-sm font-accent font-medium text-brand-400 mt-3 uppercase tracking-widest">Event Dossier & Elite Guest List</p>
                  </div>
                  <button 
                    onClick={() => setIsDetailModalOpen(false)}
                    className="p-3 hover:bg-brand-50 rounded-2xl transition-all"
                  >
                    <X className="w-6 h-6 text-brand-300" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-8">
                    <div className="space-y-5">
                      <div className="flex items-center text-sm text-brand-600 font-accent font-bold uppercase tracking-widest">
                        <Calendar className="w-5 h-5 mr-4 text-accent-500" />
                        {new Date(selectedEventForDetails.date).toLocaleDateString('en-US', { 
                          month: 'long', 
                          day: 'numeric', 
                          year: 'numeric' 
                        })}
                      </div>
                      <div className="flex items-center text-sm text-brand-600 font-accent font-bold uppercase tracking-widest">
                        <MapPin className="w-5 h-5 mr-4 text-accent-500" />
                        {selectedEventForDetails.location}
                      </div>
                      <div className="flex items-center text-sm text-brand-600 font-accent font-bold uppercase tracking-widest">
                        <Users className="w-5 h-5 mr-4 text-accent-500" />
                        {Number(selectedEventForDetails.expectedAudience) || 0} Expected Attendees
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h4 className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Description</h4>
                      <p className="text-sm text-brand-500 leading-relaxed italic opacity-80">
                        {selectedEventForDetails.description}
                      </p>
                    </div>

                    <div className="pt-6 border-t border-brand-50">
                      <button
                        onClick={() => {
                          setSelectedEventForReminder(selectedEventForDetails);
                          setIsReminderModalOpen(true);
                        }}
                        className={cn(
                          "w-full flex items-center justify-center gap-3 px-6 py-4 rounded-2xl text-[10px] font-accent font-bold uppercase tracking-[0.2em] transition-all",
                          reminders.some(r => r.eventId === selectedEventForDetails.id)
                            ? "bg-accent-50 text-accent-600 border border-accent-100"
                            : "bg-brand-50 text-brand-600 border border-brand-100 hover:bg-white hover:border-accent-400 hover:text-accent-600"
                        )}
                      >
                        {reminders.some(r => r.eventId === selectedEventForDetails.id) ? (
                          <>
                            <BellRing className="w-4 h-4" />
                            Update Elite Reminder
                          </>
                        ) : (
                          <>
                            <Bell className="w-4 h-4" />
                            Schedule Event Reminder
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Invited Professionals</h4>
                    <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                      {eventInvitations.length === 0 ? (
                        <div className="text-center py-10 bg-brand-50/50 rounded-3xl border border-brand-100">
                          <Users className="w-10 h-10 text-brand-100 mx-auto mb-3" />
                          <p className="text-[10px] text-brand-300 font-accent font-bold uppercase tracking-widest">No guests invited</p>
                        </div>
                      ) : (
                        eventInvitations.map((inv) => (
                          <div key={inv.id} className="flex items-center justify-between p-4 bg-white rounded-2xl border border-brand-100 shadow-sm hover:shadow-md transition-all">
                            <div className="flex items-center space-x-4">
                              <div className="w-10 h-10 rounded-xl bg-brand-900 flex items-center justify-center text-accent-400 font-display font-bold text-sm overflow-hidden border border-brand-800">
                                {inv.professionalPhoto ? (
                                  <img src={inv.professionalPhoto} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                ) : (
                                  inv.professionalName?.[0] || 'P'
                                )}
                              </div>
                              <div className="min-w-0">
                                <p className="text-sm font-display font-bold text-brand-900 truncate">{inv.professionalName || 'Professional'}</p>
                                <p className="text-[9px] text-brand-400 font-accent font-bold uppercase tracking-widest mt-1">Invited {new Date(inv.createdAt).toLocaleDateString()}</p>
                              </div>
                            </div>
                            <span className={cn(
                              "px-3 py-1 rounded-full text-[8px] font-accent font-bold uppercase tracking-widest shadow-sm",
                              inv.status === 'accepted' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                              inv.status === 'rejected' ? 'bg-red-50 text-red-600 border border-red-100' :
                              'bg-accent-50 text-accent-600 border border-accent-100'
                            )}>
                              {inv.status}
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                    <Link 
                      to="/search" 
                      className="btn-secondary w-full py-4 text-[10px]"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Invite Professionals
                    </Link>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {isReminderModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsReminderModalOpen(false)}
              className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden border border-brand-100"
            >
              <div className="p-10">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <h2 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Set Elite Reminder</h2>
                    <p className="text-sm font-accent font-medium text-brand-400 mt-1 uppercase tracking-widest">{selectedEventForReminder?.title}</p>
                  </div>
                  <button 
                    onClick={() => setIsReminderModalOpen(false)}
                    className="p-3 hover:bg-brand-50 rounded-2xl transition-all"
                  >
                    <X className="w-5 h-5 text-brand-300" />
                  </button>
                </div>

                <form onSubmit={handleSetReminder} className="space-y-8">
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Reminder Frequency</label>
                      <div className="grid grid-cols-1 gap-3">
                        {[
                          { id: '1_day_before', label: '1 Day Before' },
                          { id: '1_hour_before', label: '1 Hour Before' },
                          { id: 'custom', label: 'Custom Time' }
                        ].map((option) => (
                          <button
                            key={option.id}
                            type="button"
                            onClick={() => setReminderData({ ...reminderData, type: option.id as any })}
                            className={cn(
                              "px-6 py-4 rounded-2xl text-sm font-accent font-bold border-2 transition-all text-left flex items-center justify-between",
                              reminderData.type === option.id 
                                ? 'border-accent-400 bg-accent-50 text-accent-600' 
                                : 'border-brand-50 text-brand-400 hover:border-brand-100'
                            )}
                          >
                            {option.label}
                            {reminderData.type === option.id && <CheckCircle2 className="w-4 h-4" />}
                          </button>
                        ))}
                      </div>
                    </div>

                    {reminderData.type === 'custom' && (
                      <div className="space-y-3">
                        <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Custom Date & Time</label>
                        <input
                          required
                          type="datetime-local"
                          className="w-full p-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium"
                          value={reminderData.customDate}
                          onChange={(e) => setReminderData({ ...reminderData, customDate: e.target.value })}
                        />
                      </div>
                    )}

                    <div className="space-y-3">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Delivery Method</label>
                      <select
                        className="w-full p-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium bg-brand-50/50"
                        value={reminderData.deliveryMethod}
                        onChange={(e) => setReminderData({ ...reminderData, deliveryMethod: e.target.value as any })}
                      >
                        <option value="in_app">In-App Notification</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button
                      type="button"
                      onClick={() => setIsReminderModalOpen(false)}
                      className="btn-secondary flex-1 py-4 text-[10px]"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="btn-gold flex-1 py-4 text-[10px]"
                    >
                      Set Reminder
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}

        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-[2.5rem] shadow-2xl w-full max-w-2xl overflow-hidden border border-brand-100"
            >
              <div className="p-10">
                <div className="flex justify-between items-center mb-10">
                  <div>
                    <h2 className="text-3xl font-display font-bold text-brand-900 tracking-tight">
                      {editingEvent ? 'Refine Event' : 'Curate New Event'}
                    </h2>
                    <p className="text-sm font-accent font-medium text-brand-400 mt-1 uppercase tracking-widest">Define the parameters of your elite professional gathering.</p>
                  </div>
                  <button 
                    onClick={() => setIsModalOpen(false)}
                    className="p-3 hover:bg-brand-50 rounded-2xl transition-all"
                  >
                    <X className="w-6 h-6 text-brand-300" />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Event Title</label>
                      <input
                        required
                        type="text"
                        className="w-full p-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium"
                        placeholder="e.g. Global AI Summit 2026"
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Category</label>
                      <select
                        className="w-full p-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium bg-brand-50/50"
                        value={formData.category}
                        onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      >
                        {categories.map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Description</label>
                    <textarea
                      required
                      rows={3}
                      className="w-full p-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium"
                      placeholder="Articulate the vision and objectives of this gathering..."
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Date</label>
                      <input
                        required
                        type="date"
                        className="w-full p-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Location</label>
                      <input
                        required
                        type="text"
                        className="w-full p-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium"
                        placeholder="e.g. Ritz-Carlton, Paris"
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Expected Audience Size</label>
                    <input
                      required
                      type="number"
                      className="w-full p-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium"
                      placeholder="e.g. 1000"
                      value={formData.expectedAudience || 0}
                      onChange={(e) => setFormData({ ...formData, expectedAudience: parseInt(e.target.value) || 0 })}
                    />
                  </div>

                  <div className="space-y-3">
                    <label className="text-[10px] font-accent font-bold text-brand-300 uppercase tracking-[0.2em]">Tags (comma separated)</label>
                    <input
                      type="text"
                      className="w-full p-4 rounded-2xl border-brand-100 focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all font-accent font-medium"
                      placeholder="e.g. Innovation, Strategy, Network"
                      value={formData.tags}
                      onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                    />
                    {formData.tags && (
                      <div className="flex flex-wrap gap-3 mt-4">
                        {formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag !== '').map((tag, i) => (
                          <span key={i} className="px-4 py-1.5 bg-brand-50 text-brand-400 text-[9px] font-accent font-bold uppercase rounded-full tracking-[0.2em] border border-brand-100">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button
                      type="button"
                      onClick={() => setIsModalOpen(false)}
                      className="btn-secondary flex-1 py-4 text-[10px]"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="btn-gold flex-1 py-4 text-[10px]"
                    >
                      {editingEvent ? 'Save Refinements' : 'Curate Event'}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
