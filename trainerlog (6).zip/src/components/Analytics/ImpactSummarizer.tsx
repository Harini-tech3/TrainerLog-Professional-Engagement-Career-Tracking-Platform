import React, { useState } from 'react';
import { Engagement } from '../../types';
import { 
  Users, 
  MapPin, 
  Star,
  Activity,
  ArrowUpRight,
  Sparkles,
  Zap,
  Loader2,
  Quote
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

interface ImpactSummarizerProps {
  engagements: Engagement[];
  profile?: any;
}

export default function ImpactSummarizer({ engagements, profile }: ImpactSummarizerProps) {
  const [narrative, setNarrative] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const verifiedEngagements = engagements.filter(e => e.status === 'verified');
  const totalAudience = engagements.reduce((sum, e) => sum + (Number(e.audienceSize) || 0), 0);
  const distinctVenues = new Set(engagements.map(e => e.venue).filter(Boolean)).size;
  
  // Calculate trend (last 30 days vs previous 30 days)
  const now = new Date();
  const last30Days = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const prev30Days = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);
  
  const recentCount = engagements.filter(e => new Date(e.date) >= last30Days).length;
  const previousCount = engagements.filter(e => {
    const d = new Date(e.date);
    return d >= prev30Days && d < last30Days;
  }).length;
  
  const trend = previousCount === 0 ? 100 : Math.round(((recentCount - previousCount) / previousCount) * 100);

  const generateNarrative = async () => {
    if (engagements.length < 2) {
      toast.error("More engagements required", {
        description: "Log at least 2 engagements to generate a meaningful impact narrative."
      });
      return;
    }

    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai/analyze-impact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ engagements, profile }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to catalyze impact');
      }
      const data = await response.json();
      setNarrative(data.narrative);
      toast.success("Professional Narrative Catalyzed", {
        description: "AI analysis of your global impact is complete."
      });
    } catch (err: any) {
      console.error(err);
      toast.error("Narrative Synthesis Failed", {
        description: err.message.includes('credentials') 
          ? "Check your local .env configuration for the Gemini API key."
          : "The AI engine is currently optimizing. Please try again shortly."
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="premium-card p-10 relative overflow-hidden">
      <div className="absolute top-0 right-0 p-12 opacity-5 scale-150 pointer-events-none">
        <Sparkles className="w-32 h-32 text-accent-500" />
      </div>
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-10">
          <div>
            <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight">Impact Snapshot</h3>
            <p className="text-[10px] font-accent font-bold text-brand-400 mt-1 uppercase tracking-widest italic">Performance & Reach Summary</p>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={generateNarrative}
              disabled={isGenerating}
              className="px-4 py-2 bg-brand-900 text-accent-400 text-[10px] font-accent font-bold rounded-full border border-accent-900/10 uppercase tracking-widest flex items-center gap-2 hover:bg-black transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed group shadow-lg cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Catalyzing...
                </>
              ) : (
                <>
                  <Zap className="w-3.5 h-3.5 group-hover:animate-pulse" />
                  AI Narrative
                </>
              )}
            </button>
            <div className="px-4 py-2 bg-emerald-50 text-emerald-600 text-[10px] font-accent font-bold rounded-full border border-emerald-100 uppercase tracking-widest flex items-center gap-2">
              <Activity className="w-3 h-3" />
              Live Analysis
            </div>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {narrative ? (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-10 bg-brand-900/5 border border-accent-100 rounded-[2rem] p-10 relative group"
            >
              <div className="absolute top-0 left-0 -translate-x-3 -translate-y-3 p-3 bg-brand-900 text-accent-400 rounded-2xl shadow-xl">
                <Quote className="w-5 h-5 fill-accent-400" />
              </div>
              <p className="text-xl font-display font-medium text-brand-900 leading-relaxed italic pr-4">
                {narrative}
              </p>
              <div className="mt-8 flex items-center gap-2">
                <div className="h-px bg-brand-200 flex-1" />
                <span className="text-[9px] font-accent font-bold text-accent-600 uppercase tracking-[0.3em] bg-white px-4 py-1 rounded-full border border-brand-100">AI-Powered Impact Analysis</span>
                <div className="h-px bg-brand-200 flex-1" />
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
          <div className="space-y-2">
            <div className="flex items-center gap-3 text-brand-400">
              <Users className="w-4 h-4" />
              <span className="text-[10px] font-accent font-bold uppercase tracking-widest">Global Reach</span>
            </div>
            <div className="flex items-baseline gap-3">
              <span className="text-4xl font-display font-bold text-brand-900">{totalAudience.toLocaleString()}</span>
              <span className="text-sm font-accent font-bold text-emerald-600 flex items-center">
                <ArrowUpRight className="w-3 h-3 mr-1" />
                {trend}%
              </span>
            </div>
            <p className="text-[10px] text-brand-400 font-accent font-medium">Total audience attendance across all logged engagements.</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-3 text-brand-400">
              <Star className="w-4 h-4" />
              <span className="text-[10px] font-accent font-bold uppercase tracking-widest">Verified Integrity</span>
            </div>
            <div className="flex items-baseline gap-3">
              <span className="text-4xl font-display font-bold text-brand-900">{verifiedEngagements.length}</span>
              <span className="text-sm font-accent font-bold text-accent-600 uppercase tracking-widest">Logs</span>
            </div>
            <p className="text-[10px] text-brand-400 font-accent font-medium">{Math.round((verifiedEngagements.length / (engagements.length || 1)) * 100)}% verification rate from organizers.</p>
          </div>
        </div>

        <div className="bg-brand-50/50 rounded-3xl p-8 border border-brand-100">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center gap-6">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm border border-brand-100">
                <MapPin className="w-6 h-6 text-brand-600" />
              </div>
              <div>
                <p className="text-[10px] font-accent font-bold text-brand-400 uppercase tracking-widest">Global Footprint</p>
                <p className="text-lg font-display font-bold text-brand-900">{distinctVenues} Distinct Venues</p>
              </div>
            </div>
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-10 h-10 rounded-full border-4 border-white bg-brand-100 flex items-center justify-center overflow-hidden">
                  <div className="w-full h-full bg-brand-200 animate-pulse" />
                </div>
              ))}
              <div className="w-10 h-10 rounded-full border-4 border-white bg-brand-900 flex items-center justify-center text-white text-[10px] font-accent font-bold">
                +{engagements.length}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] font-accent font-bold text-brand-400 uppercase tracking-[0.2em]">Activity Density</span>
            <span className="text-[10px] font-accent font-bold text-brand-900">
              {recentCount} in the last 30 days
            </span>
          </div>
          <div className="h-1.5 bg-brand-50 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${Math.min((recentCount / 10) * 100, 100)}%` }}
              className="h-full bg-accent-500 shadow-[0_0_10px_rgba(201,162,63,0.4)]"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
