import React, { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  serverTimestamp, 
  doc, 
  runTransaction,
  orderBy
} from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../Auth/AuthContext';
import { Review, Profile } from '../../types';
import { Star, MessageSquare, Send, User as UserIcon, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { cn } from '../../lib/utils';

interface ReviewSystemProps {
  professionalId: string;
  engagementId?: string;
  canReview?: boolean;
}

export default function ReviewSystem({ professionalId, engagementId, canReview = false }: ReviewSystemProps) {
  const { user } = useAuth();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [hoveredRating, setHoveredRating] = useState(0);

  useEffect(() => {
    const q = query(
      collection(db, 'reviews'),
      where('professionalId', '==', professionalId),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Review));
      setReviews(data);
      setLoading(false);
    }, (err) => {
      console.error(err);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [professionalId]);

  const handleSubmitReview = async () => {
    if (!user || rating === 0 || !comment.trim()) {
      toast.error('Please provide a rating and a comment');
      return;
    }

    setIsSubmitting(true);
    try {
      await runTransaction(db, async (transaction) => {
        // 1. Create the review
        const reviewRef = doc(collection(db, 'reviews'));
        const reviewData = {
          professionalId,
          organizerId: user.uid,
          organizerName: user.displayName,
          engagementId: engagementId || null,
          rating,
          comment: comment.trim(),
          createdAt: new Date().toISOString()
        };
        transaction.set(reviewRef, reviewData);

        // 2. Update the profile stats
        const profileRef = doc(db, 'profiles', professionalId);
        const profileSnap = await transaction.get(profileRef);
        
        if (profileSnap.exists()) {
          const profileData = profileSnap.data() as Profile;
          const currentCount = profileData.reviewCount || 0;
          const currentAvg = profileData.averageRating || 0;
          
          const newCount = currentCount + 1;
          const newAvg = ((currentAvg * currentCount) + rating) / newCount;
          
          transaction.update(profileRef, {
            reviewCount: newCount,
            averageRating: newAvg
          });
        }
      });

      toast.success('Review submitted successfully!');
      setRating(0);
      setComment('');
    } catch (err) {
      console.error(err);
      toast.error('Failed to submit review');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return <div className="animate-pulse space-y-4">
    {[1, 2].map(i => <div key={i} className="h-24 bg-gray-50 rounded-2xl" />)}
  </div>;

  return (
    <div className="space-y-10">
      {canReview && (
        <div className="bg-white p-10 rounded-[2.5rem] border border-brand-100 shadow-xl space-y-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-accent-50/30 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
          
          <div className="flex items-center space-x-4 text-brand-900 font-display font-bold text-xl tracking-tight relative z-10">
            <Star className="w-6 h-6 text-accent-500" />
            <span>Document Your Experience</span>
          </div>
          
          <div className="flex items-center space-x-3 relative z-10">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                onClick={() => setRating(star)}
                className="p-1 transition-all duration-300 transform hover:scale-125 active:scale-95"
              >
                <Star 
                  className={cn(
                    "w-10 h-10 transition-all duration-300",
                    star <= (hoveredRating || rating) ? "text-accent-500 fill-accent-500 shadow-sm" : "text-brand-100"
                  )} 
                />
              </button>
            ))}
          </div>

          <textarea
            placeholder="Articulate your professional feedback regarding this elite collaboration..."
            className="w-full p-6 rounded-2xl border-brand-100 bg-brand-50/30 text-sm font-accent font-medium focus:ring-4 focus:ring-accent-500/10 focus:border-accent-400 outline-none transition-all resize-none relative z-10"
            rows={4}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />

          <button
            onClick={handleSubmitReview}
            disabled={isSubmitting || rating === 0 || !comment.trim()}
            className="btn-gold w-full py-5 text-[10px] relative z-10"
          >
            {isSubmitting ? 'Transmitting...' : (
              <>
                <Send className="w-4 h-4 mr-3" />
                Dispatch Review
              </>
            )}
          </button>
        </div>
      )}

      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <h3 className="text-2xl font-display font-bold text-brand-900 tracking-tight flex items-center">
            <MessageSquare className="w-7 h-7 mr-4 text-accent-500" />
            Professional Testimonials ({reviews.length})
          </h3>
          {reviews.length > 0 && (
            <div className="flex items-center text-accent-600 font-accent font-bold text-[10px] uppercase tracking-[0.2em] bg-accent-50 px-4 py-2 rounded-full border border-accent-100 shadow-sm">
              <Star className="w-4 h-4 mr-2 fill-accent-500 text-accent-500" />
              {(reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1)} Elite Average
            </div>
          )}
        </div>

        {reviews.length === 0 ? (
          <div className="text-center py-20 bg-brand-50/30 rounded-[3rem] border-2 border-dashed border-brand-100">
            <MessageSquare className="w-16 h-16 text-brand-100 mx-auto mb-6" />
            <p className="text-brand-400 font-accent font-bold uppercase tracking-[0.2em] text-xs">No testimonials documented yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {reviews.map((review) => (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white p-8 rounded-[2rem] border border-brand-100 shadow-lg space-y-6 group hover:shadow-xl transition-all duration-500"
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-brand-900 rounded-xl flex items-center justify-center text-accent-400 font-display font-bold shadow-lg border border-brand-800">
                      <UserIcon className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-display font-bold text-brand-900 text-lg group-hover:text-accent-600 transition-colors">{review.organizerName}</p>
                      <div className="flex items-center text-[9px] text-brand-300 font-accent font-bold uppercase tracking-[0.2em] mt-1">
                        <Calendar className="w-3 h-3 mr-2 text-accent-500" />
                        {new Date(review.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1 bg-brand-50 px-3 py-1.5 rounded-full border border-brand-100">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star 
                        key={star} 
                        className={cn(
                          "w-3.5 h-3.5",
                          star <= review.rating ? "text-accent-500 fill-accent-500" : "text-brand-100"
                        )} 
                      />
                    ))}
                  </div>
                </div>
                <p className="text-base text-brand-500 leading-relaxed font-accent font-medium italic opacity-80 pl-2 border-l-2 border-accent-100">
                  "{review.comment}"
                </p>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
